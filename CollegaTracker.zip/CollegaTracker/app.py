import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import os
from services.garmin_connect import GarminConnectService
from services.integrations import IntegrationsService
from services.data_analysis import DataAnalysisService
from utils.helpers import format_duration, calculate_training_load

# Page configuration
st.set_page_config(
    page_title="Ultra-Endurance Performance Platform",
    page_icon="🏃‍♂️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize services
@st.cache_resource
def init_services():
    """Initialize all services with proper error handling"""
    garmin_service = GarminConnectService()
    integrations_service = IntegrationsService()
    data_analysis_service = DataAnalysisService()
    return garmin_service, integrations_service, data_analysis_service

def main():
    """Main application entry point"""
    
    # Header
    st.title("🏃‍♂️ Ultra-Endurance Performance Platform")
    st.markdown("### Trasformazione atletica completa per performance di ultra-endurance")
    
    # Initialize services
    try:
        garmin_service, integrations_service, data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione dei servizi: {str(e)}")
        st.stop()
    
    # Sidebar for navigation and quick stats
    with st.sidebar:
        st.header("🏔️ Quick Overview")
        
        # Connection status
        st.subheader("📡 Stato Connessioni")
        
        # Check Garmin Connect status
        try:
            garmin_status = garmin_service.check_connection_status()
            if garmin_status:
                st.success("✅ Garmin Connect")
            else:
                st.error("❌ Garmin Connect - Riconnetti")
        except:
            st.warning("⚠️ Garmin Connect - Verifica configurazione")
        
        # Other integrations status
        integrations_status = integrations_service.get_all_connection_status()
        for service, status in integrations_status.items():
            if status:
                st.success(f"✅ {service}")
            else:
                st.error(f"❌ {service}")
        
        st.divider()
        
        # Quick stats
        st.subheader("📊 Oggi")
        try:
            today_data = data_analysis_service.get_today_summary()
            if today_data:
                st.metric("Distanza", f"{today_data.get('distance', 0):.1f} km")
                st.metric("Tempo", format_duration(today_data.get('duration', 0)))
                st.metric("Calorie", f"{today_data.get('calories', 0):.0f}")
                st.metric("Training Load", f"{today_data.get('training_load', 0):.1f}")
            else:
                st.info("Nessun allenamento registrato oggi")
        except Exception as e:
            st.error(f"Errore nel caricamento dati: {str(e)}")
    
    # Main content area
    col1, col2, col3 = st.columns([2, 2, 1])
    
    with col1:
        st.subheader("🎯 Obiettivi Attuali")
        try:
            current_goals = data_analysis_service.get_current_goals()
            if current_goals:
                for goal in current_goals:
                    progress = goal.get('progress', 0)
                    st.progress(progress / 100, text=f"{goal['name']}: {progress}%")
            else:
                st.info("Configura i tuoi obiettivi nella sezione Training Calendar")
        except Exception as e:
            st.error(f"Errore nel caricamento obiettivi: {str(e)}")
    
    with col2:
        st.subheader("📈 Tendenza Settimanale")
        try:
            weekly_data = data_analysis_service.get_weekly_trend()
            if weekly_data and not weekly_data.empty:
                fig = px.line(
                    weekly_data, 
                    x='date', 
                    y='training_load',
                    title="Training Load - Ultimi 7 giorni"
                )
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Dati insufficienti per il grafico settimanale")
        except Exception as e:
            st.error(f"Errore nel caricamento trend: {str(e)}")
    
    with col3:
        st.subheader("⚡ Azioni Rapide")
        
        if st.button("🔄 Sincronizza Garmin", use_container_width=True):
            with st.spinner("Sincronizzazione in corso..."):
                try:
                    result = garmin_service.sync_latest_activities()
                    if result:
                        st.success("✅ Sincronizzazione completata")
                        st.rerun()
                    else:
                        st.error("❌ Errore nella sincronizzazione")
                except Exception as e:
                    st.error(f"Errore: {str(e)}")
        
        if st.button("📝 Aggiungi Allenamento", use_container_width=True):
            st.switch_page("pages/2_Training_Calendar.py")
        
        if st.button("🍎 Log Nutrizione", use_container_width=True):
            st.switch_page("pages/4_Nutrition_Tracking.py")
        
        if st.button("🦵 Riabilitazione", use_container_width=True):
            st.switch_page("pages/8_Knee_Rehabilitation.py")
    
    # Recent activities section
    st.divider()
    st.subheader("🏃‍♂️ Attività Recenti")
    
    try:
        recent_activities = garmin_service.get_recent_activities(limit=5)
        if recent_activities and not recent_activities.empty:
            # Display recent activities in a clean table
            display_cols = ['date', 'activity_type', 'distance', 'duration', 'avg_heart_rate']
            if all(col in recent_activities.columns for col in display_cols):
                st.dataframe(
                    recent_activities[display_cols],
                    use_container_width=True,
                    hide_index=True
                )
            else:
                st.dataframe(recent_activities, use_container_width=True, hide_index=True)
        else:
            st.info("Nessuna attività recente trovata. Sincronizza i dati da Garmin Connect.")
    except Exception as e:
        st.error(f"Errore nel caricamento attività recenti: {str(e)}")
    
    # Footer with inspirational quote
    st.divider()
    quotes = [
        "\"The miracle isn't that I finished. The miracle is that I had the courage to start.\" - John Bingham",
        "\"Run when you have to, walk if you have to, crawl if you have to; just never give up.\" - Dean Karnazes",
        "\"The obsession with running is really an obsession with the potential for more and more life.\" - George Sheehan"
    ]
    import random
    st.markdown(f"*{random.choice(quotes)}*")

if __name__ == "__main__":
    main()
