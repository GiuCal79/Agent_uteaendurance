import pandas as pd
import numpy as np
from datetime import datetime, timedelta, time
from typing import Union, List, Dict, Optional, Tuple
import streamlit as st

def format_duration(seconds: Union[int, float]) -> str:
    """Format duration in seconds to human readable format"""
    if pd.isna(seconds) or seconds == 0:
        return "0:00"
    
    try:
        seconds = int(seconds)
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        remaining_seconds = seconds % 60
        
        if hours > 0:
            return f"{hours}:{minutes:02d}:{remaining_seconds:02d}"
        else:
            return f"{minutes}:{remaining_seconds:02d}"
    except (ValueError, TypeError):
        return "0:00"

def calculate_pace(distance_km: float, duration_seconds: float) -> float:
    """Calculate pace in minutes per kilometer"""
    if distance_km == 0 or duration_seconds == 0:
        return 0.0
    
    try:
        pace_seconds_per_km = duration_seconds / distance_km
        pace_minutes_per_km = pace_seconds_per_km / 60
        return round(pace_minutes_per_km, 2)
    except (ValueError, TypeError, ZeroDivisionError):
        return 0.0

def format_pace(pace_min_per_km: float) -> str:
    """Format pace to MM:SS format"""
    if pd.isna(pace_min_per_km) or pace_min_per_km == 0:
        return "0:00"
    
    try:
        minutes = int(pace_min_per_km)
        seconds = int((pace_min_per_km - minutes) * 60)
        return f"{minutes}:{seconds:02d}"
    except (ValueError, TypeError):
        return "0:00"

def calculate_training_load(distance: float, duration: float, avg_hr: Optional[float] = None, 
                          intensity_factor: float = 1.0) -> float:
    """Calculate training load for a workout"""
    if distance == 0 and duration == 0:
        return 0.0
    
    try:
        # Base load calculation
        base_load = (distance * 10) + (duration / 3600 * 50)  # Distance factor + time factor
        
        # Heart rate adjustment
        if avg_hr and avg_hr > 0:
            # Assuming max HR of 190 and zones
            hr_factor = min(avg_hr / 170, 1.5)  # Cap at 1.5x
            base_load *= hr_factor
        
        # Intensity adjustment
        base_load *= intensity_factor
        
        return round(base_load, 1)
    except (ValueError, TypeError):
        return 0.0

def calculate_zones(heart_rates: Union[List[float], pd.Series], max_hr: int = 190) -> List[str]:
    """Calculate heart rate zones for a list of heart rates"""
    zones = []
    
    for hr in heart_rates:
        if pd.isna(hr) or hr == 0:
            zones.append("Unknown")
            continue
        
        try:
            hr_percentage = hr / max_hr
            
            if hr_percentage < 0.6:
                zones.append("Zone 1 (Recovery)")
            elif hr_percentage < 0.7:
                zones.append("Zone 2 (Aerobic)")
            elif hr_percentage < 0.8:
                zones.append("Zone 3 (Tempo)")
            elif hr_percentage < 0.9:
                zones.append("Zone 4 (Threshold)")
            else:
                zones.append("Zone 5 (VO2max)")
        except (ValueError, TypeError):
            zones.append("Unknown")
    
    return zones

def calculate_weekly_volume(activities_df: pd.DataFrame) -> Dict[str, float]:
    """Calculate weekly training volume statistics"""
    if activities_df.empty:
        return {'total_distance': 0, 'total_time': 0, 'avg_pace': 0, 'workouts': 0}
    
    try:
        # Ensure date column is datetime
        activities_df['date'] = pd.to_datetime(activities_df['date'])
        
        # Get current week
        current_week = datetime.now().isocalendar().week
        current_year = datetime.now().year
        
        week_data = activities_df[
            (activities_df['date'].dt.isocalendar().week == current_week) &
            (activities_df['date'].dt.year == current_year)
        ]
        
        return {
            'total_distance': week_data['distance'].sum(),
            'total_time': week_data['duration'].sum(),
            'avg_pace': week_data['avg_pace'].mean() if 'avg_pace' in week_data.columns else 0,
            'workouts': len(week_data)
        }
    except Exception:
        return {'total_distance': 0, 'total_time': 0, 'avg_pace': 0, 'workouts': 0}

def calculate_moving_average(data: Union[List[float], pd.Series], window: int = 7) -> List[float]:
    """Calculate moving average for a dataset"""
    if len(data) < window:
        return list(data)
    
    try:
        if isinstance(data, list):
            data = pd.Series(data)
        
        moving_avg = data.rolling(window=window, min_periods=1).mean()
        return moving_avg.tolist()
    except Exception:
        return list(data) if isinstance(data, list) else data.tolist()

def estimate_vo2_max(recent_activities: pd.DataFrame) -> float:
    """Estimate VO2 max based on recent running activities"""
    if recent_activities.empty:
        return 0.0
    
    try:
        # Filter running activities
        running_data = recent_activities[
            (recent_activities['activity_type'] == 'Running') &
            (recent_activities['distance'] >= 3)  # At least 3km runs
        ]
        
        if running_data.empty:
            return 0.0
        
        # Use Jack Daniels' formula (simplified)
        # VO2 max ≈ 15.3 × (mile time in minutes)^-1
        avg_pace = running_data['avg_pace'].mean()  # min/km
        
        if avg_pace > 0:
            mile_time = avg_pace * 1.609  # Convert to min/mile
            vo2_max = 15.3 / (mile_time / 60)  # Convert to VO2 max approximation
            return round(min(vo2_max * 10, 80), 1)  # Cap at realistic values
        
        return 0.0
    except Exception:
        return 0.0

def calculate_fitness_score(activities_df: pd.DataFrame, days: int = 42) -> float:
    """Calculate fitness score based on training load and consistency"""
    if activities_df.empty:
        return 0.0
    
    try:
        # Filter recent activities
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_activities = activities_df[
            pd.to_datetime(activities_df['date']) >= cutoff_date
        ]
        
        if recent_activities.empty:
            return 0.0
        
        # Calculate components
        total_load = sum(
            calculate_training_load(row['distance'], row['duration'], row.get('avg_heart_rate'))
            for _, row in recent_activities.iterrows()
        )
        
        # Consistency factor (training days / total days)
        training_days = len(recent_activities)
        consistency = min(training_days / days, 1.0)
        
        # Base fitness score
        base_score = (total_load / days) * 10  # Normalize
        fitness_score = base_score * (0.7 + 0.3 * consistency)  # Weight consistency
        
        return round(min(fitness_score, 100), 1)  # Cap at 100
    except Exception:
        return 0.0

def get_recovery_recommendation(training_load: float, last_rest_days: int) -> str:
    """Get recovery recommendation based on training load and rest days"""
    try:
        if training_load > 150 and last_rest_days < 1:
            return "Alto carico - riposo necessario"
        elif training_load > 100 and last_rest_days < 2:
            return "Considera riposo attivo"
        elif training_load < 50:
            return "Carico leggero - puoi aumentare intensità"
        else:
            return "Carico bilanciato - continua così"
    except Exception:
        return "Dati insufficienti"

def calculate_race_prediction(recent_activities: pd.DataFrame, target_distance: float) -> Dict[str, float]:
    """Predict race time based on recent training"""
    if recent_activities.empty:
        return {'predicted_time': 0, 'predicted_pace': 0, 'confidence': 0}
    
    try:
        # Filter relevant activities
        relevant_activities = recent_activities[
            (recent_activities['activity_type'] == 'Running') &
            (recent_activities['distance'] >= target_distance * 0.5)  # At least half the race distance
        ].tail(10)  # Last 10 relevant activities
        
        if relevant_activities.empty:
            return {'predicted_time': 0, 'predicted_pace': 0, 'confidence': 0}
        
        # Calculate average pace
        avg_pace = relevant_activities['avg_pace'].mean()
        
        # Adjust for race distance (longer races = slower pace)
        if target_distance <= 5:
            race_pace = avg_pace * 0.98  # Slightly faster for 5K
        elif target_distance <= 10:
            race_pace = avg_pace * 1.00  # Same pace for 10K
        elif target_distance <= 21:
            race_pace = avg_pace * 1.05  # Slower for half marathon
        else:
            race_pace = avg_pace * 1.15  # Much slower for marathon
        
        predicted_time = target_distance * race_pace * 60  # Convert to seconds
        confidence = min(len(relevant_activities) / 10, 1.0)  # More data = higher confidence
        
        return {
            'predicted_time': predicted_time,
            'predicted_pace': race_pace,
            'confidence': confidence
        }
    except Exception:
        return {'predicted_time': 0, 'predicted_pace': 0, 'confidence': 0}

def format_time_seconds(seconds: float) -> str:
    """Format time in seconds to HH:MM:SS"""
    if pd.isna(seconds) or seconds == 0:
        return "0:00:00"
    
    try:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        return f"{hours}:{minutes:02d}:{secs:02d}"
    except (ValueError, TypeError):
        return "0:00:00"

def calculate_calories_burned(distance_km: float, weight_kg: float = 70, 
                            activity_type: str = 'Running') -> float:
    """Estimate calories burned based on distance and activity type"""
    if distance_km == 0:
        return 0.0
    
    try:
        # MET values for different activities
        met_values = {
            'Running': 10.0,
            'Cycling': 8.0,
            'Swimming': 8.0,
            'Walking': 3.5,
            'Hiking': 6.0
        }
        
        met = met_values.get(activity_type, 8.0)
        
        # Calories = MET × weight (kg) × time (hours)
        # Approximate time based on distance and average speeds
        average_speeds = {
            'Running': 10,     # km/h
            'Cycling': 25,     # km/h
            'Swimming': 3,     # km/h
            'Walking': 5,      # km/h
            'Hiking': 4        # km/h
        }
        
        speed = average_speeds.get(activity_type, 10)
        time_hours = distance_km / speed
        
        calories = met * weight_kg * time_hours
        return round(calories, 0)
    except Exception:
        return 0.0

def get_weather_recommendation(temperature: float, conditions: str = "clear") -> str:
    """Get training recommendations based on weather"""
    try:
        recommendations = []
        
        if temperature < 0:
            recommendations.append("Molto freddo - riscaldamento prolungato necessario")
        elif temperature < 10:
            recommendations.append("Freddo - vestiti a strati")
        elif temperature > 25:
            recommendations.append("Caldo - idratazione extra necessaria")
        elif temperature > 30:
            recommendations.append("Molto caldo - evita le ore centrali")
        
        if conditions.lower() in ['rain', 'pioggia']:
            recommendations.append("Pioggia - attenzione alla sicurezza")
        elif conditions.lower() in ['snow', 'neve']:
            recommendations.append("Neve - considera allenamento indoor")
        elif conditions.lower() in ['wind', 'vento']:
            recommendations.append("Vento - regola l'intensità di conseguenza")
        
        return "; ".join(recommendations) if recommendations else "Condizioni ideali per allenarsi"
    except Exception:
        return "Condizioni non disponibili"

def calculate_training_stress_score(duration_seconds: float, intensity_factor: float = 0.7) -> float:
    """Calculate Training Stress Score (TSS)"""
    if duration_seconds == 0:
        return 0.0
    
    try:
        duration_hours = duration_seconds / 3600
        tss = duration_hours * intensity_factor * intensity_factor * 100
        return round(tss, 1)
    except Exception:
        return 0.0

def get_periodization_phase(activities_df: pd.DataFrame) -> str:
    """Determine current training periodization phase"""
    if activities_df.empty:
        return "Base Building"
    
    try:
        # Analyze last 4 weeks of training
        last_month = activities_df[
            pd.to_datetime(activities_df['date']) >= datetime.now() - timedelta(days=28)
        ]
        
        if last_month.empty:
            return "Base Building"
        
        # Calculate intensity distribution
        total_time = last_month['duration'].sum()
        if total_time == 0:
            return "Base Building"
        
        # Simple heuristic based on training patterns
        avg_weekly_volume = last_month['distance'].sum() / 4
        high_intensity_workouts = len(last_month[last_month['avg_heart_rate'] > 160]) if 'avg_heart_rate' in last_month.columns else 0
        
        if avg_weekly_volume > 80 and high_intensity_workouts > 4:
            return "Peak Phase"
        elif avg_weekly_volume > 60 and high_intensity_workouts > 2:
            return "Build Phase"
        elif avg_weekly_volume < 30:
            return "Recovery/Taper"
        else:
            return "Base Building"
    except Exception:
        return "Base Building"

def validate_activity_data(activity_data: Dict) -> Tuple[bool, List[str]]:
    """Validate activity data for completeness and correctness"""
    errors = []
    
    try:
        # Required fields
        required_fields = ['date', 'activity_type', 'duration']
        for field in required_fields:
            if field not in activity_data or not activity_data[field]:
                errors.append(f"Campo obbligatorio mancante: {field}")
        
        # Data validation
        if 'distance' in activity_data and activity_data['distance'] < 0:
            errors.append("La distanza non può essere negativa")
        
        if 'duration' in activity_data and activity_data['duration'] <= 0:
            errors.append("La durata deve essere maggiore di zero")
        
        if 'avg_heart_rate' in activity_data and activity_data['avg_heart_rate']:
            hr = activity_data['avg_heart_rate']
            if hr < 40 or hr > 220:
                errors.append("Frequenza cardiaca fuori range normale (40-220 bpm)")
        
        # Date validation
        if 'date' in activity_data:
            try:
                activity_date = pd.to_datetime(activity_data['date'])
                if activity_date > datetime.now():
                    errors.append("La data non può essere nel futuro")
            except Exception:
                errors.append("Formato data non valido")
        
        return len(errors) == 0, errors
    except Exception as e:
        return False, [f"Errore nella validazione: {str(e)}"]

def generate_training_zones(threshold_hr: int, max_hr: int = None) -> Dict[str, Dict[str, int]]:
    """Generate heart rate training zones"""
    if max_hr is None:
        max_hr = min(220 - 25, threshold_hr + 30)  # Estimate if not provided
    
    try:
        zones = {
            'Zone 1 (Recovery)': {
                'min_hr': int(max_hr * 0.50),
                'max_hr': int(max_hr * 0.60),
                'description': 'Recupero attivo, conversazione facile'
            },
            'Zone 2 (Aerobic)': {
                'min_hr': int(max_hr * 0.60),
                'max_hr': int(max_hr * 0.70),
                'description': 'Base aerobica, ritmo confortevole'
            },
            'Zone 3 (Tempo)': {
                'min_hr': int(max_hr * 0.70),
                'max_hr': int(max_hr * 0.80),
                'description': 'Ritmo tempo, comfortably hard'
            },
            'Zone 4 (Threshold)': {
                'min_hr': int(max_hr * 0.80),
                'max_hr': int(max_hr * 0.90),
                'description': 'Soglia anaerobica, molto impegnativo'
            },
            'Zone 5 (VO2max)': {
                'min_hr': int(max_hr * 0.90),
                'max_hr': max_hr,
                'description': 'Massimo consumo ossigeno, insostenibile'
            }
        }
        
        return zones
    except Exception:
        return {}

def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Safely divide two numbers, returning default if division by zero"""
    try:
        if denominator == 0:
            return default
        return numerator / denominator
    except (TypeError, ValueError):
        return default

def safe_mean(values: Union[List[float], pd.Series], default: float = 0.0) -> float:
    """Safely calculate mean, handling empty lists and NaN values"""
    try:
        if isinstance(values, list):
            values = pd.Series(values)
        
        clean_values = values.dropna()
        if len(clean_values) == 0:
            return default
        
        return clean_values.mean()
    except Exception:
        return default
