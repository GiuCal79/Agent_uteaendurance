ATHLETE_PROFILES = {
    "Rich Roll": {
        "specialty": "Ultra-endurance, Plant-based nutrition advocate",
        "nationality": "USA",
        "age": 57,
        "career_years": 15,
        "major_achievements": [
            "Ultraman World Championship finisher",
            "Epic5 Challenge (5 Ironman races, 5 Hawaiian islands, 5 days)",
            "Author of 'Finding Ultra'",
            "Top wellness podcast host",
            "Plant-based nutrition pioneer in endurance sports"
        ],
        "philosophy": "Redefining what's possible through plant-powered performance and mindful living",
        "key_stats": {
            "VO2 Max": "65+ ml/kg/min",
            "Weekly Volume": "25-30 hours",
            "Career Races": "50+ ultra events",
            "Plant-based": "12+ years"
        },
        "performance_metrics": {
            "vo2_max": 65,
            "threshold_pace": 3.45,  # min/km
            "marathon_pb": "2:45:00",
            "ironman_pb": "8:45:00"
        },
        "training_metrics": {
            "weekly_volume_km": 120,
            "weekly_hours": 28,
            "swimming_weekly": "15 km",
            "cycling_weekly": "400 km"
        },
        "training_methodology": {
            "structure": {
                "periodization": "Block periodization with emphasis on aerobic development",
                "weekly_structure": "6 days training, 1 complete rest",
                "daily_sessions": "Often 2 sessions per day",
                "season_planning": "Year-round training with peak events"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 75,
                "Zone 3 (Tempo)": 15,
                "Zone 4-5 (Hard)": 10
            },
            "key_principles": [
                "Consistent aerobic base building",
                "Progressive overload with adequate recovery",
                "Mental training and mindfulness practice",
                "Holistic approach to health and performance",
                "Plant-based nutrition optimization"
            ]
        },
        "nutrition_approach": {
            "philosophy": "100% plant-based whole foods",
            "pre_workout": "Dates, bananas, plant-based smoothies",
            "during_workout": "Coconut water, dates, plant-based sports drinks",
            "post_workout": "Plant protein smoothie with greens",
            "daily_structure": "Nutrient-dense whole foods, no processed foods"
        },
        "mental_approach": {
            "meditation": "Daily meditation practice, 20+ minutes",
            "visualization": "Mental rehearsal of races and challenging situations",
            "mindfulness": "Present-moment awareness during training",
            "purpose_driven": "Training and racing with deeper meaning and impact"
        },
        "signature_workouts": [
            {
                "name": "Aerobic Power Build",
                "type": "Swimming + Running",
                "duration": "3 hours",
                "purpose": "Aerobic capacity and multi-sport fitness",
                "structure": [
                    "45min easy swim",
                    "15min transition/prep",
                    "2h progressive run (starting easy, building to tempo)"
                ],
                "benefits": ["Aerobic development", "Multi-sport coordination", "Mental toughness"],
                "notes": "Focus on smooth transitions and maintaining form throughout"
            },
            {
                "name": "Endurance Brick",
                "type": "Cycling + Running",
                "duration": "4-5 hours",
                "purpose": "Race-specific endurance and brick training",
                "structure": [
                    "3h steady cycling (Zone 2 with Zone 3 surges)",
                    "Quick transition",
                    "60-90min run off the bike (negative split)"
                ],
                "benefits": ["Race simulation", "Metabolic efficiency", "Mental resilience"],
                "notes": "Practice nutrition and hydration strategies"
            }
        ],
        "inspirational_quotes": [
            "The journey is the destination",
            "Progress, not perfection",
            "Plants fuel champions",
            "Age is just a number - fitness is the fountain of youth",
            "Inspiration is the most sustainable fuel"
        ],
        "equipment": {
            "running": ["Minimal drop shoes", "Hydration vest", "GPS watch"],
            "cycling": ["Time trial bike", "Power meter", "Aero setup"],
            "swimming": ["Wetsuit", "Goggles", "Pool tools"],
            "recovery": ["Foam roller", "Massage tools", "Meditation apps"]
        },
        "recommended_resources": {
            "books": [
                "Finding Ultra by Rich Roll",
                "The Plantpower Way",
                "Breath by James Nestor"
            ],
            "documentaries": [
                "The Game Changers",
                "Forks Over Knives",
                "Rich Roll podcast episodes"
            ]
        }
    },
    
    "Christoph Strasser": {
        "specialty": "Ultra-cycling, Race Across America champion",
        "nationality": "Austria",
        "age": 41,
        "career_years": 20,
        "major_achievements": [
            "4x Race Across America (RAAM) winner",
            "Multiple ultra-cycling world records",
            "24-hour cycling world record: 941.873 km",
            "Longest distance in 7 days: 5,615 km",
            "Red Bull Trans-Siberian Extreme winner"
        ],
        "philosophy": "Mental strength and systematic preparation conquer all physical barriers",
        "key_stats": {
            "24h Distance": "941 km",
            "RAAM Wins": "4 times",
            "Weekly Volume": "800+ km",
            "Sleep/Day": "3-4 hours"
        },
        "performance_metrics": {
            "vo2_max": 75,
            "threshold_pace": 3.20,  # min/km running equivalent
            "ftp_watts": 380,
            "power_to_weight": 5.2
        },
        "training_metrics": {
            "weekly_volume_km": 800,
            "weekly_hours": 35,
            "running_weekly": "50 km",
            "cycling_weekly": "750 km"
        },
        "training_methodology": {
            "structure": {
                "periodization": "High volume base with race-specific blocks",
                "weekly_structure": "7 days training, structured recovery",
                "daily_sessions": "2-3 sessions daily during peak periods",
                "season_planning": "Built around major ultra-cycling events"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 85,
                "Zone 3 (Tempo)": 10,
                "Zone 4-5 (Hard)": 5
            },
            "key_principles": [
                "Extreme volume tolerance development",
                "Sleep deprivation training",
                "Mental resilience building",
                "Systematic approach to marginal gains",
                "Precision in nutrition and hydration"
            ]
        },
        "nutrition_approach": {
            "philosophy": "Precision nutrition for extreme endurance",
            "pre_workout": "Oatmeal, banana, coffee",
            "during_workout": "Liquid nutrition every 20-30min, solid food every 2h",
            "post_workout": "Protein and carbohydrate recovery drink",
            "daily_structure": "High carbohydrate, moderate protein, strategic fats"
        },
        "mental_approach": {
            "sleep_deprivation": "Training with minimal sleep to adapt",
            "pain_management": "Systematic approach to discomfort tolerance",
            "focus_techniques": "Segmented goal setting during ultra events",
            "motivation": "Precise planning eliminates doubt"
        },
        "signature_workouts": [
            {
                "name": "RAAM Simulation",
                "type": "Cycling",
                "duration": "20+ hours",
                "purpose": "Race simulation and sleep deprivation adaptation",
                "structure": [
                    "Start early morning with normal sleep",
                    "20+ hours continuous cycling",
                    "Nutrition every 30min",
                    "No more than 10min stops"
                ],
                "benefits": ["Sleep deprivation adaptation", "Nutrition practice", "Mental toughness"],
                "notes": "Practice exact race nutrition and position changes"
            },
            {
                "name": "Volume Block",
                "type": "Mixed",
                "duration": "6-8 hours daily x 7 days",
                "purpose": "Volume tolerance and aerobic development",
                "structure": [
                    "Long cycling sessions 4-6h",
                    "Running 1-2h daily",
                    "Swimming or rowing 30-45min",
                    "Strength training 30min"
                ],
                "benefits": ["Volume tolerance", "Aerobic power", "Recovery adaptation"],
                "notes": "Focus on maintaining form under fatigue"
            }
        ],
        "inspirational_quotes": [
            "Pain is temporary, quitting lasts forever",
            "The mind gives up before the body",
            "Preparation eliminates fear",
            "Every pedal stroke counts",
            "Sleep is overrated when chasing dreams"
        ],
        "equipment": {
            "cycling": ["Aero time trial bike", "Power meter", "Aerobars", "Multiple wheelsets"],
            "nutrition": ["Liquid nutrition system", "Precision scales", "Supplements"],
            "recovery": ["Compression gear", "Sleep optimization tools"],
            "tracking": ["GPS computers", "Heart rate monitors", "Power analysis software"]
        },
        "recommended_resources": {
            "books": [
                "The Art of Mental Training",
                "Training and Racing with a Power Meter",
                "Endure by Alex Hutchinson"
            ],
            "documentaries": [
                "Inspired to Ride",
                "Race Across America documentaries",
                "Ultra-cycling films"
            ]
        }
    },
    
    "Jonas Deichmann": {
        "specialty": "Extreme adventure, Triathlon world record holder",
        "nationality": "Germany", 
        "age": 36,
        "career_years": 12,
        "major_achievements": [
            "120 Ironman triathlons in 120 days world record",
            "Triathlon around the world (14 months)",
            "From Munich to Munich via both Capes project",
            "Multiple adventure world records",
            "Adventurer of the Year awards"
        ],
        "philosophy": "Push boundaries of human potential through systematic extreme challenges",
        "key_stats": {
            "Ironman Record": "120 in 120 days",
            "Days Around World": "430 days",
            "Distance Covered": "120,000+ km",
            "Sleep Average": "5-6 hours"
        },
        "performance_metrics": {
            "vo2_max": 72,
            "threshold_pace": 3.35,  # min/km
            "ironman_pb": "8:20:00",
            "marathon_pb": "2:38:00"
        },
        "training_metrics": {
            "weekly_volume_km": 200,
            "weekly_hours": 40,
            "swimming_weekly": "20 km",
            "cycling_weekly": "600 km",
            "running_weekly": "100 km"
        },
        "training_methodology": {
            "structure": {
                "periodization": "Continuous loading with micro-recovery periods",
                "weekly_structure": "Every day training, recovery through variation",
                "daily_sessions": "2-4 sessions per day",
                "season_planning": "Project-based with specific preparation phases"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 90,
                "Zone 3 (Tempo)": 8,
                "Zone 4-5 (Hard)": 2
            },
            "key_principles": [
                "Extreme volume adaptation",
                "Multi-sport efficiency",
                "Mental resilience through exposure",
                "Systematic risk management",
                "Continuous forward progress mindset"
            ]
        },
        "nutrition_approach": {
            "philosophy": "Flexible nutrition adapted to circumstances",
            "pre_workout": "Oats, fruits, coffee",
            "during_workout": "Mix of liquid and solid nutrition every 45min",
            "post_workout": "Recovery drink, real food within 2h",
            "daily_structure": "High volume eating, opportunistic nutrition"
        },
        "mental_approach": {
            "project_thinking": "Breaking impossible into manageable segments",
            "adversity_training": "Deliberately exposing to difficult conditions",
            "routine_building": "Creating structure in chaos",
            "forward_focus": "Always moving toward the next milestone"
        },
        "signature_workouts": [
            {
                "name": "Daily Ironman Simulation",
                "type": "Triathlon",
                "duration": "10-12 hours",
                "purpose": "Build tolerance for daily Ironman pace",
                "structure": [
                    "3.8km swim (open water when possible)",
                    "180km bike (varied terrain)",
                    "42.2km run (marathon pace)",
                    "Nutrition and transition practice"
                ],
                "benefits": ["Volume tolerance", "Multi-sport coordination", "Race pace endurance"],
                "notes": "Focus on sustainable pace that can be repeated daily"
            },
            {
                "name": "Adventure Endurance",
                "type": "Mixed terrain",
                "duration": "12-16 hours",
                "purpose": "Adaptation to variable conditions and long duration",
                "structure": [
                    "8-10h cycling (mixed terrain)",
                    "4-6h running/hiking",
                    "Include adverse weather when possible",
                    "Practice self-sufficiency"
                ],
                "benefits": ["Environmental adaptation", "Self-reliance", "Mental toughness"],
                "notes": "Vary conditions to simulate expedition challenges"
            }
        ],
        "inspirational_quotes": [
            "Impossible is just an opinion",
            "One step at a time, one day at a time",
            "The only limits are the ones we accept",
            "Adventure begins where comfort ends",
            "Every day is a gift to push further"
        ],
        "equipment": {
            "triathlon": ["TT bike", "Wetsuit", "GPS watches", "Power meter"],
            "adventure": ["Bikepacking gear", "Navigation tools", "Emergency equipment"],
            "nutrition": ["Portable nutrition", "Water purification", "Cooking equipment"],
            "safety": ["Communication devices", "First aid", "Weather protection"]
        },
        "recommended_resources": {
            "books": [
                "Limits are in your head",
                "Born to Run by Christopher McDougall",
                "Endurance by Alfred Lansing"
            ],
            "documentaries": [
                "The Impossible Triathlon",
                "Around the World in 430 Days",
                "Expedition documentaries"
            ]
        }
    },
    
    "Ross Edgley": {
        "specialty": "Swimming marathons, Strongman endurance",
        "nationality": "United Kingdom",
        "age": 38,
        "career_years": 15,
        "major_achievements": [
            "First person to swim around Great Britain (1,792 miles)",
            "Strongman marathon world record",
            "Tree marathon (26.2 miles carrying a tree)",
            "Rope climb marathon world record",
            "World's Fittest Book author"
        ],
        "philosophy": "Strength and endurance are not mutually exclusive - forge both for ultimate human performance",
        "key_stats": {
            "GB Swim": "1,792 miles",
            "Swim Days": "157 days",
            "Strongman Marathon": "4:28:00",
            "Body Fat": "10-12%"
        },
        "performance_metrics": {
            "vo2_max": 68,
            "threshold_pace": 3.55,  # min/km
            "marathon_pb": "2:55:00",
            "deadlift": "300+ kg"
        },
        "training_metrics": {
            "weekly_volume_km": 80,
            "weekly_hours": 25,
            "swimming_weekly": "40 km",
            "running_weekly": "60 km",
            "strength_sessions": "4-5 per week"
        },
        "training_methodology": {
            "structure": {
                "periodization": "Concurrent training - strength and endurance together",
                "weekly_structure": "7 day rotation with varied emphasis",
                "daily_sessions": "2-3 sessions per day",
                "season_planning": "Event-specific with baseline strength maintenance"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 70,
                "Zone 3 (Tempo)": 20,
                "Zone 4-5 (Hard)": 10
            },
            "key_principles": [
                "Stoic philosophy applied to training",
                "Progressive overload in all domains",
                "Sport science meets ancient wisdom",
                "Mental resilience through physical challenge",
                "Adaptation through varied stressors"
            ]
        },
        "nutrition_approach": {
            "philosophy": "Fuel for performance and recovery",
            "pre_workout": "Oats, banana, coffee, sometimes fasted training",
            "during_workout": "Electrolytes, carbohydrates for sessions >2h",
            "post_workout": "Protein and carbs within 30min",
            "daily_structure": "Whole foods, adequate protein, strategic carbohydrates"
        },
        "mental_approach": {
            "stoicism": "Ancient stoic principles for modern challenges",
            "segmentation": "Breaking massive challenges into manageable parts",
            "discomfort_training": "Deliberately seeking difficult conditions",
            "purpose_driven": "Training with clear mission and meaning"
        },
        "signature_workouts": [
            {
                "name": "Strongman Endurance",
                "type": "Strength + Running",
                "duration": "2-3 hours",
                "purpose": "Build concurrent strength and endurance capacity",
                "structure": [
                    "1h strength training (compound movements)",
                    "15min transition/prep",
                    "90min progressive run",
                    "Focus on maintaining form under fatigue"
                ],
                "benefits": ["Concurrent adaptation", "Mental toughness", "Unique fitness"],
                "notes": "Start with lighter weights and shorter runs, progress gradually"
            },
            {
                "name": "Open Water Marathon",
                "type": "Swimming",
                "duration": "6-10 hours",
                "purpose": "Build swimming endurance and mental resilience",
                "structure": [
                    "Continuous swimming",
                    "Feeding every 30-45min",
                    "Vary stroke and breathing patterns",
                    "Practice in various conditions"
                ],
                "benefits": ["Swimming endurance", "Mental resilience", "Fueling practice"],
                "notes": "Build up distance gradually, practice cold water adaptation"
            }
        ],
        "inspirational_quotes": [
            "Comfort is the enemy of progress",
            "The body achieves what the mind believes",
            "Strong body, strong mind, strong character",
            "Every workout is a deposit in your resilience account",
            "Pain is temporary, quitting lasts forever"
        ],
        "equipment": {
            "swimming": ["Wetsuit", "Goggles", "GPS watch", "Feeding equipment"],
            "strength": ["Barbells", "Kettlebells", "Resistance bands", "TRX"],
            "running": ["Trail shoes", "Road shoes", "Hydration pack"],
            "recovery": ["Ice bath", "Compression gear", "Massage tools"]
        },
        "recommended_resources": {
            "books": [
                "The World's Fittest Book",
                "The Art of Resilience", 
                "Meditations by Marcus Aurelius"
            ],
            "documentaries": [
                "The Great British Swim",
                "Strongman documentaries",
                "Adventure swimming films"
            ]
        }
    },
    
    "Kilian Jornet": {
        "specialty": "Skyrunning, Mountain ultra-running",
        "nationality": "Spain",
        "age": 36,
        "career_years": 20,
        "major_achievements": [
            "Multiple Skyrunning World Champion",
            "UTMB winner multiple times",
            "Fastest known times on major peaks",
            "Summits of My Life project completion",
            "Mount Everest speed ascent (twice in one week)"
        ],
        "philosophy": "Mountains teach us humility, patience, and the beauty of simple movement",
        "key_stats": {
            "UTMB Wins": "3 times",
            "Everest Ascent": "26 hours",
            "Weekly Elevation": "10,000+ m",
            "VO2 Max": "89.5 ml/kg/min"
        },
        "performance_metrics": {
            "vo2_max": 89.5,
            "threshold_pace": 3.10,  # min/km on flat
            "marathon_pb": "2:21:00",
            "uphill_speed": "1000m/h sustained"
        },
        "training_metrics": {
            "weekly_volume_km": 150,
            "weekly_hours": 25,
            "elevation_gain": "10000",
            "running_weekly": "140 km",
            "skiing_weekly": "50 km (winter)"
        },
        "training_methodology": {
            "structure": {
                "periodization": "Natural periodization following mountain seasons",
                "weekly_structure": "Daily training, rest through easy days",
                "daily_sessions": "1-2 sessions, often single long efforts",
                "season_planning": "Summer racing, winter ski mountaineering"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 80,
                "Zone 3 (Tempo)": 15,
                "Zone 4-5 (Hard)": 5
            },
            "key_principles": [
                "Train in the environment you'll race in",
                "Listen to your body and the mountains",
                "Quality over quantity",
                "Mental training through exposure",
                "Respect for nature and limits"
            ]
        },
        "nutrition_approach": {
            "philosophy": "Simple, natural foods that fuel mountain adventures",
            "pre_workout": "Oats, honey, coffee",
            "during_workout": "Dates, nuts, energy gels for long efforts",
            "post_workout": "Recovery drink, then real food",
            "daily_structure": "Mediterranean diet, lots of vegetables and fruits"
        },
        "mental_approach": {
            "mountain_wisdom": "Learning patience and reading conditions",
            "risk_assessment": "Constantly evaluating mountain safety",
            "flow_state": "Finding rhythm in challenging terrain",
            "environmental_connection": "Deep respect and connection to nature"
        },
        "signature_workouts": [
            {
                "name": "Vertical Kilometer",
                "type": "Mountain running",
                "duration": "45-60 minutes",
                "purpose": "Build vertical climbing power and efficiency",
                "structure": [
                    "Steep uphill running/hiking",
                    "1000m elevation gain",
                    "Maintain steady effort",
                    "Focus on efficient movement"
                ],
                "benefits": ["Climbing power", "Movement efficiency", "Mental toughness"],
                "notes": "Start conservatively, build to race effort over time"
            },
            {
                "name": "Alpine Long Run",
                "type": "Mountain endurance",
                "duration": "4-8 hours",
                "purpose": "Build mountain endurance and navigation skills",
                "structure": [
                    "Long mountain route",
                    "Varied terrain and elevation",
                    "Self-sufficient approach",
                    "Weather adaptation"
                ],
                "benefits": ["Mountain endurance", "Technical skills", "Mental resilience"],
                "notes": "Carry minimal safety gear, practice fueling strategies"
            }
        ],
        "inspirational_quotes": [
            "The mountains are calling and I must go",
            "It's not about the summit, it's about the journey",
            "Run simple, run free",
            "The mountain doesn't care about your ego",
            "Sometimes you fly, sometimes you fall, both teach you"
        ],
        "equipment": {
            "running": ["Trail shoes", "Minimal gear", "Lightweight pack", "GPS watch"],
            "mountaineering": ["Mountaineering boots", "Crampons", "Ice axe", "Helmet"],
            "safety": ["Emergency shelter", "First aid", "Communication device"],
            "nutrition": ["Lightweight food", "Water bottles", "Emergency food"]
        },
        "recommended_resources": {
            "books": [
                "The Invisible Border",
                "Above the Clouds",
                "Born to Run by Christopher McDougall"
            ],
            "documentaries": [
                "Summits of My Life series",
                "Path to Everest",
                "Skyrunning documentaries"
            ]
        }
    },
    
    "Yiannis Kouros": {
        "specialty": "Ultra-marathon legend, Multi-day racing",
        "nationality": "Greece",
        "age": 67,
        "career_years": 40,
        "major_achievements": [
            "Spartathlon winner 4 times",
            "1000-mile world record: 10 days, 10:30:36",
            "Multiple world records from 6 hours to 6 days",
            "Sydney to Melbourne world record: 5 days, 5:07:28",
            "Over 400 ultra-marathon victories"
        ],
        "philosophy": "The ancient Greek ideal of harmony between body, mind, and spirit in endless motion",
        "key_stats": {
            "1000 Mile Record": "10 days, 10h 30min",
            "Spartathlon Wins": "4 times",
            "World Records": "25+ current records",
            "Career Span": "40+ years"
        },
        "performance_metrics": {
            "vo2_max": 72,
            "threshold_pace": 3.25,  # min/km
            "marathon_pb": "2:13:03",
            "100km_pb": "6:17:00"
        },
        "training_metrics": {
            "weekly_volume_km": 200,
            "weekly_hours": 30,
            "daily_runs": "2-3 per day",
            "running_weekly": "200 km",
            "long_runs": "50+ km regularly"
        },
        "training_methodology": {
            "structure": {
                "periodization": "High volume year-round with race-specific preparation",
                "weekly_structure": "Daily training, no complete rest days",
                "daily_sessions": "2-3 runs per day",
                "season_planning": "Race calendar drives training focus"
            },
            "intensity_distribution": {
                "Zone 1-2 (Easy)": 85,
                "Zone 3 (Tempo)": 12,
                "Zone 4-5 (Hard)": 3
            },
            "key_principles": [
                "Massive volume tolerance",
                "Greek philosophical approach to suffering",
                "Mental transcendence through running",
                "Simplicity in training methods",
                "Deep understanding of pacing and rhythm"
            ]
        },
        "nutrition_approach": {
            "philosophy": "Traditional Mediterranean diet with race-specific fueling",
            "pre_workout": "Light breakfast, coffee",
            "during_workout": "Simple carbohydrates, electrolytes, real food",
            "post_workout": "Traditional Greek foods, emphasis on recovery",
            "daily_structure": "Fresh vegetables, olive oil, fish, minimal processed foods"
        },
        "mental_approach": {
            "greek_philosophy": "Ancient stoicism applied to modern ultra-running",
            "mental_transcendence": "Moving beyond physical limitations through mental discipline",
            "rhythm_finding": "Discovering sustainable pace and maintaining it",
            "suffering_acceptance": "Embracing discomfort as part of the journey"
        },
        "signature_workouts": [
            {
                "name": "Greek Volume Training",
                "type": "Multi-run day",
                "duration": "All day",
                "purpose": "Build massive volume tolerance",
                "structure": [
                    "Morning run: 30-40km easy pace",
                    "Midday run: 20-30km moderate",
                    "Evening run: 20-30km easy",
                    "Focus on consistent pacing"
                ],
                "benefits": ["Volume tolerance", "Recovery between efforts", "Mental endurance"],
                "notes": "Build up gradually, focus on maintaining form"
            },
            {
                "name": "Spartathlon Simulation",
                "type": "Ultra-marathon",
                "duration": "20+ hours",
                "purpose": "Race-specific preparation and pacing practice",
                "structure": [
                    "245km continuous running",
                    "Practice race nutrition every hour",
                    "Maintain target race pace",
                    "Include night running"
                ],
                "benefits": ["Race simulation", "Nutrition practice", "Mental preparation"],
                "notes": "Complete simulation including aid station stops"
            }
        ],
        "inspirational_quotes": [
            "My philosophy is that suffering is not the enemy",
            "The body can endure more than the mind believes",
            "Running is a form of meditation in motion",
            "Pain is temporary, glory is eternal",
            "The Greek spirit of ancient athletes lives in modern ultra-running"
        ],
        "equipment": {
            "running": ["Simple running shoes", "Minimal gear", "Traditional shorts"],
            "nutrition": ["Basic energy foods", "Electrolyte drinks", "Real food"],
            "timing": ["Simple watch", "No complex technology"],
            "weather": ["Basic weather protection", "Simple layers"]
        },
        "recommended_resources": {
            "books": [
                "The Road to Sparta by Dean Karnazes",
                "Ancient Greek athletic texts",
                "Philosophy of endurance"
            ],
            "documentaries": [
                "Spartathlon documentaries",
                "Greek ultra-running films",
                "Ancient Olympic Games"
            ]
        }
    }
}
