import sqlite3
import pandas as pd
import os
from datetime import datetime, date
from typing import Optional, Dict, List, Any, Union
import streamlit as st
import json

class DatabaseService:
    """Service for database operations and data persistence"""
    
    def __init__(self, db_path: str = "ultra_endurance.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database with required tables"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Activities table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS activities (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        activity_id TEXT UNIQUE,
                        date TEXT NOT NULL,
                        activity_type TEXT NOT NULL,
                        distance REAL DEFAULT 0,
                        duration INTEGER DEFAULT 0,
                        avg_heart_rate INTEGER,
                        max_heart_rate INTEGER,
                        calories INTEGER DEFAULT 0,
                        avg_pace REAL,
                        elevation_gain REAL DEFAULT 0,
                        activity_name TEXT,
                        notes TEXT,
                        perceived_effort INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Nutrition table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS nutrition (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        meal_type TEXT NOT NULL,
                        food_name TEXT NOT NULL,
                        quantity REAL NOT NULL,
                        calories REAL DEFAULT 0,
                        proteins REAL DEFAULT 0,
                        carbs REAL DEFAULT 0,
                        fats REAL DEFAULT 0,
                        fiber REAL DEFAULT 0,
                        sugars REAL DEFAULT 0,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Biometric measurements table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS biometric_measurements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        time TEXT,
                        weight REAL,
                        body_fat REAL,
                        muscle_mass REAL,
                        water_percentage REAL,
                        bone_mass REAL,
                        visceral_fat INTEGER,
                        resting_hr INTEGER,
                        blood_pressure_sys INTEGER,
                        blood_pressure_dia INTEGER,
                        sleep_hours REAL,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Lifestyle habits table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS lifestyle_habits (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        morning_score REAL DEFAULT 0,
                        evening_score REAL DEFAULT 0,
                        workout_completed BOOLEAN DEFAULT 0,
                        workout_quality INTEGER DEFAULT 0,
                        meals_planned BOOLEAN DEFAULT 0,
                        hydration_target BOOLEAN DEFAULT 0,
                        energy_level INTEGER DEFAULT 5,
                        mood_score INTEGER DEFAULT 5,
                        stress_level INTEGER DEFAULT 5,
                        meditation_completed BOOLEAN DEFAULT 0,
                        sleep_target_met BOOLEAN DEFAULT 0,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Rehabilitation progress table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS rehabilitation_progress (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        pain_level INTEGER DEFAULT 0,
                        swelling TEXT,
                        stiffness TEXT,
                        flexion_rom INTEGER,
                        extension_rom INTEGER,
                        quadriceps_strength INTEGER,
                        hamstring_strength INTEGER,
                        glute_strength INTEGER,
                        single_leg_stance INTEGER,
                        walking_score INTEGER DEFAULT 0,
                        stairs_score INTEGER DEFAULT 0,
                        squat_score INTEGER DEFAULT 0,
                        running_score INTEGER DEFAULT 0,
                        medications TEXT,
                        other_treatments TEXT,
                        notes TEXT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # User goals table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS user_goals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        goal_name TEXT NOT NULL,
                        goal_type TEXT NOT NULL,
                        target_value REAL,
                        current_value REAL DEFAULT 0,
                        target_date TEXT,
                        is_active BOOLEAN DEFAULT 1,
                        progress_percentage REAL DEFAULT 0,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Hydration tracking table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS hydration (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        hour INTEGER NOT NULL,
                        water_amount INTEGER NOT NULL,
                        cumulative_amount INTEGER DEFAULT 0,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # User preferences table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS user_preferences (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        preference_key TEXT UNIQUE NOT NULL,
                        preference_value TEXT NOT NULL,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                conn.commit()
        except Exception as e:
            st.error(f"Errore nell'inizializzazione database: {str(e)}")
    
    def save_activity(self, activity_data: Dict) -> bool:
        """Save activity data to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT OR REPLACE INTO activities 
                    (activity_id, date, activity_type, distance, duration, avg_heart_rate, 
                     max_heart_rate, calories, avg_pace, elevation_gain, activity_name, 
                     notes, perceived_effort)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    activity_data.get('activity_id'),
                    activity_data.get('date'),
                    activity_data.get('activity_type'),
                    activity_data.get('distance', 0),
                    activity_data.get('duration', 0),
                    activity_data.get('avg_heart_rate'),
                    activity_data.get('max_heart_rate'),
                    activity_data.get('calories', 0),
                    activity_data.get('avg_pace'),
                    activity_data.get('elevation_gain', 0),
                    activity_data.get('activity_name', ''),
                    activity_data.get('notes', ''),
                    activity_data.get('perceived_effort')
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare attività: {str(e)}")
            return False
    
    def get_activities_by_date_range(self, start_date: Union[str, date], 
                                   end_date: Union[str, date]) -> pd.DataFrame:
        """Get activities within date range"""
        try:
            if isinstance(start_date, date):
                start_date = start_date.strftime('%Y-%m-%d')
            if isinstance(end_date, date):
                end_date = end_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM activities 
                    WHERE date BETWEEN ? AND ? 
                    ORDER BY date DESC
                '''
                return pd.read_sql_query(query, conn, params=(start_date, end_date))
        except Exception as e:
            st.error(f"Errore nel recupero attività: {str(e)}")
            return pd.DataFrame()
    
    def get_recent_activities(self, limit: int = 10) -> pd.DataFrame:
        """Get most recent activities"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM activities 
                    ORDER BY date DESC, created_at DESC 
                    LIMIT ?
                '''
                return pd.read_sql_query(query, conn, params=(limit,))
        except Exception as e:
            st.error(f"Errore nel recupero attività recenti: {str(e)}")
            return pd.DataFrame()
    
    def save_nutrition_entry(self, nutrition_data: Dict) -> bool:
        """Save nutrition entry to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO nutrition 
                    (date, meal_type, food_name, quantity, calories, proteins, 
                     carbs, fats, fiber, sugars, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    nutrition_data.get('date'),
                    nutrition_data.get('meal_type'),
                    nutrition_data.get('food_name'),
                    nutrition_data.get('quantity', 0),
                    nutrition_data.get('calories', 0),
                    nutrition_data.get('proteins', 0),
                    nutrition_data.get('carbs', 0),
                    nutrition_data.get('fats', 0),
                    nutrition_data.get('fiber', 0),
                    nutrition_data.get('sugars', 0),
                    nutrition_data.get('timestamp', datetime.now())
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare entry nutrizionale: {str(e)}")
            return False
    
    def get_daily_nutrition(self, target_date: Union[str, date]) -> Optional[Dict]:
        """Get nutrition data for a specific date"""
        try:
            if isinstance(target_date, date):
                target_date = target_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT meal_type, SUM(calories) as calories, SUM(proteins) as proteins,
                           SUM(carbs) as carbs, SUM(fats) as fats
                    FROM nutrition 
                    WHERE date = ? 
                    GROUP BY meal_type
                '''
                meals_df = pd.read_sql_query(query, conn, params=(target_date,))
                
                if meals_df.empty:
                    return None
                
                # Calculate totals
                total_calories = meals_df['calories'].sum()
                total_proteins = meals_df['proteins'].sum()
                total_carbs = meals_df['carbs'].sum()
                total_fats = meals_df['fats'].sum()
                
                # Meals breakdown
                meals_breakdown = dict(zip(meals_df['meal_type'], meals_df['calories']))
                
                return {
                    'total_calories': total_calories,
                    'target_calories': 2500,  # Should come from user preferences
                    'total_proteins': total_proteins,
                    'target_proteins': 150,
                    'total_carbs': total_carbs,
                    'target_carbs': 350,
                    'total_fats': total_fats,
                    'target_fats': 85,
                    'meals_breakdown': meals_breakdown
                }
        except Exception as e:
            st.error(f"Errore nel recupero dati nutrizionali: {str(e)}")
            return None
    
    def get_nutrition_meals_log(self, target_date: Union[str, date]) -> pd.DataFrame:
        """Get detailed meals log for a date"""
        try:
            if isinstance(target_date, date):
                target_date = target_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM nutrition 
                    WHERE date = ? 
                    ORDER BY timestamp ASC
                '''
                return pd.read_sql_query(query, conn, params=(target_date,))
        except Exception as e:
            st.error(f"Errore nel recupero log pasti: {str(e)}")
            return pd.DataFrame()
    
    def save_biometric_measurement(self, measurement_data: Dict) -> bool:
        """Save biometric measurement to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO biometric_measurements 
                    (date, time, weight, body_fat, muscle_mass, water_percentage, 
                     bone_mass, visceral_fat, resting_hr, blood_pressure_sys, 
                     blood_pressure_dia, sleep_hours)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    measurement_data.get('date'),
                    measurement_data.get('time'),
                    measurement_data.get('weight'),
                    measurement_data.get('body_fat'),
                    measurement_data.get('muscle_mass'),
                    measurement_data.get('water_percentage'),
                    measurement_data.get('bone_mass'),
                    measurement_data.get('visceral_fat'),
                    measurement_data.get('resting_hr'),
                    measurement_data.get('blood_pressure_sys'),
                    measurement_data.get('blood_pressure_dia'),
                    measurement_data.get('sleep_hours')
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare misurazione biometrica: {str(e)}")
            return False
    
    def get_biometric_data_range(self, start_date: Union[str, date], 
                               end_date: Union[str, date]) -> pd.DataFrame:
        """Get biometric data within date range"""
        try:
            if isinstance(start_date, date):
                start_date = start_date.strftime('%Y-%m-%d')
            if isinstance(end_date, date):
                end_date = end_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM biometric_measurements 
                    WHERE date BETWEEN ? AND ? 
                    ORDER BY date ASC
                '''
                return pd.read_sql_query(query, conn, params=(start_date, end_date))
        except Exception as e:
            st.error(f"Errore nel recupero dati biometrici: {str(e)}")
            return pd.DataFrame()
    
    def get_latest_biometric_data(self) -> Optional[Dict]:
        """Get latest biometric measurements"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM biometric_measurements 
                    ORDER BY date DESC, timestamp DESC 
                    LIMIT 1
                '''
                df = pd.read_sql_query(query, conn)
                
                if df.empty:
                    return None
                
                latest = df.iloc[0]
                
                # Calculate weekly changes (simplified)
                week_ago_query = '''
                    SELECT * FROM biometric_measurements 
                    WHERE date <= date('now', '-7 days')
                    ORDER BY date DESC, timestamp DESC 
                    LIMIT 1
                '''
                week_ago_df = pd.read_sql_query(week_ago_query, conn)
                
                changes = {}
                if not week_ago_df.empty:
                    week_ago = week_ago_df.iloc[0]
                    changes = {
                        'weight_change_week': latest['weight'] - week_ago['weight'] if latest['weight'] and week_ago['weight'] else 0,
                        'bf_change_week': latest['body_fat'] - week_ago['body_fat'] if latest['body_fat'] and week_ago['body_fat'] else 0,
                        'muscle_change_week': latest['muscle_mass'] - week_ago['muscle_mass'] if latest['muscle_mass'] and week_ago['muscle_mass'] else 0,
                        'rhr_change_week': latest['resting_hr'] - week_ago['resting_hr'] if latest['resting_hr'] and week_ago['resting_hr'] else 0,
                        'sleep_change_week': latest['sleep_hours'] - week_ago['sleep_hours'] if latest['sleep_hours'] and week_ago['sleep_hours'] else 0
                    }
                
                result = latest.to_dict()
                result.update(changes)
                return result
                
        except Exception as e:
            st.error(f"Errore nel recupero ultimi dati biometrici: {str(e)}")
            return None
    
    def save_lifestyle_habits(self, habits_data: Dict) -> bool:
        """Save daily lifestyle habits tracking"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT OR REPLACE INTO lifestyle_habits 
                    (date, morning_score, evening_score, workout_completed, workout_quality,
                     meals_planned, hydration_target, energy_level, mood_score, stress_level,
                     meditation_completed, sleep_target_met)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    habits_data.get('date'),
                    habits_data.get('morning_score', 0),
                    habits_data.get('evening_score', 0),
                    habits_data.get('workout_completed', False),
                    habits_data.get('workout_quality', 0),
                    habits_data.get('meals_planned', False),
                    habits_data.get('hydration_target', False),
                    habits_data.get('energy_level', 5),
                    habits_data.get('mood_score', 5),
                    habits_data.get('stress_level', 5),
                    habits_data.get('meditation_completed', False),
                    habits_data.get('sleep_target_met', False)
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare abitudini lifestyle: {str(e)}")
            return False
    
    def get_habits_data(self, days: int = 30) -> pd.DataFrame:
        """Get lifestyle habits data for analysis"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM lifestyle_habits 
                    WHERE date >= date('now', '-{} days')
                    ORDER BY date ASC
                '''.format(days)
                return pd.read_sql_query(query, conn)
        except Exception as e:
            st.error(f"Errore nel recupero dati abitudini: {str(e)}")
            return pd.DataFrame()
    
    def save_rehabilitation_progress(self, rehab_data: Dict) -> bool:
        """Save rehabilitation progress data"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO rehabilitation_progress 
                    (date, pain_level, swelling, stiffness, flexion_rom, extension_rom,
                     quadriceps_strength, hamstring_strength, glute_strength, single_leg_stance,
                     walking_score, stairs_score, squat_score, running_score, 
                     medications, other_treatments, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    rehab_data.get('date'),
                    rehab_data.get('pain_level', 0),
                    rehab_data.get('swelling', ''),
                    rehab_data.get('stiffness', ''),
                    rehab_data.get('flexion_rom'),
                    rehab_data.get('extension_rom'),
                    rehab_data.get('quadriceps_strength'),
                    rehab_data.get('hamstring_strength'),
                    rehab_data.get('glute_strength'),
                    rehab_data.get('single_leg_stance'),
                    rehab_data.get('walking_score', 0),
                    rehab_data.get('stairs_score', 0),
                    rehab_data.get('squat_score', 0),
                    rehab_data.get('running_score', 0),
                    json.dumps(rehab_data.get('medications', [])),
                    json.dumps(rehab_data.get('other_treatments', [])),
                    rehab_data.get('notes', '')
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare progressi riabilitazione: {str(e)}")
            return False
    
    def get_rehabilitation_progress(self) -> pd.DataFrame:
        """Get rehabilitation progress data"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM rehabilitation_progress 
                    ORDER BY date ASC
                '''
                return pd.read_sql_query(query, conn)
        except Exception as e:
            st.error(f"Errore nel recupero progressi riabilitazione: {str(e)}")
            return pd.DataFrame()
    
    def save_goal(self, goal_data: Dict) -> bool:
        """Save user goal to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO user_goals 
                    (goal_name, goal_type, target_value, target_date, is_active)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    goal_data.get('goal_name'),
                    goal_data.get('goal_type'),
                    goal_data.get('target_value'),
                    goal_data.get('target_date'),
                    goal_data.get('is_active', True)
                ))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare obiettivo: {str(e)}")
            return False
    
    def get_active_goals(self) -> pd.DataFrame:
        """Get active user goals"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT * FROM user_goals 
                    WHERE is_active = 1 
                    ORDER BY created_at DESC
                '''
                return pd.read_sql_query(query, conn)
        except Exception as e:
            st.error(f"Errore nel recupero obiettivi: {str(e)}")
            return pd.DataFrame()
    
    def add_hydration_entry(self, date_str: str, hour: int, amount: int) -> bool:
        """Add hydration entry"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get current cumulative amount
                cursor.execute('''
                    SELECT COALESCE(SUM(water_amount), 0) 
                    FROM hydration 
                    WHERE date = ?
                ''', (date_str,))
                
                current_total = cursor.fetchone()[0]
                new_cumulative = current_total + amount
                
                cursor.execute('''
                    INSERT INTO hydration 
                    (date, hour, water_amount, cumulative_amount)
                    VALUES (?, ?, ?, ?)
                ''', (date_str, hour, amount, new_cumulative))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nell'aggiunta idratazione: {str(e)}")
            return False
    
    def get_hydration_data(self, target_date: Union[str, date]) -> Optional[Dict]:
        """Get hydration data for a date"""
        try:
            if isinstance(target_date, date):
                target_date = target_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT COALESCE(SUM(water_amount), 0) as total_water
                    FROM hydration 
                    WHERE date = ?
                '''
                result = pd.read_sql_query(query, conn, params=(target_date,))
                
                if result.empty:
                    return {'water_consumed': 0, 'water_target': 3000}
                
                return {
                    'water_consumed': result.iloc[0]['total_water'],
                    'water_target': 3000  # Should come from user preferences
                }
        except Exception as e:
            st.error(f"Errore nel recupero dati idratazione: {str(e)}")
            return None
    
    def get_hydration_timeline(self, target_date: Union[str, date]) -> pd.DataFrame:
        """Get hourly hydration timeline"""
        try:
            if isinstance(target_date, date):
                target_date = target_date.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.db_path) as conn:
                query = '''
                    SELECT hour, SUM(water_amount) as water_amount
                    FROM hydration 
                    WHERE date = ?
                    GROUP BY hour
                    ORDER BY hour ASC
                '''
                return pd.read_sql_query(query, conn, params=(target_date,))
        except Exception as e:
            st.error(f"Errore nel recupero timeline idratazione: {str(e)}")
            return pd.DataFrame()
    
    def set_user_preference(self, key: str, value: str) -> bool:
        """Set user preference"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT OR REPLACE INTO user_preferences 
                    (preference_key, preference_value, updated_at)
                    VALUES (?, ?, ?)
                ''', (key, value, datetime.now()))
                
                conn.commit()
                return True
        except Exception as e:
            st.error(f"Errore nel salvare preferenza: {str(e)}")
            return False
    
    def get_user_preference(self, key: str, default_value: str = "") -> str:
        """Get user preference"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT preference_value FROM user_preferences 
                    WHERE preference_key = ?
                ''', (key,))
                
                result = cursor.fetchone()
                return result[0] if result else default_value
        except Exception as e:
            st.error(f"Errore nel recupero preferenza: {str(e)}")
            return default_value
    
    def backup_database(self, backup_path: str) -> bool:
        """Create database backup"""
        try:
            import shutil
            shutil.copy2(self.db_path, backup_path)
            return True
        except Exception as e:
            st.error(f"Errore nel backup database: {str(e)}")
            return False
    
    def get_database_stats(self) -> Dict[str, int]:
        """Get database statistics"""
        try:
            stats = {}
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                tables = ['activities', 'nutrition', 'biometric_measurements', 
                         'lifestyle_habits', 'rehabilitation_progress', 'user_goals']
                
                for table in tables:
                    cursor.execute(f'SELECT COUNT(*) FROM {table}')
                    stats[table] = cursor.fetchone()[0]
            
            return stats
        except Exception as e:
            st.error(f"Errore nel recupero statistiche database: {str(e)}")
            return {}
