import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
from typing import Optional, Dict, List, Any
import streamlit as st
from scipy import stats
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression

class DataAnalysisService:
    """Service for advanced data analysis and metrics calculation"""
    
    def __init__(self):
        self.scaler = MinMaxScaler()
    
    def get_today_summary(self) -> Optional[Dict]:
        """Get today's training summary"""
        try:
            # In production, this would query the database
            # For now, return empty structure
            return {
                'distance': 0,
                'duration': 0,
                'calories': 0,
                'training_load': 0
            }
        except Exception as e:
            st.error(f"Errore nel recupero riepilogo giornaliero: {str(e)}")
            return None
    
    def get_current_goals(self) -> Optional[List[Dict]]:
        """Get current active goals"""
        try:
            # In production, this would query user's goals from database
            return []
        except Exception as e:
            st.error(f"Errore nel recupero obiettivi: {str(e)}")
            return None
    
    def get_weekly_trend(self) -> Optional[pd.DataFrame]:
        """Get weekly training load trend"""
        try:
            # Return empty DataFrame - would be populated from database
            return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero trend settimanale: {str(e)}")
            return pd.DataFrame()
    
    def calculate_training_load_trend(self, activities_data: pd.DataFrame, 
                                    start_date: datetime, end_date: datetime) -> Optional[pd.DataFrame]:
        """Calculate acute vs chronic training load trend"""
        try:
            if activities_data.empty:
                return pd.DataFrame()
            
            # Ensure date column is datetime
            activities_data['date'] = pd.to_datetime(activities_data['date'])
            
            # Create daily aggregates
            daily_load = activities_data.groupby('date').agg({
                'duration': 'sum',
                'distance': 'sum',
                'calories': 'sum'
            }).reset_index()
            
            # Calculate daily training load (simplified TSS)
            daily_load['training_load'] = (
                daily_load['duration'] * 0.5 +  # Duration factor
                daily_load['distance'] * 2.0 +   # Distance factor
                daily_load['calories'] * 0.1     # Calories factor
            ) / 100
            
            # Calculate rolling averages
            daily_load = daily_load.sort_values('date')
            daily_load['acute_load'] = daily_load['training_load'].rolling(window=7, min_periods=1).mean()
            daily_load['chronic_load'] = daily_load['training_load'].rolling(window=28, min_periods=1).mean()
            
            # Calculate acute:chronic ratio
            daily_load['acute_chronic_ratio'] = daily_load['acute_load'] / daily_load['chronic_load'].replace(0, 1)
            
            return daily_load
        except Exception as e:
            st.error(f"Errore nel calcolo trend carico: {str(e)}")
            return pd.DataFrame()
    
    def calculate_tss(self, activities_data: pd.DataFrame) -> float:
        """Calculate Training Stress Score"""
        try:
            if activities_data.empty:
                return 0.0
            
            total_tss = 0.0
            
            for _, activity in activities_data.iterrows():
                duration_hours = activity.get('duration', 0) / 3600
                avg_hr = activity.get('avg_heart_rate', 0)
                
                if duration_hours > 0 and avg_hr > 0:
                    # Simplified TSS calculation
                    threshold_hr = 170  # Should come from user profile
                    intensity_factor = avg_hr / threshold_hr if threshold_hr > 0 else 0.7
                    
                    tss = duration_hours * intensity_factor * intensity_factor * 100
                    total_tss += tss
            
            return total_tss
        except Exception as e:
            st.error(f"Errore nel calcolo TSS: {str(e)}")
            return 0.0
    
    def get_recent_records(self, activities_data: pd.DataFrame) -> Optional[Dict]:
        """Get recent personal records"""
        try:
            if activities_data.empty:
                return None
            
            records = {
                'max_distance': activities_data['distance'].max(),
                'max_duration': activities_data['duration'].max(),
                'max_calories': activities_data['calories'].max(),
                'max_hr': activities_data['max_heart_rate'].max() if 'max_heart_rate' in activities_data.columns else 0,
                'best_pace': activities_data['avg_pace'].min() if 'avg_pace' in activities_data.columns else 0,
                'best_tss': self.calculate_tss(activities_data)
            }
            
            return records
        except Exception as e:
            st.error(f"Errore nel recupero record: {str(e)}")
            return None
    
    def get_pre_workout_metrics(self, workout_date: str) -> Optional[Dict]:
        """Get pre-workout conditions and metrics"""
        try:
            # In production, this would aggregate data from various sources
            # For now, return empty structure
            return {
                'sleep_quality': 0,
                'resting_hr': 0,
                'hrv': 0,
                'stress_level': 0
            }
        except Exception as e:
            st.error(f"Errore nel recupero metriche pre-workout: {str(e)}")
            return None
    
    def get_post_workout_metrics(self, activity_data: pd.Series) -> Optional[Dict]:
        """Calculate post-workout recovery and progression metrics"""
        try:
            duration_hours = activity_data.get('duration', 0) / 3600
            distance = activity_data.get('distance', 0)
            avg_hr = activity_data.get('avg_heart_rate', 0)
            
            # Calculate training load
            training_load = self._calculate_training_load(duration_hours, distance, avg_hr)
            
            # Estimate recovery time
            recovery_time = self._estimate_recovery_time(training_load, avg_hr)
            
            # Calculate stress score
            stress_score = self._calculate_stress_score(duration_hours, avg_hr)
            
            # Calculate progression coefficients
            coefficients = self._calculate_progression_coefficients(activity_data)
            
            return {
                'training_load': training_load,
                'recovery_time': recovery_time,
                'stress_score': stress_score,
                'aerobic_coefficient': coefficients.get('aerobic', 0),
                'anaerobic_coefficient': coefficients.get('anaerobic', 0),
                'strength_coefficient': coefficients.get('strength', 0)
            }
        except Exception as e:
            st.error(f"Errore nel calcolo metriche post-workout: {str(e)}")
            return None
    
    def compare_performance(self, actual_activity: pd.Series, predicted_performance: Optional[Dict]) -> Optional[Dict]:
        """Compare actual vs predicted performance"""
        try:
            if predicted_performance is None:
                return None
            
            comparison = {
                'pace_difference': actual_activity.get('avg_pace', 0) - predicted_performance.get('predicted_pace', 0),
                'hr_difference': actual_activity.get('avg_heart_rate', 0) - predicted_performance.get('predicted_hr', 0),
                'effort_difference': 0  # Would need actual effort rating
            }
            
            return comparison
        except Exception as e:
            st.error(f"Errore nel confronto performance: {str(e)}")
            return None
    
    def get_similar_workouts(self, target_activity: pd.Series, limit: int = 5) -> Optional[pd.DataFrame]:
        """Find similar workouts for comparison"""
        try:
            # In production, this would query database for similar activities
            # Return empty DataFrame for now
            return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero workout simili: {str(e)}")
            return pd.DataFrame()
    
    def get_user_performance_summary(self) -> Optional[Dict]:
        """Get user's current performance summary"""
        try:
            # In production, this would aggregate user's recent performance data
            return {
                'vo2_max': 0,
                'threshold_pace': 0,
                'weekly_volume': 0,
                'current_fitness': 0
            }
        except Exception as e:
            st.error(f"Errore nel recupero summary performance: {str(e)}")
            return None
    
    def generate_progressive_goals(self, athlete_data: Dict, user_performance: Optional[Dict]) -> Optional[Dict]:
        """Generate progressive goals based on athlete data and user performance"""
        try:
            if user_performance is None:
                return None
            
            # Calculate progressive milestones
            milestones = {
                '3_months': [
                    "Aumenta volume settimanale del 10%",
                    "Migliora passo di soglia di 10 sec/km",
                    "Completa una distanza ultra entry-level"
                ],
                '6_months': [
                    "Raggiungi 80% del volume dell'atleta target",
                    "Partecipa a gara di 50+ km",
                    "Implementa strategie nutrizionali avanzate"
                ],
                '12_months': [
                    "Avvicinati alle performance dell'atleta target",
                    "Completa gara ultra di livello intermedio",
                    "Sviluppa approccio mentale professionale"
                ]
            }
            
            return milestones
        except Exception as e:
            st.error(f"Errore nella generazione obiettivi progressivi: {str(e)}")
            return None
    
    def adapt_workout_to_user_level(self, workout_details: Dict, user_performance: Optional[Dict]) -> Optional[Dict]:
        """Adapt athlete workout to user's current level"""
        try:
            if user_performance is None:
                return None
            
            # Simplified adaptation - would be more sophisticated in production
            adapted_workout = workout_details.copy()
            adapted_workout['adapted'] = True
            adapted_workout['notes'] = "Allenamento adattato al tuo livello attuale"
            
            return adapted_workout
        except Exception as e:
            st.error(f"Errore nell'adattamento workout: {str(e)}")
            return None
    
    def calculate_athlete_progress(self, athlete_name: str, athlete_data: Dict, 
                                 user_performance: Optional[Dict]) -> Optional[Dict]:
        """Calculate user's progress towards athlete level"""
        try:
            if user_performance is None:
                return None
            
            # Simplified progress calculation
            progress = {
                'overall_progress': 25.0,  # Percentage
                'physical_fitness': 30.0,
                'training_volume': 20.0,
                'performance_level': 25.0
            }
            
            return progress
        except Exception as e:
            st.error(f"Errore nel calcolo progresso atleta: {str(e)}")
            return None
    
    def get_habits_data(self, days: int = 30) -> Optional[pd.DataFrame]:
        """Get habits tracking data for analysis"""
        try:
            # Return empty DataFrame - would be populated from database
            return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero dati abitudini: {str(e)}")
            return pd.DataFrame()
    
    def get_sleep_analysis(self) -> Optional[Dict]:
        """Get sleep quality analysis"""
        try:
            # Return empty data - would analyze sleep patterns from database
            return {
                'avg_sleep_hours': 0,
                'sleep_quality': 0,
                'sleep_efficiency': 0
            }
        except Exception as e:
            st.error(f"Errore nell'analisi sonno: {str(e)}")
            return None
    
    def generate_weekly_lifestyle_report(self) -> Optional[Dict]:
        """Generate weekly lifestyle report"""
        try:
            # Return empty report structure
            return {
                'goals_achieved': {},
                'improvement_areas': [],
                'recommendations': []
            }
        except Exception as e:
            st.error(f"Errore nella generazione report lifestyle: {str(e)}")
            return None
    
    def get_rehabilitation_progress(self) -> Optional[pd.DataFrame]:
        """Get rehabilitation progress data"""
        try:
            # Return empty DataFrame - would be populated from database
            return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero progressi riabilitazione: {str(e)}")
            return pd.DataFrame()
    
    def generate_health_alerts(self, latest_measurements: Optional[Dict]) -> Optional[Dict]:
        """Generate health alerts based on biometric data"""
        try:
            if latest_measurements is None:
                return None
            
            alerts = {
                'alerts': [],
                'recommendations': []
            }
            
            # Example alert logic
            resting_hr = latest_measurements.get('resting_hr', 0)
            if resting_hr > 80:
                alerts['alerts'].append({
                    'severity': 'medium',
                    'message': 'Frequenza cardiaca a riposo elevata'
                })
            
            return alerts
        except Exception as e:
            st.error(f"Errore nella generazione alert salute: {str(e)}")
            return None
    
    def _calculate_training_load(self, duration_hours: float, distance: float, avg_hr: float) -> float:
        """Calculate training load for a workout"""
        try:
            base_load = duration_hours * 50  # Base load per hour
            
            if distance > 0:
                base_load += distance * 10  # Distance factor
            
            if avg_hr > 0:
                hr_factor = avg_hr / 170  # Intensity factor
                base_load *= hr_factor
            
            return base_load
        except:
            return 0.0
    
    def _estimate_recovery_time(self, training_load: float, avg_hr: float) -> float:
        """Estimate recovery time in hours"""
        try:
            base_recovery = training_load / 20  # Base recovery formula
            
            if avg_hr > 160:
                base_recovery *= 1.5  # High intensity penalty
            
            return min(base_recovery, 72)  # Max 72 hours
        except:
            return 24.0
    
    def _calculate_stress_score(self, duration_hours: float, avg_hr: float) -> float:
        """Calculate workout stress score"""
        try:
            if duration_hours == 0:
                return 0.0
            
            threshold_hr = 170  # Should come from user profile
            intensity_factor = avg_hr / threshold_hr if threshold_hr > 0 else 0.7
            
            stress_score = duration_hours * intensity_factor * intensity_factor * 100
            return stress_score
        except:
            return 0.0
    
    def _calculate_progression_coefficients(self, activity_data: pd.Series) -> Dict[str, float]:
        """Calculate training progression coefficients"""
        try:
            duration = activity_data.get('duration', 0)
            avg_hr = activity_data.get('avg_heart_rate', 0)
            activity_type = activity_data.get('activity_type', 'Unknown')
            
            # Simplified coefficient calculation
            coefficients = {
                'aerobic': 0.5,
                'anaerobic': 0.3,
                'strength': 0.2
            }
            
            # Adjust based on activity type and intensity
            if activity_type == 'Running':
                if avg_hr > 160:
                    coefficients['anaerobic'] += 0.3
                else:
                    coefficients['aerobic'] += 0.3
            
            return coefficients
        except:
            return {'aerobic': 0.0, 'anaerobic': 0.0, 'strength': 0.0}
