import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import streamlit as st
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

class MLPredictionsService:
    """Service for machine learning predictions and recommendations"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.pace_model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.hr_model = GradientBoostingRegressor(n_estimators=100, random_state=42)
        self.performance_model = LinearRegression()
        self.models_trained = False
    
    def predict_workout_performance(self, activity_data: pd.Series, 
                                  pre_workout_data: Optional[Dict]) -> Optional[Dict]:
        """Predict workout performance based on historical data and pre-workout conditions"""
        try:
            if pre_workout_data is None:
                return None
            
            # Extract features for prediction
            features = self._extract_prediction_features(activity_data, pre_workout_data)
            
            if not self.models_trained:
                # In production, models would be pre-trained
                return self._generate_baseline_predictions(activity_data, pre_workout_data)
            
            # Use trained models for prediction
            predicted_pace = self.pace_model.predict([features])[0]
            predicted_hr = self.hr_model.predict([features])[0]
            
            # Calculate confidence based on model performance
            confidence = self._calculate_prediction_confidence(features)
            
            return {
                'predicted_pace': predicted_pace,
                'predicted_hr': predicted_hr,
                'predicted_effort': self._predict_perceived_effort(features),
                'confidence': confidence
            }
        except Exception as e:
            st.error(f"Errore nella previsione performance: {str(e)}")
            return None
    
    def generate_workout_recommendations(self, activity_data: pd.Series, 
                                       post_workout_metrics: Optional[Dict]) -> Optional[Dict]:
        """Generate workout recommendations based on performance analysis"""
        try:
            recommendations = {
                'next_workouts': [],
                'warnings': [],
                'strengths': []
            }
            
            # Analyze current workout
            distance = activity_data.get('distance', 0)
            duration = activity_data.get('duration', 0)
            avg_hr = activity_data.get('avg_heart_rate', 0)
            activity_type = activity_data.get('activity_type', 'Unknown')
            
            # Generate recommendations based on analysis
            if post_workout_metrics:
                training_load = post_workout_metrics.get('training_load', 0)
                recovery_time = post_workout_metrics.get('recovery_time', 24)
                
                # Recovery recommendations
                if recovery_time > 48:
                    recommendations['warnings'].append(
                        "Carico di allenamento elevato - considera riposo attivo domani"
                    )
                
                if training_load > 150:
                    recommendations['warnings'].append(
                        "Training load molto alto - monitora segni di sovrallenamento"
                    )
                
                # Next workout suggestions
                if activity_type == 'Running':
                    if training_load < 100:
                        recommendations['next_workouts'].append({
                            'type': 'Interval Training',
                            'description': 'Sessione di interval per migliorare velocità'
                        })
                    else:
                        recommendations['next_workouts'].append({
                            'type': 'Recovery Run',
                            'description': 'Corsa di recupero a ritmo facile'
                        })
                
                # Identify strengths
                if avg_hr < 150 and distance > 10:
                    recommendations['strengths'].append(
                        "Ottima efficienza aerobica mantenuta su lunga distanza"
                    )
            
            # Default recommendations if no post-workout metrics
            if not recommendations['next_workouts']:
                recommendations['next_workouts'].append({
                    'type': 'Active Recovery',
                    'description': 'Sessione di recupero attivo con stretching'
                })
            
            return recommendations
        except Exception as e:
            st.error(f"Errore nella generazione raccomandazioni: {str(e)}")
            return None
    
    def predict_injury_risk(self, training_data: pd.DataFrame) -> Optional[Dict]:
        """Predict injury risk based on training patterns"""
        try:
            if training_data.empty:
                return None
            
            # Calculate risk factors
            risk_factors = self._calculate_risk_factors(training_data)
            
            # Simple risk assessment
            risk_score = 0.0
            risk_level = "Basso"
            risk_details = []
            
            # Training load progression risk
            if risk_factors.get('load_progression', 0) > 1.3:
                risk_score += 0.3
                risk_details.append("Aumento troppo rapido del carico di allenamento")
            
            # Volume consistency risk
            if risk_factors.get('volume_variability', 0) > 0.5:
                risk_score += 0.2
                risk_details.append("Variabilità eccessiva nel volume settimanale")
            
            # Recovery balance risk
            if risk_factors.get('recovery_ratio', 0) < 0.3:
                risk_score += 0.2
                risk_details.append("Insufficiente tempo di recupero")
            
            # Determine risk level
            if risk_score > 0.6:
                risk_level = "Alto"
            elif risk_score > 0.3:
                risk_level = "Moderato"
            
            return {
                'risk_score': risk_score,
                'risk_level': risk_level,
                'risk_factors': risk_details,
                'recommendations': self._generate_injury_prevention_recommendations(risk_score)
            }
        except Exception as e:
            st.error(f"Errore nella previsione rischio infortuni: {str(e)}")
            return None
    
    def predict_race_performance(self, race_distance: float, training_data: pd.DataFrame) -> Optional[Dict]:
        """Predict race performance based on training data"""
        try:
            if training_data.empty:
                return None
            
            # Analyze training patterns
            recent_performances = self._analyze_recent_performances(training_data)
            fitness_trend = self._calculate_fitness_trend(training_data)
            
            # Predict race time based on recent training paces
            predicted_pace = self._predict_race_pace(race_distance, recent_performances)
            predicted_time = race_distance * predicted_pace * 60  # Convert to seconds
            
            # Calculate confidence interval
            confidence_interval = self._calculate_time_confidence_interval(predicted_time, training_data)
            
            return {
                'predicted_time_seconds': predicted_time,
                'predicted_pace_min_per_km': predicted_pace,
                'confidence_interval_seconds': confidence_interval,
                'fitness_trend': fitness_trend,
                'race_strategy': self._generate_race_strategy(race_distance, predicted_pace)
            }
        except Exception as e:
            st.error(f"Errore nella previsione performance gara: {str(e)}")
            return None
    
    def optimize_training_plan(self, goals: Dict, current_fitness: Dict, 
                             available_time: int) -> Optional[Dict]:
        """Generate optimized training plan using ML"""
        try:
            # Extract key parameters
            target_distance = goals.get('target_distance', 21)
            target_time = goals.get('target_time_seconds', 0)
            current_weekly_volume = current_fitness.get('weekly_volume', 30)
            
            # Calculate required improvements
            improvements_needed = self._calculate_required_improvements(goals, current_fitness)
            
            # Generate optimized weekly structure
            weekly_plan = self._optimize_weekly_structure(
                current_weekly_volume, 
                available_time, 
                improvements_needed
            )
            
            # Generate progressive training phases
            training_phases = self._generate_training_phases(
                target_distance, 
                improvements_needed,
                available_time
            )
            
            return {
                'weekly_plan': weekly_plan,
                'training_phases': training_phases,
                'expected_improvements': improvements_needed,
                'success_probability': self._calculate_success_probability(goals, current_fitness)
            }
        except Exception as e:
            st.error(f"Errore nell'ottimizzazione piano allenamento: {str(e)}")
            return None
    
    def train_models(self, training_data: pd.DataFrame) -> bool:
        """Train ML models with historical data"""
        try:
            if training_data.empty or len(training_data) < 10:
                return False
            
            # Prepare features and targets
            features, pace_targets, hr_targets = self._prepare_training_data(training_data)
            
            if len(features) < 10:
                return False
            
            # Split data
            X_train, X_test, y_pace_train, y_pace_test = train_test_split(
                features, pace_targets, test_size=0.2, random_state=42
            )
            
            # Train pace prediction model
            self.pace_model.fit(X_train, y_pace_train)
            pace_score = self.pace_model.score(X_test, y_pace_test)
            
            # Train heart rate prediction model if data available
            if len(hr_targets) > 0:
                _, _, y_hr_train, y_hr_test = train_test_split(
                    features, hr_targets, test_size=0.2, random_state=42
                )
                self.hr_model.fit(X_train, y_hr_train)
                hr_score = self.hr_model.score(X_test, y_hr_test)
            
            self.models_trained = True
            return True
        except Exception as e:
            st.error(f"Errore nell'allenamento modelli ML: {str(e)}")
            return False
    
    def _extract_prediction_features(self, activity_data: pd.Series, pre_workout_data: Dict) -> List[float]:
        """Extract features for ML prediction"""
        features = [
            activity_data.get('distance', 0),
            activity_data.get('duration', 0) / 3600,  # Convert to hours
            pre_workout_data.get('sleep_quality', 5),
            pre_workout_data.get('resting_hr', 60),
            pre_workout_data.get('hrv', 30),
            pre_workout_data.get('stress_level', 5),
            datetime.now().weekday(),  # Day of week
            datetime.now().hour        # Time of day
        ]
        return features
    
    def _generate_baseline_predictions(self, activity_data: pd.Series, pre_workout_data: Dict) -> Dict:
        """Generate baseline predictions when models aren't trained"""
        distance = activity_data.get('distance', 0)
        activity_type = activity_data.get('activity_type', 'Running')
        
        # Baseline pace prediction based on distance and activity type
        if activity_type == 'Running':
            if distance < 5:
                predicted_pace = 4.5  # min/km for short runs
            elif distance < 15:
                predicted_pace = 5.0  # min/km for medium runs
            else:
                predicted_pace = 5.5  # min/km for long runs
        else:
            predicted_pace = 5.0
        
        # Adjust based on pre-workout conditions
        sleep_factor = pre_workout_data.get('sleep_quality', 5) / 10
        stress_factor = (10 - pre_workout_data.get('stress_level', 5)) / 10
        adjustment = (sleep_factor + stress_factor) / 2
        
        predicted_pace *= (2 - adjustment)  # Better conditions = faster pace
        
        # Predicted heart rate
        predicted_hr = 150 + (distance * 2) - (adjustment * 20)
        predicted_hr = max(120, min(predicted_hr, 190))
        
        return {
            'predicted_pace': predicted_pace,
            'predicted_hr': predicted_hr,
            'predicted_effort': 5 + (distance * 0.2),
            'confidence': 0.6  # Moderate confidence for baseline
        }
    
    def _predict_perceived_effort(self, features: List[float]) -> float:
        """Predict perceived effort (RPE 1-10)"""
        distance = features[0]
        duration_hours = features[1]
        
        # Simple effort prediction
        base_effort = 3 + (distance * 0.3) + (duration_hours * 2)
        return min(base_effort, 10)
    
    def _calculate_prediction_confidence(self, features: List[float]) -> float:
        """Calculate confidence in predictions"""
        # Simplified confidence calculation
        # In production, this would be based on model validation metrics
        return 0.75
    
    def _calculate_risk_factors(self, training_data: pd.DataFrame) -> Dict[str, float]:
        """Calculate injury risk factors from training data"""
        risk_factors = {}
        
        # Training load progression
        if len(training_data) >= 2:
            recent_load = training_data['duration'].tail(7).sum()
            previous_load = training_data['duration'].tail(14).head(7).sum()
            
            if previous_load > 0:
                risk_factors['load_progression'] = recent_load / previous_load
            else:
                risk_factors['load_progression'] = 1.0
        
        # Volume variability
        weekly_volumes = training_data.groupby(
            pd.to_datetime(training_data['date']).dt.isocalendar().week
        )['distance'].sum()
        
        if len(weekly_volumes) > 1:
            risk_factors['volume_variability'] = weekly_volumes.std() / weekly_volumes.mean()
        else:
            risk_factors['volume_variability'] = 0.0
        
        # Recovery ratio (simplified)
        total_days = len(training_data)
        training_days = len(training_data[training_data['distance'] > 0])
        
        if total_days > 0:
            risk_factors['recovery_ratio'] = (total_days - training_days) / total_days
        else:
            risk_factors['recovery_ratio'] = 0.0
        
        return risk_factors
    
    def _generate_injury_prevention_recommendations(self, risk_score: float) -> List[str]:
        """Generate injury prevention recommendations"""
        recommendations = []
        
        if risk_score > 0.6:
            recommendations.extend([
                "Riduci immediatamente il volume di allenamento del 20-30%",
                "Inserisci giorni di riposo aggiuntivi",
                "Focus su stretching e mobilità",
                "Considera una valutazione medica preventiva"
            ])
        elif risk_score > 0.3:
            recommendations.extend([
                "Modera l'aumento del carico di allenamento",
                "Aumenta il tempo dedicato al recupero",
                "Implementa esercizi di rinforzo preventivo",
                "Monitora attentamente i segnali del corpo"
            ])
        else:
            recommendations.extend([
                "Mantieni la routine di prevenzione attuale",
                "Continua con progressioni graduali",
                "Mantieni buone abitudini di recupero"
            ])
        
        return recommendations
    
    def _analyze_recent_performances(self, training_data: pd.DataFrame) -> Dict:
        """Analyze recent performance trends"""
        recent_data = training_data.tail(20)  # Last 20 workouts
        
        analysis = {
            'avg_pace': recent_data['avg_pace'].mean() if 'avg_pace' in recent_data.columns else 5.0,
            'pace_trend': 0.0,
            'volume_trend': 0.0,
            'consistency': 0.0
        }
        
        # Calculate trends if enough data
        if len(recent_data) >= 10:
            # Pace trend (negative = improving)
            pace_values = recent_data['avg_pace'].dropna()
            if len(pace_values) >= 5:
                x = np.arange(len(pace_values))
                slope, _, _, _, _ = stats.linregress(x, pace_values)
                analysis['pace_trend'] = slope
        
        return analysis
    
    def _calculate_fitness_trend(self, training_data: pd.DataFrame) -> str:
        """Calculate overall fitness trend"""
        if len(training_data) < 10:
            return "Dati insufficienti"
        
        recent_avg = training_data.tail(10)['distance'].mean()
        older_avg = training_data.head(10)['distance'].mean()
        
        if recent_avg > older_avg * 1.1:
            return "In miglioramento"
        elif recent_avg < older_avg * 0.9:
            return "In declino"
        else:
            return "Stabile"
    
    def _predict_race_pace(self, race_distance: float, recent_performances: Dict) -> float:
        """Predict race pace based on recent performances"""
        base_pace = recent_performances.get('avg_pace', 5.0)
        
        # Adjust for race distance
        if race_distance <= 5:
            race_pace = base_pace * 0.95  # Faster for short races
        elif race_distance <= 21:
            race_pace = base_pace * 1.02  # Slightly slower for half marathon
        else:
            race_pace = base_pace * 1.1   # Slower for marathon+
        
        return race_pace
    
    def _calculate_time_confidence_interval(self, predicted_time: float, training_data: pd.DataFrame) -> Dict:
        """Calculate confidence interval for predicted time"""
        # Simplified confidence interval
        variability = 0.05  # 5% variability
        
        return {
            'lower_bound': predicted_time * (1 - variability),
            'upper_bound': predicted_time * (1 + variability)
        }
    
    def _generate_race_strategy(self, race_distance: float, predicted_pace: float) -> Dict:
        """Generate race strategy recommendations"""
        strategy = {
            'pacing_strategy': 'Even pacing',
            'splits': [],
            'nutrition_timing': [],
            'key_points': []
        }
        
        # Generate split recommendations
        if race_distance >= 21:
            # Half marathon or longer
            strategy['splits'] = [
                f"Primi 5km: {predicted_pace + 0.1:.2f} min/km (start conservativo)",
                f"Km 5-15: {predicted_pace:.2f} min/km (ritmo gara)",
                f"Ultimi 5km: {predicted_pace - 0.1:.2f} min/km (se possibile accelerare)"
            ]
            
            strategy['nutrition_timing'] = [
                "Ogni 5km: idratazione",
                "Ogni 45min: carboidrati (se gara >90min)"
            ]
        
        return strategy
    
    def _calculate_required_improvements(self, goals: Dict, current_fitness: Dict) -> Dict:
        """Calculate required improvements to reach goals"""
        improvements = {
            'pace_improvement_percent': 0,
            'volume_increase_percent': 0,
            'endurance_improvement': 0
        }
        
        current_pace = current_fitness.get('avg_pace', 5.0)
        target_pace = goals.get('target_pace', current_pace)
        
        if current_pace > 0 and target_pace > 0:
            improvements['pace_improvement_percent'] = ((current_pace - target_pace) / current_pace) * 100
        
        return improvements
    
    def _optimize_weekly_structure(self, current_volume: float, available_time: int, 
                                 improvements_needed: Dict) -> Dict:
        """Optimize weekly training structure"""
        weekly_plan = {
            'total_volume_km': min(current_volume * 1.1, available_time * 2),
            'workouts_per_week': min(5, available_time // 60),
            'easy_runs_percent': 70,
            'tempo_runs_percent': 20,
            'intervals_percent': 10
        }
        
        return weekly_plan
    
    def _generate_training_phases(self, target_distance: float, improvements_needed: Dict, 
                                available_time: int) -> List[Dict]:
        """Generate progressive training phases"""
        phases = [
            {
                'name': 'Base Building',
                'duration_weeks': 8,
                'focus': 'Aerobic development',
                'volume_increase': '10% per week'
            },
            {
                'name': 'Build Phase',
                'duration_weeks': 6,
                'focus': 'Tempo and threshold work',
                'volume_increase': '5% per week'
            },
            {
                'name': 'Peak Phase',
                'duration_weeks': 4,
                'focus': 'Race-specific training',
                'volume_increase': 'Maintain'
            },
            {
                'name': 'Taper',
                'duration_weeks': 2,
                'focus': 'Recovery and race prep',
                'volume_increase': '-20% per week'
            }
        ]
        
        return phases
    
    def _calculate_success_probability(self, goals: Dict, current_fitness: Dict) -> float:
        """Calculate probability of achieving goals"""
        # Simplified success probability calculation
        current_level = current_fitness.get('fitness_score', 50)
        required_level = goals.get('difficulty_score', 70)
        
        if required_level <= current_level:
            return 0.9
        elif required_level <= current_level * 1.2:
            return 0.7
        elif required_level <= current_level * 1.5:
            return 0.4
        else:
            return 0.2
    
    def _prepare_training_data(self, training_data: pd.DataFrame) -> tuple:
        """Prepare data for model training"""
        features = []
        pace_targets = []
        hr_targets = []
        
        for _, row in training_data.iterrows():
            feature_row = [
                row.get('distance', 0),
                row.get('duration', 0) / 3600,
                row.get('calories', 0),
                pd.to_datetime(row.get('date', datetime.now())).weekday(),
                pd.to_datetime(row.get('date', datetime.now())).hour
            ]
            
            features.append(feature_row)
            
            if 'avg_pace' in row and pd.notna(row['avg_pace']):
                pace_targets.append(row['avg_pace'])
            
            if 'avg_heart_rate' in row and pd.notna(row['avg_heart_rate']):
                hr_targets.append(row['avg_heart_rate'])
        
        return np.array(features), np.array(pace_targets), np.array(hr_targets)
