import os
import requests
import pandas as pd
from datetime import datetime, date, timedelta
from typing import Optional, Dict, List, Any
import streamlit as st

class IntegrationsService:
    """Service for managing integrations with external platforms"""
    
    def __init__(self):
        # API Keys from environment
        self.yazio_api_key = os.getenv("YAZIO_API_KEY", "")
        self.fitdays_api_key = os.getenv("FITDAYS_API_KEY", "")
        self.apple_health_token = os.getenv("APPLE_HEALTH_TOKEN", "")
        
        # Session for HTTP requests
        self.session = requests.Session()
    
    def get_all_connection_status(self) -> Dict[str, bool]:
        """Get connection status for all integrated services"""
        return {
            "Yazio": self._check_yazio_connection(),
            "Fitdays": self._check_fitdays_connection(),
            "Apple Health": self._check_apple_health_connection()
        }
    
    def _check_yazio_connection(self) -> bool:
        """Check Yazio API connection"""
        try:
            if not self.yazio_api_key:
                return False
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            response = self.session.get(
                "https://api.yazio.com/v1/user/profile",
                headers=headers,
                timeout=5
            )
            return response.status_code == 200
        except Exception:
            return False
    
    def _check_fitdays_connection(self) -> bool:
        """Check Fitdays API connection"""
        try:
            if not self.fitdays_api_key:
                return False
            
            headers = {
                'X-API-Key': self.fitdays_api_key,
                'Content-Type': 'application/json'
            }
            
            response = self.session.get(
                "https://api.fitdays.com/v1/user",
                headers=headers,
                timeout=5
            )
            return response.status_code == 200
        except Exception:
            return False
    
    def _check_apple_health_connection(self) -> bool:
        """Check Apple Health connection"""
        try:
            if not self.apple_health_token:
                return False
            
            # Apple Health typically uses different authentication
            # This is a simplified check
            return len(self.apple_health_token) > 0
        except Exception:
            return False
    
    def get_daily_nutrition(self, target_date: date) -> Optional[Dict]:
        """Get nutrition data for a specific date from Yazio"""
        try:
            if not self._check_yazio_connection():
                # Return sample structure for development
                return {
                    'total_calories': 0,
                    'target_calories': 2500,
                    'total_proteins': 0,
                    'target_proteins': 150,
                    'total_carbs': 0,
                    'target_carbs': 350,
                    'total_fats': 0,
                    'target_fats': 85,
                    'meals_breakdown': {}
                }
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            date_str = target_date.strftime('%Y-%m-%d')
            response = self.session.get(
                f"https://api.yazio.com/v1/nutrition/daily/{date_str}",
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'total_calories': data.get('totalCalories', 0),
                    'target_calories': data.get('targetCalories', 2500),
                    'total_proteins': data.get('totalProteins', 0),
                    'target_proteins': data.get('targetProteins', 150),
                    'total_carbs': data.get('totalCarbs', 0),
                    'target_carbs': data.get('targetCarbs', 350),
                    'total_fats': data.get('totalFats', 0),
                    'target_fats': data.get('targetFats', 85),
                    'meals_breakdown': data.get('mealsBreakdown', {})
                }
            else:
                return None
        except Exception as e:
            st.error(f"Errore nel recupero dati nutrizionali: {str(e)}")
            return None
    
    def get_meals_log(self, target_date: date) -> Optional[pd.DataFrame]:
        """Get detailed meals log for a specific date"""
        try:
            if not self._check_yazio_connection():
                return pd.DataFrame()  # Return empty DataFrame
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            date_str = target_date.strftime('%Y-%m-%d')
            response = self.session.get(
                f"https://api.yazio.com/v1/meals/{date_str}",
                headers=headers
            )
            
            if response.status_code == 200:
                meals_data = response.json()
                
                meals_list = []
                for meal in meals_data.get('meals', []):
                    meal_dict = {
                        'meal_type': meal.get('mealType'),
                        'food_name': meal.get('foodName'),
                        'quantity': meal.get('quantity', 0),
                        'calories': meal.get('calories', 0),
                        'proteins': meal.get('proteins', 0),
                        'carbs': meal.get('carbs', 0),
                        'fats': meal.get('fats', 0),
                        'fiber': meal.get('fiber', 0),
                        'sugars': meal.get('sugars', 0),
                        'timestamp': meal.get('timestamp')
                    }
                    meals_list.append(meal_dict)
                
                return pd.DataFrame(meals_list)
            else:
                return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero log pasti: {str(e)}")
            return pd.DataFrame()
    
    def get_nutrition_range(self, start_date: date, end_date: date) -> Optional[pd.DataFrame]:
        """Get nutrition data for a date range"""
        try:
            if not self._check_yazio_connection():
                return pd.DataFrame()
            
            nutrition_data = []
            current_date = start_date
            
            while current_date <= end_date:
                daily_nutrition = self.get_daily_nutrition(current_date)
                if daily_nutrition:
                    daily_nutrition['date'] = current_date
                    nutrition_data.append(daily_nutrition)
                
                current_date += timedelta(days=1)
            
            return pd.DataFrame(nutrition_data)
        except Exception as e:
            st.error(f"Errore nel recupero range nutrizionale: {str(e)}")
            return pd.DataFrame()
    
    def get_hydration_data(self, target_date: date) -> Optional[Dict]:
        """Get hydration data for a specific date"""
        try:
            if not self._check_yazio_connection():
                return {
                    'water_consumed': 0,
                    'water_target': 3000
                }
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            date_str = target_date.strftime('%Y-%m-%d')
            response = self.session.get(
                f"https://api.yazio.com/v1/hydration/{date_str}",
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'water_consumed': data.get('waterConsumed', 0),
                    'water_target': data.get('waterTarget', 3000),
                    'hydration_percentage': data.get('hydrationPercentage', 0)
                }
            else:
                return None
        except Exception as e:
            st.error(f"Errore nel recupero dati idratazione: {str(e)}")
            return None
    
    def get_hydration_timeline(self, target_date: date) -> Optional[pd.DataFrame]:
        """Get hourly hydration timeline for a date"""
        try:
            if not self._check_yazio_connection():
                return pd.DataFrame()
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            date_str = target_date.strftime('%Y-%m-%d')
            response = self.session.get(
                f"https://api.yazio.com/v1/hydration/timeline/{date_str}",
                headers=headers
            )
            
            if response.status_code == 200:
                timeline_data = response.json()
                
                timeline_list = []
                for entry in timeline_data.get('timeline', []):
                    timeline_dict = {
                        'hour': entry.get('hour'),
                        'water_amount': entry.get('waterAmount', 0),
                        'cumulative_amount': entry.get('cumulativeAmount', 0)
                    }
                    timeline_list.append(timeline_dict)
                
                return pd.DataFrame(timeline_list)
            else:
                return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero timeline idratazione: {str(e)}")
            return pd.DataFrame()
    
    def get_latest_biometric_data(self) -> Optional[Dict]:
        """Get latest biometric measurements from Fitdays"""
        try:
            if not self._check_fitdays_connection():
                return {
                    'weight': 0,
                    'body_fat': 0,
                    'muscle_mass': 0,
                    'water_percentage': 0,
                    'bone_mass': 0,
                    'visceral_fat': 0,
                    'resting_hr': 0,
                    'blood_pressure_sys': 0,
                    'blood_pressure_dia': 0,
                    'sleep_hours': 0,
                    'weight_change_week': 0,
                    'bf_change_week': 0,
                    'muscle_change_week': 0,
                    'rhr_change_week': 0,
                    'sleep_change_week': 0
                }
            
            headers = {
                'X-API-Key': self.fitdays_api_key,
                'Content-Type': 'application/json'
            }
            
            response = self.session.get(
                "https://api.fitdays.com/v1/measurements/latest",
                headers=headers
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'weight': data.get('weight', 0),
                    'body_fat': data.get('bodyFat', 0),
                    'muscle_mass': data.get('muscleMass', 0),
                    'water_percentage': data.get('waterPercentage', 0),
                    'bone_mass': data.get('boneMass', 0),
                    'visceral_fat': data.get('visceralFat', 0),
                    'resting_hr': data.get('restingHR', 0),
                    'blood_pressure_sys': data.get('bloodPressureSys', 0),
                    'blood_pressure_dia': data.get('bloodPressureDia', 0),
                    'sleep_hours': data.get('sleepHours', 0),
                    'weight_change_week': data.get('weightChangeWeek', 0),
                    'bf_change_week': data.get('bfChangeWeek', 0),
                    'muscle_change_week': data.get('muscleChangeWeek', 0),
                    'rhr_change_week': data.get('rhrChangeWeek', 0),
                    'sleep_change_week': data.get('sleepChangeWeek', 0)
                }
            else:
                return None
        except Exception as e:
            st.error(f"Errore nel recupero dati biometrici: {str(e)}")
            return None
    
    def get_biometric_data_range(self, start_date: datetime, end_date: datetime) -> Optional[pd.DataFrame]:
        """Get biometric data for a date range"""
        try:
            if not self._check_fitdays_connection():
                return pd.DataFrame()
            
            headers = {
                'X-API-Key': self.fitdays_api_key,
                'Content-Type': 'application/json'
            }
            
            params = {
                'startDate': start_date.strftime('%Y-%m-%d'),
                'endDate': end_date.strftime('%Y-%m-%d')
            }
            
            response = self.session.get(
                "https://api.fitdays.com/v1/measurements/range",
                headers=headers,
                params=params
            )
            
            if response.status_code == 200:
                measurements_data = response.json()
                
                measurements_list = []
                for measurement in measurements_data.get('measurements', []):
                    measurement_dict = {
                        'date': measurement.get('date'),
                        'weight': measurement.get('weight', 0),
                        'body_fat': measurement.get('bodyFat', 0),
                        'muscle_mass': measurement.get('muscleMass', 0),
                        'water_percentage': measurement.get('waterPercentage', 0),
                        'bone_mass': measurement.get('boneMass', 0),
                        'visceral_fat': measurement.get('visceralFat', 0),
                        'resting_hr': measurement.get('restingHR', 0),
                        'blood_pressure_sys': measurement.get('bloodPressureSys', 0),
                        'blood_pressure_dia': measurement.get('bloodPressureDia', 0),
                        'sleep_hours': measurement.get('sleepHours', 0)
                    }
                    measurements_list.append(measurement_dict)
                
                return pd.DataFrame(measurements_list)
            else:
                return pd.DataFrame()
        except Exception as e:
            st.error(f"Errore nel recupero range biometrico: {str(e)}")
            return pd.DataFrame()
    
    def sync_apple_health_data(self) -> bool:
        """Sync data from Apple Health"""
        try:
            if not self._check_apple_health_connection():
                return False
            
            # Apple Health integration would typically use HealthKit
            # This is a simplified implementation
            headers = {
                'Authorization': f'Bearer {self.apple_health_token}',
                'Content-Type': 'application/json'
            }
            
            # Sync various health metrics
            health_endpoints = [
                'steps',
                'heart_rate',
                'sleep',
                'workout',
                'body_measurements'
            ]
            
            sync_results = []
            for endpoint in health_endpoints:
                try:
                    response = self.session.get(
                        f"https://api.apple.com/health/v1/{endpoint}",
                        headers=headers
                    )
                    sync_results.append(response.status_code == 200)
                except:
                    sync_results.append(False)
            
            return all(sync_results)
        except Exception as e:
            st.error(f"Errore nella sincronizzazione Apple Health: {str(e)}")
            return False
    
    def add_manual_nutrition_entry(self, meal_data: Dict) -> bool:
        """Add manual nutrition entry to Yazio"""
        try:
            if not self._check_yazio_connection():
                # For development, simulate success
                return True
            
            headers = {
                'Authorization': f'Bearer {self.yazio_api_key}',
                'Content-Type': 'application/json'
            }
            
            response = self.session.post(
                "https://api.yazio.com/v1/meals",
                headers=headers,
                json=meal_data
            )
            
            return response.status_code in [200, 201]
        except Exception as e:
            st.error(f"Errore nell'aggiunta pasto: {str(e)}")
            return False
    
    def add_manual_biometric_entry(self, measurement_data: Dict) -> bool:
        """Add manual biometric measurement to Fitdays"""
        try:
            if not self._check_fitdays_connection():
                # For development, simulate success
                return True
            
            headers = {
                'X-API-Key': self.fitdays_api_key,
                'Content-Type': 'application/json'
            }
            
            response = self.session.post(
                "https://api.fitdays.com/v1/measurements",
                headers=headers,
                json=measurement_data
            )
            
            return response.status_code in [200, 201]
        except Exception as e:
            st.error(f"Errore nell'aggiunta misurazione: {str(e)}")
            return False
