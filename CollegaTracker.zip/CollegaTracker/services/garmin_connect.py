import os
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import streamlit as st
from garminconnect import Garmin
import time
import pickle

class GarminConnectService:
    """Service for Garmin Connect API integration"""
    
    def __init__(self):
        self.username = os.getenv("GARMIN_USERNAME", "")
        self.password = os.getenv("GARMIN_PASSWORD", "")
        self.client = None
        self.authenticated = False
        self.last_request_time = 0
        self.min_request_interval = 2  # seconds between requests
        self.session_file = "garmin_session.pkl"
        
        # Try to restore previous session first
        if self._restore_session():
            try:
                # Test if session is still valid
                self.client.get_stats(datetime.now().strftime('%Y-%m-%d'))
                self.authenticated = True
                return
            except:
                pass
        
        # If no valid session, authenticate
        if self.username and self.password:
            self._authenticate_with_retry()
    
    def _restore_session(self) -> bool:
        """Try to restore a previous session"""
        try:
            if os.path.exists(self.session_file):
                with open(self.session_file, 'rb') as f:
                    session_data = pickle.load(f)
                    if session_data.get('username') == self.username:
                        self.client = session_data.get('client')
                        return True
            return False
        except Exception:
            return False
    
    def _save_session(self):
        """Save current session"""
        try:
            session_data = {
                'username': self.username,
                'client': self.client
            }
            with open(self.session_file, 'wb') as f:
                pickle.dump(session_data, f)
        except Exception:
            pass
    
    def _authenticate_with_retry(self):
        """Authenticate with retry logic for rate limiting"""
        max_retries = 3
        retry_delay = 30  # seconds
        
        for attempt in range(max_retries):
            try:
                self.client = Garmin(self.username, self.password)
                self.client.login()
                self.authenticated = True
                self._save_session()
                break
            except Exception as e:
                error_msg = str(e)
                if '429' in error_msg or 'Too Many Requests' in error_msg:
                    if attempt < max_retries - 1:
                        st.warning(f"Rate limit raggiunto. Attesa di {retry_delay} secondi...")
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                    else:
                        st.error("Rate limit Garmin Connect. Riprova tra qualche minuto.")
                        self.authenticated = False
                else:
                    st.error(f"Errore connessione Garmin Connect: {error_msg}")
                    self.authenticated = False
                    break
    
    def _rate_limit(self):
        """Apply rate limiting between requests"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        if time_since_last_request < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last_request)
        self.last_request_time = time.time()
    
    def check_connection_status(self) -> bool:
        """Check if Garmin Connect is properly connected"""
        try:
            if not self.authenticated or not self.client:
                return False
            
            # Test connection by getting user stats
            stats = self.client.get_stats(datetime.now().strftime('%Y-%m-%d'))
            return stats is not None
        except Exception as e:
            return False
    
    def get_user_profile(self) -> Optional[Dict]:
        """Get user profile information from Garmin Connect"""
        try:
            if not self.check_connection_status():
                return None
            
            profile = self.client.get_full_name()
            user_summary = self.client.get_user_summary(datetime.now().strftime('%Y-%m-%d'))
            
            return {
                'full_name': profile,
                'user_summary': user_summary
            }
        except Exception as e:
            st.error(f"Errore nel recupero profilo utente: {str(e)}")
            return None
    
    def get_recent_activities(self, limit: int = 20) -> Optional[pd.DataFrame]:
        """Get recent activities from Garmin Connect"""
        try:
            if not self.check_connection_status():
                return pd.DataFrame()  # Return empty DataFrame instead of None
            
            # Apply rate limiting
            self._rate_limit()
            
            # Get activities from Garmin
            activities = self.client.get_activities(0, limit)
            
            if not activities:
                return pd.DataFrame()
            
            # Convert to DataFrame
            activities_list = []
            for activity in activities:
                # Handle activity type correctly
                activity_type = activity.get('activityType', {})
                if isinstance(activity_type, dict):
                    type_key = activity_type.get('typeKey', 'Unknown')
                else:
                    type_key = str(activity_type)
                
                activity_dict = {
                    'activity_id': activity.get('activityId'),
                    'date': activity.get('startTimeLocal', '').split('T')[0] if activity.get('startTimeLocal') else '',
                    'activity_type': type_key,
                    'distance': activity.get('distance', 0) / 1000 if activity.get('distance') else 0,  # Convert to km
                    'duration': activity.get('duration', 0),  # seconds
                    'avg_heart_rate': activity.get('averageHR'),
                    'max_heart_rate': activity.get('maxHR'),
                    'calories': activity.get('calories', 0),
                    'avg_pace': self._calculate_pace(activity.get('distance', 0), activity.get('duration', 0)),
                    'elevation_gain': 0,  # Not available in basic activity data
                    'activity_name': activity.get('activityName', ''),
                    'training_load': activity.get('activityTrainingLoad', 0)
                }
                activities_list.append(activity_dict)
            
            return pd.DataFrame(activities_list)
        except Exception as e:
            st.error(f"Errore nel recupero attività: {str(e)}")
            return pd.DataFrame()
    
    def get_activities_in_range(self, start_date: datetime, end_date: datetime) -> Optional[pd.DataFrame]:
        """Get activities within a specific date range"""
        try:
            if not self.check_connection_status():
                return pd.DataFrame()
            
            # Get activities for date range
            activities_list = []
            current_date = start_date
            
            while current_date <= end_date:
                try:
                    daily_activities = self.client.get_activities_by_date(current_date.strftime('%Y-%m-%d'))
                    if daily_activities:
                        for activity in daily_activities:
                            activity_dict = {
                                'activity_id': activity.get('activityId'),
                                'date': activity.get('startTimeLocal', '').split('T')[0] if activity.get('startTimeLocal') else '',
                                'activity_type': activity.get('activityType', {}).get('typeKey', 'Unknown'),
                                'distance': activity.get('distance', 0) / 1000 if activity.get('distance') else 0,
                                'duration': activity.get('duration', 0),
                                'avg_heart_rate': activity.get('averageHR'),
                                'max_heart_rate': activity.get('maxHR'),
                                'calories': activity.get('calories', 0),
                                'avg_pace': self._calculate_pace(activity.get('distance', 0), activity.get('duration', 0)),
                                'elevation_gain': activity.get('elevationGain', 0),
                                'activity_name': activity.get('activityName', '')
                            }
                            activities_list.append(activity_dict)
                except Exception:
                    pass  # Skip days with no data or errors
                
                current_date += timedelta(days=1)
            
            return pd.DataFrame(activities_list)
        except Exception as e:
            st.error(f"Errore nel recupero attività per range date: {str(e)}")
            return pd.DataFrame()
    
    def get_workout_details(self, activity_id: str) -> Optional[pd.DataFrame]:
        """Get detailed data for a specific workout"""
        try:
            if not self.check_connection_status():
                return pd.DataFrame()
            
            # Get detailed activity data
            activity_details = self.client.get_activity_by_id(activity_id)
            
            if not activity_details:
                return pd.DataFrame()
            
            # Convert to DataFrame format for detailed analysis
            details_dict = {
                'activity_id': activity_details.get('activityId'),
                'start_time': activity_details.get('startTimeLocal'),
                'distance': activity_details.get('distance', 0) / 1000,
                'duration': activity_details.get('duration', 0),
                'moving_duration': activity_details.get('movingDuration', 0),
                'avg_speed': activity_details.get('avgSpeed'),
                'max_speed': activity_details.get('maxSpeed'),
                'avg_heart_rate': activity_details.get('averageHR'),
                'max_heart_rate': activity_details.get('maxHR'),
                'avg_power': activity_details.get('avgPower'),
                'max_power': activity_details.get('maxPower'),
                'training_stress_score': activity_details.get('trainingStressScore'),
                'calories': activity_details.get('calories'),
                'elevation_gain': activity_details.get('elevationGain'),
                'elevation_loss': activity_details.get('elevationLoss')
            }
            
            return pd.DataFrame([details_dict])
        except Exception as e:
            st.error(f"Errore nel recupero dettagli workout: {str(e)}")
            return pd.DataFrame()
    
    def sync_latest_activities(self) -> bool:
        """Sync latest activities and biometric data from Garmin Connect"""
        try:
            if not self.check_connection_status():
                return False
            
            # Get latest activities
            recent_activities = self.get_recent_activities(10)
            
            # Get today's biometric data
            today = datetime.now()
            
            # Sync sleep data
            sleep_data = self.get_sleep_data(today)
            
            # Sync stress data
            stress_data = self.get_stress_data(today)
            
            # Sync HRV data
            hrv_data = self.get_heart_rate_variability(today)
            
            # Get daily stats
            daily_stats = self.get_daily_stats(today)
            
            success_count = 0
            if recent_activities is not None and not recent_activities.empty:
                success_count += 1
            if sleep_data:
                success_count += 1
            if stress_data:
                success_count += 1
            if hrv_data:
                success_count += 1
            if daily_stats:
                success_count += 1
            
            return success_count > 0
            
        except Exception as e:
            st.error(f"Errore nella sincronizzazione: {str(e)}")
            return False
    
    def sync_historical_data(self, months_back: int = 12) -> Dict[str, int]:
        """Sync historical data for the last N months"""
        try:
            if not self.check_connection_status():
                return {'error': 1}
            
            end_date = datetime.now()
            start_date = end_date - timedelta(days=months_back * 30)
            
            st.info(f"Sincronizzazione dati storici dal {start_date.strftime('%d/%m/%Y')} al {end_date.strftime('%d/%m/%Y')}")
            
            # Get all activities in batches
            all_activities = []
            batch_size = 100
            offset = 0
            
            while True:
                batch_activities = self.client.get_activities(offset, batch_size)
                if not batch_activities:
                    break
                
                # Filter activities within date range
                for activity in batch_activities:
                    activity_date_str = activity.get('startTimeLocal', '').split('T')[0]
                    if activity_date_str:
                        activity_date = datetime.strptime(activity_date_str, '%Y-%m-%d')
                        if activity_date >= start_date:
                            all_activities.append(activity)
                        elif activity_date < start_date:
                            # Activities are sorted by date, so we can stop here
                            break
                
                offset += batch_size
                if len(batch_activities) < batch_size:
                    break
            
            # Process historical biometric data
            biometric_data_count = 0
            current_date = start_date
            
            while current_date <= end_date:
                try:
                    # Get daily stats
                    daily_stats = self.get_daily_stats(current_date)
                    if daily_stats:
                        biometric_data_count += 1
                    
                    # Get sleep data
                    sleep_data = self.get_sleep_data(current_date)
                    if sleep_data:
                        biometric_data_count += 1
                        
                except Exception:
                    pass  # Skip days with errors
                
                current_date += timedelta(days=1)
            
            return {
                'activities': len(all_activities),
                'biometric_days': biometric_data_count,
                'period_days': (end_date - start_date).days
            }
            
        except Exception as e:
            st.error(f"Errore sincronizzazione storica: {str(e)}")
            return {'error': 1}
    
    def get_activity_summary_year(self) -> Optional[Dict]:
        """Get comprehensive activity summary for the last year"""
        try:
            if not self.check_connection_status():
                return None
            
            # Get last 365 days of activities
            activities = self.client.get_activities(0, 500)  # Get more activities
            
            if not activities:
                return None
            
            # Process activities data
            summary = {
                'total_activities': len(activities),
                'total_distance': 0,
                'total_duration': 0,
                'total_calories': 0,
                'activity_types': {},
                'monthly_summary': {},
                'best_performances': {}
            }
            
            for activity in activities:
                # Basic totals
                summary['total_distance'] += activity.get('distance', 0) / 1000
                summary['total_duration'] += activity.get('duration', 0)
                summary['total_calories'] += activity.get('calories', 0)
                
                # Activity type breakdown
                activity_type = activity.get('activityType', {})
                if isinstance(activity_type, dict):
                    type_key = activity_type.get('typeKey', 'Unknown')
                else:
                    type_key = str(activity_type)
                
                if type_key not in summary['activity_types']:
                    summary['activity_types'][type_key] = {'count': 0, 'distance': 0, 'duration': 0}
                
                summary['activity_types'][type_key]['count'] += 1
                summary['activity_types'][type_key]['distance'] += activity.get('distance', 0) / 1000
                summary['activity_types'][type_key]['duration'] += activity.get('duration', 0)
                
                # Monthly breakdown
                activity_date = activity.get('startTimeLocal', '').split('T')[0]
                if activity_date:
                    month_key = activity_date[:7]  # YYYY-MM
                    if month_key not in summary['monthly_summary']:
                        summary['monthly_summary'][month_key] = {'count': 0, 'distance': 0, 'duration': 0}
                    
                    summary['monthly_summary'][month_key]['count'] += 1
                    summary['monthly_summary'][month_key]['distance'] += activity.get('distance', 0) / 1000
                    summary['monthly_summary'][month_key]['duration'] += activity.get('duration', 0)
            
            return summary
            
        except Exception as e:
            st.error(f"Errore nel recupero riepilogo annuale: {str(e)}")
            return None
    
    def get_sleep_data(self, date: datetime) -> Optional[Dict]:
        """Get sleep data for a specific date"""
        try:
            if not self.check_connection_status():
                return None
            
            sleep_data = self.client.get_sleep_data(date.strftime('%Y-%m-%d'))
            
            if sleep_data:
                return {
                    'date': date.strftime('%Y-%m-%d'),
                    'sleep_hours': sleep_data.get('sleepTimeSeconds', 0) / 3600,
                    'deep_sleep_hours': sleep_data.get('deepSleepSeconds', 0) / 3600,
                    'light_sleep_hours': sleep_data.get('lightSleepSeconds', 0) / 3600,
                    'rem_sleep_hours': sleep_data.get('remSleepSeconds', 0) / 3600,
                    'awake_hours': sleep_data.get('awakeTimeSeconds', 0) / 3600,
                    'sleep_score': sleep_data.get('sleepScore')
                }
            
            return None
        except Exception as e:
            st.error(f"Errore nel recupero dati sonno: {str(e)}")
            return None
    
    def get_stress_data(self, date: datetime) -> Optional[Dict]:
        """Get stress data for a specific date"""
        try:
            if not self.check_connection_status():
                return None
            
            stress_data = self.client.get_stress_data(date.strftime('%Y-%m-%d'))
            
            if stress_data:
                return {
                    'date': date.strftime('%Y-%m-%d'),
                    'overall_stress_level': stress_data.get('overallStressLevel'),
                    'rest_stress_duration': stress_data.get('restStressDuration'),
                    'activity_stress_duration': stress_data.get('activityStressDuration'),
                    'low_stress_duration': stress_data.get('lowStressDuration'),
                    'medium_stress_duration': stress_data.get('mediumStressDuration'),
                    'high_stress_duration': stress_data.get('highStressDuration')
                }
            
            return None
        except Exception as e:
            st.error(f"Errore nel recupero dati stress: {str(e)}")
            return None
    
    def get_heart_rate_variability(self, date: datetime) -> Optional[Dict]:
        """Get HRV data for a specific date"""
        try:
            if not self.check_connection_status():
                return None
            
            hrv_data = self.client.get_hrv_data(date.strftime('%Y-%m-%d'))
            
            if hrv_data:
                return {
                    'date': date.strftime('%Y-%m-%d'),
                    'weekly_avg': hrv_data.get('weeklyAvg'),
                    'last_night_avg': hrv_data.get('lastNightAvg'),
                    'last_night_5_min_high': hrv_data.get('lastNight5MinHigh'),
                    'baseline': hrv_data.get('baseline'),
                    'status': hrv_data.get('status')
                }
            
            return None
        except Exception as e:
            st.error(f"Errore nel recupero dati HRV: {str(e)}")
            return None
    
    def _calculate_pace(self, distance_meters: float, duration_seconds: float) -> float:
        """Calculate pace in minutes per kilometer"""
        if distance_meters == 0 or duration_seconds == 0:
            return 0.0
        
        distance_km = distance_meters / 1000
        pace_seconds_per_km = duration_seconds / distance_km
        pace_minutes_per_km = pace_seconds_per_km / 60
        
        return pace_minutes_per_km
    
    def get_daily_stats(self, date: datetime) -> Optional[Dict]:
        """Get comprehensive daily statistics"""
        try:
            if not self.check_connection_status():
                return None
            
            date_str = date.strftime('%Y-%m-%d')
            
            # Get multiple data sources
            stats = self.client.get_stats(date_str)
            steps_data = self.client.get_steps_data(date_str)
            heart_rate_data = self.client.get_heart_rates(date_str)
            
            return {
                'date': date_str,
                'stats': stats,
                'steps': steps_data,
                'heart_rate': heart_rate_data
            }
            
        except Exception as e:
            return None
    
    def get_body_composition(self, date: datetime) -> Optional[Dict]:
        """Get body composition data"""
        try:
            if not self.check_connection_status():
                return None
            
            body_data = self.client.get_body_composition(date.strftime('%Y-%m-%d'))
            return body_data
            
        except Exception as e:
            return None