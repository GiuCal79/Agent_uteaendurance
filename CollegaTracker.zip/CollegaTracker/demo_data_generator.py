import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List
import random

class DemoDataGenerator:
    """Generates realistic demo data based on verified user activity types"""
    
    def __init__(self):
        # Based on verified user activities: swimming and breathwork
        self.activity_types = {
            'lap_swimming': {'weight': 0.4, 'avg_duration': 45, 'avg_distance': 1.5},
            'breathwork': {'weight': 0.3, 'avg_duration': 20, 'avg_distance': 0},
            'running': {'weight': 0.2, 'avg_duration': 35, 'avg_distance': 5.5},
            'cycling': {'weight': 0.1, 'avg_duration': 60, 'avg_distance': 20}
        }
    
    def generate_activities_year(self, num_activities: int = 120) -> pd.DataFrame:
        """Generate a year of realistic activities"""
        activities = []
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)
        
        for i in range(num_activities):
            # Random date within the year
            random_days = random.randint(0, 365)
            activity_date = start_date + timedelta(days=random_days)
            
            # Choose activity type based on weights
            activity_type = np.random.choice(
                list(self.activity_types.keys()),
                p=list(self.activity_types[act]['weight'] for act in self.activity_types.keys())
            )
            
            config = self.activity_types[activity_type]
            
            # Generate realistic metrics
            duration_minutes = np.random.normal(config['avg_duration'], config['avg_duration'] * 0.2)
            duration_minutes = max(10, duration_minutes)  # Minimum 10 minutes
            
            if config['avg_distance'] > 0:
                distance = np.random.normal(config['avg_distance'], config['avg_distance'] * 0.3)
                distance = max(0.5, distance)
            else:
                distance = 0
            
            # Heart rate zones based on activity type
            if activity_type == 'breathwork':
                avg_hr = np.random.normal(70, 10)
                max_hr = avg_hr + random.randint(5, 15)
            elif activity_type == 'lap_swimming':
                avg_hr = np.random.normal(145, 15)
                max_hr = avg_hr + random.randint(20, 35)
            elif activity_type == 'running':
                avg_hr = np.random.normal(155, 20)
                max_hr = avg_hr + random.randint(25, 40)
            else:  # cycling
                avg_hr = np.random.normal(140, 18)
                max_hr = avg_hr + random.randint(20, 35)
            
            # Ensure realistic HR values
            avg_hr = max(60, min(180, avg_hr))
            max_hr = max(avg_hr + 10, min(200, max_hr))
            
            # Calculate calories based on duration and intensity
            if activity_type == 'breathwork':
                calories = duration_minutes * 2  # Very low calorie burn
            elif activity_type == 'lap_swimming':
                calories = duration_minutes * 12  # High calorie burn
            elif activity_type == 'running':
                calories = duration_minutes * 10
            else:  # cycling
                calories = duration_minutes * 8
            
            activities.append({
                'activity_id': f"demo_{i}",
                'date': activity_date.strftime('%Y-%m-%d'),
                'activity_type': activity_type,
                'duration_seconds': int(duration_minutes * 60),
                'distance_meters': distance * 1000 if distance > 0 else 0,
                'avg_heart_rate': int(avg_hr),
                'max_heart_rate': int(max_hr),
                'calories': int(calories),
                'avg_pace': self._calculate_pace(distance, duration_minutes) if distance > 0 else 0,
                'elevation_gain': random.randint(0, 50) if activity_type != 'lap_swimming' else 0,
                'training_stress_score': self._calculate_tss(duration_minutes, avg_hr),
                'avg_cadence': random.randint(160, 180) if activity_type == 'running' else 0
            })
        
        return pd.DataFrame(activities).sort_values('date', ascending=False)
    
    def generate_biometric_data(self, days: int = 90) -> Dict:
        """Generate realistic biometric data"""
        end_date = datetime.now()
        dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(days)]
        
        return {
            'sleep_data': self._generate_sleep_data(dates),
            'hrv_data': self._generate_hrv_data(dates),
            'stress_data': self._generate_stress_data(dates),
            'body_battery': self._generate_body_battery_data(dates),
            'resting_hr': self._generate_resting_hr_data(dates)
        }
    
    def _calculate_pace(self, distance_km: float, duration_minutes: float) -> float:
        """Calculate pace in minutes per km"""
        if distance_km <= 0:
            return 0
        return duration_minutes / distance_km
    
    def _calculate_tss(self, duration_minutes: float, avg_hr: float) -> int:
        """Calculate Training Stress Score"""
        # Simplified TSS calculation
        intensity_factor = avg_hr / 180  # Assuming max HR of 180
        normalized_power = intensity_factor ** 4
        tss = (duration_minutes * normalized_power * intensity_factor) / 60 * 100
        return max(1, int(tss))
    
    def _generate_sleep_data(self, dates: List[str]) -> List[Dict]:
        """Generate realistic sleep data"""
        sleep_data = []
        for date in dates:
            sleep_hours = np.random.normal(7.5, 1.2)
            sleep_hours = max(5, min(10, sleep_hours))
            
            deep_sleep = sleep_hours * np.random.uniform(0.15, 0.25)
            light_sleep = sleep_hours * np.random.uniform(0.45, 0.65)
            rem_sleep = sleep_hours * np.random.uniform(0.20, 0.30)
            awake_time = sleep_hours - (deep_sleep + light_sleep + rem_sleep)
            
            sleep_data.append({
                'date': date,
                'total_sleep_hours': round(sleep_hours, 1),
                'deep_sleep_hours': round(deep_sleep, 1),
                'light_sleep_hours': round(light_sleep, 1),
                'rem_sleep_hours': round(rem_sleep, 1),
                'awake_hours': round(max(0, awake_time), 1),
                'sleep_score': random.randint(65, 95)
            })
        
        return sleep_data
    
    def _generate_hrv_data(self, dates: List[str]) -> List[Dict]:
        """Generate realistic HRV data"""
        return [
            {
                'date': date,
                'hrv_score': random.randint(25, 65),
                'rmssd': np.random.normal(35, 10)
            }
            for date in dates
        ]
    
    def _generate_stress_data(self, dates: List[str]) -> List[Dict]:
        """Generate realistic stress data"""
        return [
            {
                'date': date,
                'avg_stress': random.randint(15, 75),
                'max_stress': random.randint(30, 95),
                'stress_score': random.randint(1, 100)
            }
            for date in dates
        ]
    
    def _generate_body_battery_data(self, dates: List[str]) -> List[Dict]:
        """Generate realistic Body Battery data"""
        return [
            {
                'date': date,
                'charged': random.randint(70, 100),
                'drained': random.randint(20, 60),
                'highest': random.randint(80, 100),
                'lowest': random.randint(5, 30)
            }
            for date in dates
        ]
    
    def _generate_resting_hr_data(self, dates: List[str]) -> List[Dict]:
        """Generate realistic resting heart rate data"""
        base_rhr = 55
        return [
            {
                'date': date,
                'resting_heart_rate': base_rhr + np.random.normal(0, 5)
            }
            for date in dates
        ]