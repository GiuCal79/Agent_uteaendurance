import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta, time
from services.data_analysis import DataAnalysisService

st.set_page_config(page_title="Lifestyle Routines", page_icon="🌱", layout="wide")

@st.cache_resource
def init_services():
    data_analysis_service = DataAnalysisService()
    return data_analysis_service

def main():
    st.title("🌱 Routine di Lifestyle")
    st.markdown("### Ottimizzazione delle abitudini quotidiane per performance ultra-endurance")
    
    try:
        data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Daily routine builder
    st.subheader("🕐 Costruttore Routine Giornaliera")
    
    with st.expander("➕ Crea/Modifica Routine", expanded=True):
        routine_type = st.selectbox(
            "Tipo di routine",
            ["Giorno di Allenamento", "Giorno di Recupero", "Giorno di Gara", "Routine Personalizzata"]
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🌅 Routine Mattutina")
            
            morning_routine = {}
            morning_routine['wake_time'] = st.time_input("Sveglia", value=time(6, 0))
            morning_routine['meditation'] = st.checkbox("Meditazione (10 min)")
            morning_routine['mobility'] = st.checkbox("Mobilità/Stretching (15 min)")
            morning_routine['cold_shower'] = st.checkbox("Doccia fredda (2-3 min)")
            morning_routine['breakfast_time'] = st.time_input("Colazione", value=time(7, 0))
            morning_routine['supplements'] = st.multiselect(
                "Integratori mattutini",
                ["Vitamina D", "Omega-3", "Magnesio", "Vitamina B12", "Probiotici", "Creatina"]
            )
            morning_routine['hydration'] = st.number_input("Acqua al risveglio (ml)", min_value=0, max_value=1000, value=500, step=50)
        
        with col2:
            st.markdown("#### 🌙 Routine Serale")
            
            evening_routine = {}
            evening_routine['dinner_time'] = st.time_input("Cena", value=time(19, 0))
            evening_routine['screen_cutoff'] = st.time_input("Stop schermi", value=time(21, 0))
            evening_routine['reading'] = st.checkbox("Lettura (30 min)")
            evening_routine['gratitude_journal'] = st.checkbox("Diario gratitudine")
            evening_routine['sleep_prep'] = st.checkbox("Preparazione sonno (camera fresca, buio)")
            evening_routine['bedtime'] = st.time_input("A letto entro", value=time(22, 30))
            evening_routine['sleep_target'] = st.number_input("Ore sonno target", min_value=6.0, max_value=10.0, value=8.0, step=0.5)
        
        if st.button("💾 Salva Routine", use_container_width=True):
            routine_data = {
                'type': routine_type,
                'morning': morning_routine,
                'evening': evening_routine,
                'created_date': datetime.now()
            }
            
            try:
                # Save routine data
                st.success(f"✅ Routine '{routine_type}' salvata con successo!")
            except Exception as e:
                st.error(f"Errore nel salvare la routine: {str(e)}")
    
    # Today's routine tracking
    st.subheader("📋 Tracking Routine Oggi")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("#### 🌅 Mattina")
        
        # Morning checklist
        morning_tasks = [
            "Sveglia all'orario previsto",
            "Meditazione completata",
            "Mobilità/Stretching fatto",
            "Doccia fredda",
            "Colazione sana",
            "Integratori presi",
            "Idratazione adeguata"
        ]
        
        morning_completed = []
        for task in morning_tasks:
            completed = st.checkbox(task, key=f"morning_{task}")
            if completed:
                morning_completed.append(task)
        
        morning_score = len(morning_completed) / len(morning_tasks) * 100
        st.progress(morning_score / 100)
        st.metric("Completamento Mattina", f"{morning_score:.0f}%")
    
    with col2:
        st.markdown("#### 🏃‍♂️ Giorno")
        
        # Daily activities
        st.markdown("##### Allenamento")
        workout_completed = st.checkbox("Allenamento completato")
        workout_quality = st.slider("Qualità allenamento", 1, 10, 7) if workout_completed else 0
        
        st.markdown("##### Alimentazione")
        meals_planned = st.checkbox("Pasti seguiti come pianificato")
        hydration_target = st.checkbox("Obiettivo idratazione raggiunto")
        
        st.markdown("##### Energia e Umore")
        energy_level = st.slider("Livello energia", 1, 10, 7)
        mood_score = st.slider("Umore", 1, 10, 7)
        stress_level = st.slider("Livello stress", 1, 10, 3)
    
    with col3:
        st.markdown("#### 🌙 Sera")
        
        # Evening checklist
        evening_tasks = [
            "Cena all'orario previsto",
            "Stop schermi rispettato",
            "Tempo per lettura",
            "Diario gratitudine",
            "Camera preparata per sonno",
            "A letto all'orario target"
        ]
        
        evening_completed = []
        for task in evening_tasks:
            completed = st.checkbox(task, key=f"evening_{task}")
            if completed:
                evening_completed.append(task)
        
        evening_score = len(evening_completed) / len(evening_tasks) * 100
        st.progress(evening_score / 100)
        st.metric("Completamento Sera", f"{evening_score:.0f}%")
    
    # Save today's tracking
    if st.button("💾 Salva Tracking Giornaliero", use_container_width=True):
        daily_tracking = {
            'date': date.today(),
            'morning_score': morning_score,
            'morning_completed': morning_completed,
            'workout_completed': workout_completed,
            'workout_quality': workout_quality,
            'meals_planned': meals_planned,
            'hydration_target': hydration_target,
            'energy_level': energy_level,
            'mood_score': mood_score,
            'stress_level': stress_level,
            'evening_score': evening_score,
            'evening_completed': evening_completed
        }
        
        try:
            # Save daily tracking
            st.success("✅ Tracking giornaliero salvato!")
        except Exception as e:
            st.error(f"Errore nel salvare il tracking: {str(e)}")
    
    # Habits analysis
    st.subheader("📊 Analisi Abitudini")
    
    try:
        # Get historical habit data
        habits_data = data_analysis_service.get_habits_data(days=30)
        
        if habits_data is not None and not habits_data.empty:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📈 Trend Completamento Routine")
                
                # Calculate daily completion scores
                habits_data['total_score'] = (habits_data['morning_score'] + habits_data['evening_score']) / 2
                
                fig = px.line(
                    habits_data,
                    x='date',
                    y=['morning_score', 'evening_score', 'total_score'],
                    title="Completamento Routine Giornaliere (%)",
                    labels={'value': 'Completamento (%)', 'variable': 'Routine'}
                )
                fig.add_hline(y=80, line_dash="dash", annotation_text="Target 80%")
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("#### 🎯 Consistenza Abitudini")
                
                # Calculate habit consistency
                habit_consistency = {
                    'Meditazione': habits_data['meditation_completed'].mean() * 100,
                    'Esercizio Fisico': habits_data['workout_completed'].mean() * 100,
                    'Sonno Regolare': habits_data['sleep_target_met'].mean() * 100,
                    'Alimentazione': habits_data['meals_planned'].mean() * 100,
                    'Idratazione': habits_data['hydration_target'].mean() * 100
                }
                
                consistency_df = pd.DataFrame(
                    list(habit_consistency.items()),
                    columns=['Abitudine', 'Consistenza (%)']
                )
                
                fig = px.bar(
                    consistency_df,
                    x='Abitudine',
                    y='Consistenza (%)',
                    title="Consistenza Abitudini Chiave",
                    color='Consistenza (%)',
                    color_continuous_scale='RdYlGn'
                )
                fig.add_hline(y=80, line_dash="dash", annotation_text="Target 80%")
                st.plotly_chart(fig, use_container_width=True)
            
            # Weekly pattern analysis
            st.markdown("#### 📅 Pattern Settimanali")
            
            habits_data['day_of_week'] = pd.to_datetime(habits_data['date']).dt.day_name()
            weekly_pattern = habits_data.groupby('day_of_week').agg({
                'total_score': 'mean',
                'energy_level': 'mean',
                'mood_score': 'mean',
                'stress_level': 'mean'
            }).reset_index()
            
            # Reorder days
            day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            weekly_pattern['day_of_week'] = pd.Categorical(weekly_pattern['day_of_week'], categories=day_order, ordered=True)
            weekly_pattern = weekly_pattern.sort_values('day_of_week')
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.bar(
                    weekly_pattern,
                    x='day_of_week',
                    y='total_score',
                    title="Completamento Routine per Giorno della Settimana",
                    color='total_score',
                    color_continuous_scale='Viridis'
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                fig = go.Figure()
                
                fig.add_trace(go.Scatter(
                    x=weekly_pattern['day_of_week'],
                    y=weekly_pattern['energy_level'],
                    mode='lines+markers',
                    name='Energia',
                    line=dict(color='green')
                ))
                
                fig.add_trace(go.Scatter(
                    x=weekly_pattern['day_of_week'],
                    y=weekly_pattern['mood_score'],
                    mode='lines+markers',
                    name='Umore',
                    line=dict(color='blue')
                ))
                
                fig.add_trace(go.Scatter(
                    x=weekly_pattern['day_of_week'],
                    y=10 - weekly_pattern['stress_level'],  # Invert stress for better visualization
                    mode='lines+markers',
                    name='Benessere (10-stress)',
                    line=dict(color='orange')
                ))
                
                fig.update_layout(
                    title="Energia, Umore e Benessere per Giorno della Settimana",
                    yaxis_title="Punteggio (1-10)"
                )
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Dati abitudini insufficienti per l'analisi. Inizia a tracciare le tue routine!")
    except Exception as e:
        st.error(f"Errore nell'analisi abitudini: {str(e)}")
    
    # Sleep optimization
    st.subheader("😴 Ottimizzazione Sonno")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 🛏️ Analisi Qualità Sonno")
        
        try:
            sleep_data = data_analysis_service.get_sleep_analysis()
            
            if sleep_data:
                st.metric("Ore Sonno Media", f"{sleep_data.get('avg_sleep_hours', 0):.1f}h")
                st.metric("Qualità Sonno", f"{sleep_data.get('sleep_quality', 0):.1f}/10")
                st.metric("Efficienza Sonno", f"{sleep_data.get('sleep_efficiency', 0):.1f}%")
                
                # Sleep debt calculation
                sleep_debt = (8.0 - sleep_data.get('avg_sleep_hours', 8.0)) * 7  # Weekly debt
                if sleep_debt > 0:
                    st.warning(f"⚠️ Debito sonno settimanale: {sleep_debt:.1f}h")
                else:
                    st.success("✅ Sonno adeguato")
            else:
                st.info("Dati sonno non disponibili")
        except Exception as e:
            st.error(f"Errore nell'analisi sonno: {str(e)}")
    
    with col2:
        st.markdown("#### 💡 Raccomandazioni Sonno")
        
        sleep_recommendations = [
            "🌡️ Mantieni camera a 18-20°C",
            "🌑 Ambiente completamente buio",
            "📱 No schermi 1h prima di dormire",
            "☕ Evita caffeina dopo le 14:00",
            "🧘 Routine rilassante pre-sonno",
            "⏰ Orari sonno regolari anche nel weekend",
            "🏃‍♂️ Evita allenamenti intensi 3h prima di dormire"
        ]
        
        for rec in sleep_recommendations:
            st.markdown(f"• {rec}")
    
    # Stress management
    st.subheader("🧘‍♂️ Gestione Stress e Recupero")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("#### 🧘 Tecniche di Rilassamento")
        
        relaxation_techniques = st.multiselect(
            "Seleziona tecniche praticate oggi",
            [
                "Respirazione profonda (4-7-8)",
                "Meditazione mindfulness",
                "Yoga/Stretching",
                "Bagno caldo",
                "Musica rilassante",
                "Lettura",
                "Passeggiata nella natura",
                "Massaggio auto-rilascio"
            ]
        )
        
        relaxation_duration = st.number_input(
            "Tempo totale rilassamento (min)",
            min_value=0, max_value=120, value=20, step=5
        )
    
    with col2:
        st.markdown("#### ⚡ Gestione Energia")
        
        energy_strategies = st.multiselect(
            "Strategie energia utilizzate",
            [
                "Power nap (10-20 min)",
                "Esposizione luce naturale",
                "Movimento regolare",
                "Spuntini bilanciati",
                "Idratazione frequente",
                "Pause lavoro programmate",
                "Respirazione energizzante"
            ]
        )
        
        caffeine_intake = st.number_input(
            "Caffeina consumata (mg)",
            min_value=0, max_value=500, value=0, step=25
        )
    
    with col3:
        st.markdown("#### 🔄 Recupero Attivo")
        
        recovery_activities = st.multiselect(
            "Attività recupero oggi",
            [
                "Foam rolling",
                "Stretching dinamico",
                "Camminata leggera",
                "Nuoto rilassante",
                "Sauna/Bagno turco",
                "Crioterapia",
                "Massaggio",
                "Yoga restorative"
            ]
        )
        
        recovery_quality = st.slider(
            "Qualità recupero percepita",
            1, 10, 7
        )
    
    # Weekly lifestyle report
    st.subheader("📋 Report Settimanale Lifestyle")
    
    if st.button("📊 Genera Report Settimanale", use_container_width=True):
        try:
            weekly_report = data_analysis_service.generate_weekly_lifestyle_report()
            
            if weekly_report:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### 🎯 Obiettivi Raggiunti")
                    
                    goals_achieved = weekly_report.get('goals_achieved', {})
                    for goal, achieved in goals_achieved.items():
                        if achieved:
                            st.success(f"✅ {goal}")
                        else:
                            st.error(f"❌ {goal}")
                
                with col2:
                    st.markdown("#### 📈 Aree di Miglioramento")
                    
                    improvements = weekly_report.get('improvement_areas', [])
                    for improvement in improvements:
                        st.warning(f"⚠️ {improvement}")
                
                st.markdown("#### 💡 Raccomandazioni per la Prossima Settimana")
                recommendations = weekly_report.get('recommendations', [])
                for rec in recommendations:
                    st.info(f"💡 {rec}")
            else:
                st.info("Dati insufficienti per generare il report settimanale")
        except Exception as e:
            st.error(f"Errore nella generazione del report: {str(e)}")

if __name__ == "__main__":
    main()
