import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import numpy as np
from services.garmin_connect import GarminConnectService
from services.data_analysis import DataAnalysisService
from services.integrations import IntegrationsService
from utils.helpers import format_duration, calculate_zones
from cache_manager import CacheManager

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")

# Initialize services
@st.cache_resource
def init_services():
    garmin_service = GarminConnectService()
    data_analysis_service = DataAnalysisService()
    integrations_service = IntegrationsService()
    cache_manager = CacheManager()
    return garmin_service, data_analysis_service, integrations_service, cache_manager

def main():
    st.title("📊 Dashboard Completa")
    st.markdown("### Panoramica completa delle tue performance e progressi")
    
    try:
        garmin_service, data_analysis_service, integrations_service, cache_manager = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Time period selector
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        period = st.selectbox(
            "Periodo di analisi",
            ["Ultima settimana", "Ultimo mese", "Ultimi 3 mesi", "Anno corrente"],
            index=1
        )
    
    with col2:
        activity_filter = st.multiselect(
            "Filtra attività",
            ["Running", "Cycling", "Swimming", "Walking", "Altro"],
            default=["Running", "Cycling"]
        )
    
    # Calculate date range based on period
    end_date = datetime.now()
    if period == "Ultima settimana":
        start_date = end_date - timedelta(weeks=1)
    elif period == "Ultimo mese":
        start_date = end_date - timedelta(days=30)
    elif period == "Ultimi 3 mesi":
        start_date = end_date - timedelta(days=90)
    else:  # Anno corrente
        start_date = datetime(end_date.year, 1, 1)
    
    # Connection status and real-time data sync
    st.subheader("🔗 Stato Connessioni e Dati in Tempo Reale")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if garmin_service.check_connection_status():
            st.success("✅ Garmin Connect: Connesso")
            
            col_sync1, col_sync2 = st.columns(2)
            with col_sync1:
                if st.button("🔄 Sincronizza Recenti"):
                    with st.spinner("Sincronizzazione dati recenti..."):
                        success = garmin_service.sync_latest_activities()
                        if success:
                            st.success("Dati recenti sincronizzati!")
                            st.rerun()
                        else:
                            st.error("Errore sincronizzazione")
            
            with col_sync2:
                if st.button("📈 Carica Anno Completo"):
                    with st.spinner("Caricamento dati ultimo anno..."):
                        historical_data = garmin_service.sync_historical_data(12)
                        if 'error' not in historical_data:
                            st.success(f"Caricati {historical_data['activities']} allenamenti e {historical_data['biometric_days']} giorni di dati biometrici")
                            st.rerun()
                        else:
                            st.error("Errore nel caricamento storico")
        else:
            st.error("❌ Garmin Connect: Disconnesso")
            st.warning("⚠️ Rate limit raggiunto. Garmin Connect limita il numero di richieste per prevenire abusi.")
            
            col_retry, col_wait = st.columns(2)
            with col_retry:
                if st.button("🔄 Riprova Ora"):
                    with st.spinner("Tentativo di riconnessione..."):
                        # Clear session and retry
                        import os
                        if os.path.exists("garmin_session.pkl"):
                            os.remove("garmin_session.pkl")
                        st.rerun()
            
            with col_wait:
                if st.button("⏱️ Attendi 5 minuti"):
                    st.info("Il rate limit di Garmin Connect si resetta automaticamente. Riprova tra qualche minuto.")
            
            st.info("💡 Per continuare a usare la piattaforma:")
            st.write("• Attendi 5-10 minuti per il reset automatico del limite")
            st.write("• Verifica che le credenziali Garmin siano corrette")
            st.write("• I dati sincronizzati precedentemente rimangono disponibili")
    
    with col2:
        # Check Yazio connection
        connection_status = integrations_service.get_all_connection_status()
        if connection_status.get("Yazio", False):
            st.success("✅ Yazio: Connesso")
            if st.button("🔄 Sincronizza Dati Nutrizionali"):
                with st.spinner("Sincronizzazione dati Yazio..."):
                    today = datetime.now().date()
                    nutrition_data = integrations_service.get_daily_nutrition(today)
                    if nutrition_data:
                        st.success("Dati nutrizionali sincronizzati!")
                        st.json(nutrition_data)
                    else:
                        st.warning("Nessun dato nutrizionale trovato per oggi")
        else:
            st.error("❌ Yazio: Disconnesso")
            st.info("Verifica le credenziali API Yazio nelle impostazioni")
    
    with col3:
        st.info("ℹ️ Fitdays: Non configurato")
    
    # Real-time biometric data section
    if garmin_service.check_connection_status():
        st.subheader("📊 Dati Biometrici Oggi")
        today = datetime.now()
        
        # Get today's comprehensive data
        daily_stats = garmin_service.get_daily_stats(today)
        sleep_data = garmin_service.get_sleep_data(today)
        
        if daily_stats and 'stats' in daily_stats:
            stats = daily_stats['stats']
            
            col1, col2, col3, col4, col5 = st.columns(5)
            
            with col1:
                total_steps = stats.get('totalSteps', 0)
                step_goal = stats.get('dailyStepGoal', 10000)
                st.metric("Passi Oggi", f"{total_steps:,}", f"Goal: {step_goal:,}")
            
            with col2:
                resting_hr = stats.get('restingHeartRate', 0)
                avg_7d_rhr = stats.get('lastSevenDaysAvgRestingHeartRate', 0)
                delta_hr = resting_hr - avg_7d_rhr if avg_7d_rhr else 0
                st.metric("FC Riposo", f"{resting_hr} bpm", f"{delta_hr:+d} vs 7gg")
            
            with col3:
                body_battery = stats.get('bodyBatteryMostRecentValue', 0)
                bb_charged = stats.get('bodyBatteryChargedValue', 0)
                st.metric("Body Battery", f"{body_battery}%", f"+{bb_charged} ricarica")
            
            with col4:
                avg_stress = stats.get('averageStressLevel', 0)
                stress_qualifier = stats.get('stressQualifier', 'N/A')
                st.metric("Stress Medio", f"{avg_stress}/100", f"{stress_qualifier}")
            
            with col5:
                total_calories = stats.get('totalKilocalories', 0)
                active_calories = stats.get('activeKilocalories', 0)
                st.metric("Calorie Totali", f"{total_calories:.0f}", f"{active_calories:.0f} attive")
        
        # Sleep data display
        if sleep_data and 'dailySleepDTO' in sleep_data:
            sleep_summary = sleep_data['dailySleepDTO']
            
            st.subheader("😴 Dati Sonno Ultima Notte")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                sleep_hours = sleep_summary.get('sleepTimeSeconds', 0) / 3600
                st.metric("Ore Sonno", f"{sleep_hours:.1f}h")
            
            with col2:
                deep_sleep = sleep_summary.get('deepSleepSeconds', 0) / 3600
                st.metric("Sonno Profondo", f"{deep_sleep:.1f}h")
            
            with col3:
                hrv_avg = sleep_data.get('avgOvernightHrv', 0)
                hrv_status = sleep_data.get('hrvStatus', 'N/A')
                st.metric("HRV Media", f"{hrv_avg:.1f}ms", f"{hrv_status}")
            
            with col4:
                bb_change = sleep_data.get('bodyBatteryChange', 0)
                resting_hr_sleep = sleep_data.get('restingHeartRate', 0)
                st.metric("FC Riposo Notte", f"{resting_hr_sleep} bpm", f"BB: {bb_change:+d}")
    
    st.divider()
    
    # Load data
    try:
        activities_data = garmin_service.get_activities_in_range(start_date, end_date)
        if activities_data is None or activities_data.empty:
            st.warning("Nessun dato disponibile per il periodo selezionato.")
            st.info("💡 Prova a sincronizzare i dati o verifica la connessione Garmin Connect")
            
            # Show sample data structure when no data available
            with st.expander("📋 Informazioni Debug"):
                st.write("Stato autenticazione Garmin:", garmin_service.authenticated)
                st.write("Credenziali configurate:", bool(garmin_service.username and garmin_service.password))
                
                # Try to get recent activities for testing
                try:
                    test_activities = garmin_service.get_recent_activities(5)
                    if test_activities is not None and not test_activities.empty:
                        st.write("✅ Dati disponibili da Garmin:")
                        st.dataframe(test_activities.head())
                    else:
                        st.write("❌ Nessun dato recente trovato")
                except Exception as test_e:
                    st.write(f"❌ Errore test connessione: {test_e}")
            return
        
        # Filter by activity type if specified
        if activity_filter:
            activities_data = activities_data[activities_data['activity_type'].isin(activity_filter)]
        
        st.success(f"📊 Caricati {len(activities_data)} allenamenti dal {start_date.strftime('%d/%m/%Y')} al {end_date.strftime('%d/%m/%Y')}")
        
        # Show yearly summary if available
        if st.button("📋 Visualizza Riepilogo Annuale Completo"):
            with st.spinner("Generazione riepilogo annuale..."):
                yearly_summary = garmin_service.get_activity_summary_year()
                if yearly_summary:
                    st.subheader("📊 Riepilogo Ultimo Anno")
                    
                    # Overall stats
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Allenamenti Totali", yearly_summary['total_activities'])
                    with col2:
                        st.metric("Distanza Totale", f"{yearly_summary['total_distance']:.0f} km")
                    with col3:
                        st.metric("Tempo Totale", f"{yearly_summary['total_duration']/3600:.0f}h")
                    with col4:
                        st.metric("Calorie Totali", f"{yearly_summary['total_calories']:.0f}")
                    
                    # Activity type breakdown
                    if yearly_summary['activity_types']:
                        st.subheader("🏃 Breakdown per Tipo Attività")
                        activity_df = pd.DataFrame.from_dict(yearly_summary['activity_types'], orient='index')
                        activity_df = activity_df.reset_index().rename(columns={'index': 'Tipo Attività'})
                        st.dataframe(activity_df, use_container_width=True)
                    
                    # Monthly trends
                    if yearly_summary['monthly_summary']:
                        st.subheader("📈 Tendenze Mensili")
                        monthly_df = pd.DataFrame.from_dict(yearly_summary['monthly_summary'], orient='index')
                        monthly_df = monthly_df.reset_index().rename(columns={'index': 'Mese'})
                        
                        # Plot monthly distance
                        fig = px.line(monthly_df, x='Mese', y='distance', 
                                    title="Distanza Mensile (km)",
                                    markers=True)
                        st.plotly_chart(fig, use_container_width=True)
                else:
                    st.error("Impossibile generare riepilogo annuale")
        
    except Exception as e:
        st.error(f"Errore nel caricamento dati: {str(e)}")
        with st.expander("📋 Dettagli Errore"):
            st.code(str(e))
        return
    
    # Key metrics row
    st.subheader("🏆 Metriche Chiave")
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        total_distance = activities_data['distance'].sum() if 'distance' in activities_data.columns else 0
        st.metric("Distanza Totale", f"{total_distance:.1f} km")
    
    with col2:
        total_time = activities_data['duration'].sum() if 'duration' in activities_data.columns else 0
        st.metric("Tempo Totale", format_duration(total_time))
    
    with col3:
        total_calories = activities_data['calories'].sum() if 'calories' in activities_data.columns else 0
        st.metric("Calorie Totali", f"{total_calories:.0f}")
    
    with col4:
        avg_pace = activities_data['avg_pace'].mean() if 'avg_pace' in activities_data.columns else 0
        st.metric("Passo Medio", f"{avg_pace:.2f} min/km")
    
    with col5:
        activities_count = len(activities_data)
        st.metric("Allenamenti", f"{activities_count}")
    
    # Charts section
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Tendenza Volume Allenamento")
        try:
            # Group by week and calculate weekly totals
            activities_data['week'] = pd.to_datetime(activities_data['date']).dt.to_period('W')
            weekly_data = activities_data.groupby('week').agg({
                'distance': 'sum',
                'duration': 'sum',
                'calories': 'sum'
            }).reset_index()
            weekly_data['week'] = weekly_data['week'].astype(str)
            
            fig = px.bar(
                weekly_data, 
                x='week', 
                y='distance',
                title="Distanza Settimanale (km)",
                color='distance',
                color_continuous_scale='Viridis'
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        except Exception as e:
            st.error(f"Errore nel grafico tendenza: {str(e)}")
    
    with col2:
        st.subheader("🎯 Distribuzione Intensità")
        try:
            if 'avg_heart_rate' in activities_data.columns:
                # Calculate heart rate zones
                hr_zones = calculate_zones(activities_data['avg_heart_rate'])
                zone_counts = pd.Series(hr_zones).value_counts().sort_index()
                
                fig = px.pie(
                    values=zone_counts.values,
                    names=zone_counts.index,
                    title="Distribuzione Zone Frequenza Cardiaca",
                    color_discrete_sequence=px.colors.sequential.RdYlGn_r
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Dati frequenza cardiaca non disponibili")
        except Exception as e:
            st.error(f"Errore nel grafico intensità: {str(e)}")
    
    # Performance analysis
    st.subheader("⚡ Analisi Performance")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🏃‍♂️ Progressione Passo")
        try:
            if 'avg_pace' in activities_data.columns and 'date' in activities_data.columns:
                running_data = activities_data[activities_data['activity_type'] == 'Running'].copy()
                if not running_data.empty:
                    running_data['date'] = pd.to_datetime(running_data['date'])
                    running_data = running_data.sort_values('date')
                    
                    fig = px.scatter(
                        running_data,
                        x='date',
                        y='avg_pace',
                        size='distance',
                        title="Evoluzione Passo nel Tempo",
                        trendline="lowess"
                    )
                    fig.update_layout(height=400)
                    fig.update_yaxis(title="Passo (min/km)")
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("Nessun dato di corsa disponibile")
            else:
                st.info("Dati passo non disponibili")
        except Exception as e:
            st.error(f"Errore nel grafico progressione: {str(e)}")
    
    with col2:
        st.subheader("💓 Analisi Frequenza Cardiaca")
        try:
            if 'avg_heart_rate' in activities_data.columns and 'max_heart_rate' in activities_data.columns:
                fig = go.Figure()
                
                fig.add_trace(go.Scatter(
                    x=activities_data['date'],
                    y=activities_data['avg_heart_rate'],
                    mode='lines+markers',
                    name='FC Media',
                    line=dict(color='blue')
                ))
                
                fig.add_trace(go.Scatter(
                    x=activities_data['date'],
                    y=activities_data['max_heart_rate'],
                    mode='lines+markers',
                    name='FC Massima',
                    line=dict(color='red')
                ))
                
                fig.update_layout(
                    title="Andamento Frequenza Cardiaca",
                    xaxis_title="Data",
                    yaxis_title="BPM",
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Dati frequenza cardiaca non disponibili")
        except Exception as e:
            st.error(f"Errore nel grafico FC: {str(e)}")
    
    # Training load analysis
    st.subheader("🔥 Analisi Carico di Allenamento")
    
    try:
        training_load_data = data_analysis_service.calculate_training_load_trend(
            activities_data, start_date, end_date
        )
        
        if training_load_data is not None and not training_load_data.empty:
            col1, col2 = st.columns([2, 1])
            
            with col1:
                fig = px.line(
                    training_load_data,
                    x='date',
                    y=['acute_load', 'chronic_load'],
                    title="Carico Acuto vs Cronico",
                    labels={'value': 'Training Load', 'variable': 'Tipo'}
                )
                fig.add_hline(y=1.0, line_dash="dash", line_color="red", 
                             annotation_text="Soglia rischio infortunio")
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                current_ratio = training_load_data['acute_chronic_ratio'].iloc[-1] if not training_load_data.empty else 0
                st.metric("Rapporto A:C Attuale", f"{current_ratio:.2f}")
                
                if current_ratio > 1.3:
                    st.error("⚠️ Rischio infortunio elevato")
                elif current_ratio > 1.0:
                    st.warning("⚠️ Carico in aumento")
                else:
                    st.success("✅ Carico sotto controllo")
                
                # Training stress score
                tss = data_analysis_service.calculate_tss(activities_data)
                st.metric("TSS Totale", f"{tss:.0f}")
        else:
            st.info("Dati insufficienti per l'analisi del carico")
    except Exception as e:
        st.error(f"Errore nell'analisi carico: {str(e)}")
    
    # Recent records and achievements
    st.subheader("🏅 Record e Risultati Recenti")
    
    try:
        records = data_analysis_service.get_recent_records(activities_data)
        if records:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("🏃‍♂️ Distanza Record", f"{records.get('max_distance', 0):.1f} km")
                st.metric("⏱️ Durata Record", format_duration(records.get('max_duration', 0)))
            
            with col2:
                st.metric("🔥 Calorie Record", f"{records.get('max_calories', 0):.0f}")
                st.metric("💓 FC Max Registrata", f"{records.get('max_hr', 0):.0f} bpm")
            
            with col3:
                st.metric("⚡ Passo Migliore", f"{records.get('best_pace', 0):.2f} min/km")
                st.metric("📊 Miglior TSS", f"{records.get('best_tss', 0):.0f}")
        else:
            st.info("Nessun record disponibile per il periodo selezionato")
    except Exception as e:
        st.error(f"Errore nel caricamento record: {str(e)}")

if __name__ == "__main__":
    main()
