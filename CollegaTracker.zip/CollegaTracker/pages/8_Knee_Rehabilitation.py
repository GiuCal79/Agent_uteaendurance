import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
from services.data_analysis import DataAnalysisService

st.set_page_config(page_title="Knee Rehabilitation", page_icon="🦵", layout="wide")

@st.cache_resource
def init_services():
    data_analysis_service = DataAnalysisService()
    return data_analysis_service

def main():
    st.title("🦵 Riabilitazione Ginocchio")
    st.markdown("### Programma specializzato per il recupero e la prevenzione degli infortuni al ginocchio")
    
    try:
        data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Injury assessment
    st.subheader("📋 Valutazione Iniziale")
    
    with st.expander("🔍 Assessment Completo", expanded=True):
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 📊 Informazioni Generali")
            
            injury_type = st.selectbox(
                "Tipo di problematica",
                [
                    "Dolore generico",
                    "Condromalacia rotulea",
                    "Tendinite rotulea",
                    "Sindrome femoro-patellare",
                    "Meniscopatia",
                    "Distorsione ligamentosa",
                    "Post-chirurgico",
                    "Prevenzione"
                ]
            )
            
            pain_level = st.slider("Livello dolore attuale (0-10)", 0, 10, 0)
            
            onset_date = st.date_input(
                "Data insorgenza problema",
                value=date.today() - timedelta(days=30),
                max_value=date.today()
            )
            
            activity_limitation = st.selectbox(
                "Limitazione attività",
                ["Nessuna", "Lieve", "Moderata", "Severa", "Impossibile camminare"]
            )
            
            previous_treatments = st.multiselect(
                "Trattamenti precedenti",
                ["Fisioterapia", "Farmaci", "Infiltrazioni", "Chirurgia", "Riposo", "Ghiaccio", "Altro"]
            )
        
        with col2:
            st.markdown("#### 🎯 Test Funzionali")
            
            st.markdown("##### Range of Motion")
            flexion_rom = st.slider("Flessione (gradi)", 0, 150, 130)
            extension_rom = st.slider("Estensione (gradi)", -10, 10, 0)
            
            st.markdown("##### Test di Forza")
            quadriceps_strength = st.slider("Forza quadricipite (1-5)", 1, 5, 4)
            hamstring_strength = st.slider("Forza ischiocrurale (1-5)", 1, 5, 4)
            glute_strength = st.slider("Forza glutei (1-5)", 1, 5, 4)
            
            st.markdown("##### Test Funzionali")
            single_leg_stance = st.slider("Single leg stance (secondi)", 0, 60, 30)
            step_down_quality = st.selectbox("Qualità step down", ["Ottima", "Buona", "Discreta", "Scarsa"])
            squat_depth = st.slider("Profondità squat (%)", 0, 100, 80)
        
        if st.button("💾 Salva Assessment", use_container_width=True):
            assessment_data = {
                'date': date.today(),
                'injury_type': injury_type,
                'pain_level': pain_level,
                'onset_date': onset_date,
                'activity_limitation': activity_limitation,
                'previous_treatments': previous_treatments,
                'flexion_rom': flexion_rom,
                'extension_rom': extension_rom,
                'quadriceps_strength': quadriceps_strength,
                'hamstring_strength': hamstring_strength,
                'glute_strength': glute_strength,
                'single_leg_stance': single_leg_stance,
                'step_down_quality': step_down_quality,
                'squat_depth': squat_depth
            }
            
            try:
                # Save assessment data
                st.success("✅ Assessment salvato con successo!")
                st.session_state.assessment_completed = True
            except Exception as e:
                st.error(f"Errore nel salvare l'assessment: {str(e)}")
    
    # Rehabilitation protocol
    st.subheader("🏥 Protocollo Riabilitativo")
    
    if st.session_state.get('assessment_completed', False):
        # Generate rehabilitation program based on assessment
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("#### 📅 Programma Settimanale")
            
            # Phase-based rehabilitation
            rehab_phase = st.selectbox(
                "Fase riabilitativa",
                ["Fase 1: Controllo dolore e infiammazione", 
                 "Fase 2: Recupero mobilità", 
                 "Fase 3: Rinforzo muscolare", 
                 "Fase 4: Rieducazione funzionale",
                 "Fase 5: Return to sport"]
            )
            
            # Define exercises based on phase
            if "Fase 1" in rehab_phase:
                exercises = [
                    {
                        'name': 'Crioterapia',
                        'duration': '15-20 min',
                        'frequency': '3-4 volte/giorno',
                        'description': 'Applicazione ghiaccio per ridurre infiammazione'
                    },
                    {
                        'name': 'Elevazione arto',
                        'duration': '30 min',
                        'frequency': 'Più volte/giorno',
                        'description': 'Tenere gamba sollevata per drenaggio'
                    },
                    {
                        'name': 'Contrazioni isometriche quadricipite',
                        'duration': '5 sec x 10 ripetizioni',
                        'frequency': '3 serie, 3 volte/giorno',
                        'description': 'Attivazione muscolare senza movimento'
                    },
                    {
                        'name': 'Mobilizzazione dolce caviglia',
                        'duration': '10 ripetizioni',
                        'frequency': '3 volte/giorno',
                        'description': 'Mantenere circolazione distale'
                    }
                ]
            
            elif "Fase 2" in rehab_phase:
                exercises = [
                    {
                        'name': 'Mobilizzazione passiva ginocchio',
                        'duration': '10-15 min',
                        'frequency': '2-3 volte/giorno',
                        'description': 'Recupero graduale range of motion'
                    },
                    {
                        'name': 'Stretching quadricipite',
                        'duration': '30 sec x 3',
                        'frequency': '2 volte/giorno',
                        'description': 'Mantenimento flessibilità'
                    },
                    {
                        'name': 'Stretching ischiocrurale',
                        'duration': '30 sec x 3',
                        'frequency': '2 volte/giorno',
                        'description': 'Riduzione tensione posteriore'
                    },
                    {
                        'name': 'Heel slides',
                        'duration': '10-15 ripetizioni',
                        'frequency': '3 serie, 2 volte/giorno',
                        'description': 'Recupero flessione attiva'
                    }
                ]
            
            elif "Fase 3" in rehab_phase:
                exercises = [
                    {
                        'name': 'Rinforzo quadricipite a catena chiusa',
                        'duration': '12-15 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Mini squat, leg press'
                    },
                    {
                        'name': 'Rinforzo ischiocrurale',
                        'duration': '12-15 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Curl nordico assistito'
                    },
                    {
                        'name': 'Rinforzo glutei',
                        'duration': '15 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Bridge, clamshell, abduzione'
                    },
                    {
                        'name': 'Propriocezione base',
                        'duration': '30 sec',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Equilibrio monopodalico'
                    }
                ]
            
            elif "Fase 4" in rehab_phase:
                exercises = [
                    {
                        'name': 'Squat completo',
                        'duration': '15 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Movimento funzionale completo'
                    },
                    {
                        'name': 'Affondi multidirezionali',
                        'duration': '10 per direzione',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Stabilità dinamica'
                    },
                    {
                        'name': 'Step up/down',
                        'duration': '15 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Controllo eccentrico'
                    },
                    {
                        'name': 'Propriocezione avanzata',
                        'duration': '45 sec',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Superficie instabile'
                    }
                ]
            
            else:  # Fase 5
                exercises = [
                    {
                        'name': 'Salti bilaterali',
                        'duration': '10 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Atterraggio controllato'
                    },
                    {
                        'name': 'Salti unilaterali',
                        'duration': '8 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Progressione asimmetrica'
                    },
                    {
                        'name': 'Cambi di direzione',
                        'duration': '10 ripetizioni',
                        'frequency': '3 serie, 1 volta/giorno',
                        'description': 'Cutting movements'
                    },
                    {
                        'name': 'Sport-specific drills',
                        'duration': '15-20 min',
                        'frequency': '1 volta/giorno',
                        'description': 'Gesti specifici dello sport'
                    }
                ]
            
            # Display exercises
            for i, exercise in enumerate(exercises):
                with st.expander(f"🏋️‍♂️ {exercise['name']}", expanded=True):
                    col_a, col_b, col_c = st.columns(3)
                    
                    with col_a:
                        st.markdown(f"**Durata**: {exercise['duration']}")
                    with col_b:
                        st.markdown(f"**Frequenza**: {exercise['frequency']}")
                    with col_c:
                        completed = st.checkbox("Completato", key=f"exercise_{i}")
                    
                    st.markdown(f"**Descrizione**: {exercise['description']}")
                    
                    if completed:
                        pain_after = st.slider(f"Dolore dopo esercizio (0-10)", 0, 10, 0, key=f"pain_{i}")
                        difficulty = st.slider(f"Difficoltà percepita (1-10)", 1, 10, 5, key=f"diff_{i}")
        
        with col2:
            st.markdown("#### 📊 Monitoraggio Giornaliero")
            
            # Daily tracking
            today_pain = st.slider("Dolore oggi (0-10)", 0, 10, 0)
            today_swelling = st.selectbox("Gonfiore", ["Assente", "Lieve", "Moderato", "Severo"])
            today_stiffness = st.selectbox("Rigidità", ["Assente", "Mattutina", "Dopo attività", "Costante"])
            
            functional_activities = {
                'Camminare piano': st.slider("Camminata lenta", 0, 10, 8),
                'Salire scale': st.slider("Salire scale", 0, 10, 6),
                'Scendere scale': st.slider("Scendere scale", 0, 10, 6),
                'Squat': st.slider("Squat", 0, 10, 4),
                'Corsa': st.slider("Corsa", 0, 10, 2)
            }
            
            st.markdown("#### 💊 Farmaci/Trattamenti")
            medications = st.multiselect(
                "Farmaci assunti oggi",
                ["FANS", "Paracetamolo", "Cortisone", "Integratori", "Nessuno"]
            )
            
            other_treatments = st.multiselect(
                "Altri trattamenti",
                ["Fisioterapia", "Massaggio", "Tecar", "Laser", "Ultrasuoni", "Nessuno"]
            )
            
            if st.button("💾 Salva Giornata", use_container_width=True):
                daily_data = {
                    'date': date.today(),
                    'pain_level': today_pain,
                    'swelling': today_swelling,
                    'stiffness': today_stiffness,
                    'functional_activities': functional_activities,
                    'medications': medications,
                    'other_treatments': other_treatments
                }
                
                try:
                    # Save daily tracking
                    st.success("✅ Dati giornalieri salvati!")
                except Exception as e:
                    st.error(f"Errore nel salvare i dati: {str(e)}")
    else:
        st.info("⚠️ Completa l'assessment iniziale per accedere al protocollo riabilitativo.")
    
    # Progress tracking
    st.subheader("📈 Monitoraggio Progressi")
    
    try:
        # Get rehabilitation progress data
        progress_data = data_analysis_service.get_rehabilitation_progress()
        
        if progress_data is not None and not progress_data.empty:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📊 Trend Dolore")
                
                fig = px.line(
                    progress_data,
                    x='date',
                    y='pain_level',
                    title="Evoluzione Livello Dolore",
                    markers=True
                )
                fig.update_layout(
                    yaxis_title="Livello Dolore (0-10)",
                    yaxis=dict(range=[0, 10])
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("#### 🏃‍♂️ Capacità Funzionali")
                
                # Latest functional scores
                latest_data = progress_data.iloc[-1] if not progress_data.empty else None
                
                if latest_data is not None:
                    functional_scores = {
                        'Camminata': latest_data.get('walking_score', 0),
                        'Scale': latest_data.get('stairs_score', 0),
                        'Squat': latest_data.get('squat_score', 0),
                        'Corsa': latest_data.get('running_score', 0)
                    }
                    
                    fig = px.bar(
                        x=list(functional_scores.keys()),
                        y=list(functional_scores.values()),
                        title="Capacità Funzionali Attuali",
                        color=list(functional_scores.values()),
                        color_continuous_scale='RdYlGn'
                    )
                    fig.update_layout(yaxis_title="Punteggio (0-10)")
                    st.plotly_chart(fig, use_container_width=True)
            
            # ROM and strength progress
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📐 Range of Motion")
                
                if 'flexion_rom' in progress_data.columns and 'extension_rom' in progress_data.columns:
                    fig = go.Figure()
                    
                    fig.add_trace(go.Scatter(
                        x=progress_data['date'],
                        y=progress_data['flexion_rom'],
                        mode='lines+markers',
                        name='Flessione',
                        line=dict(color='blue')
                    ))
                    
                    fig.add_trace(go.Scatter(
                        x=progress_data['date'],
                        y=progress_data['extension_rom'],
                        mode='lines+markers',
                        name='Estensione',
                        line=dict(color='red')
                    ))
                    
                    fig.update_layout(
                        title="Evoluzione Range of Motion",
                        yaxis_title="Gradi",
                        xaxis_title="Data"
                    )
                    st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("#### 💪 Forza Muscolare")
                
                if all(col in progress_data.columns for col in ['quadriceps_strength', 'hamstring_strength', 'glute_strength']):
                    fig = go.Figure()
                    
                    fig.add_trace(go.Scatter(
                        x=progress_data['date'],
                        y=progress_data['quadriceps_strength'],
                        mode='lines+markers',
                        name='Quadricipite',
                        line=dict(color='green')
                    ))
                    
                    fig.add_trace(go.Scatter(
                        x=progress_data['date'],
                        y=progress_data['hamstring_strength'],
                        mode='lines+markers',
                        name='Ischiocrurale',
                        line=dict(color='orange')
                    ))
                    
                    fig.add_trace(go.Scatter(
                        x=progress_data['date'],
                        y=progress_data['glute_strength'],
                        mode='lines+markers',
                        name='Glutei',
                        line=dict(color='purple')
                    ))
                    
                    fig.update_layout(
                        title="Evoluzione Forza Muscolare",
                        yaxis_title="Punteggio Forza (1-5)",
                        xaxis_title="Data"
                    )
                    st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Nessun dato di progresso disponibile. Inizia il tracking giornaliero per visualizzare i progressi.")
    except Exception as e:
        st.error(f"Errore nel caricamento progressi: {str(e)}")
    
    # Return to sport criteria
    st.subheader("🏃‍♂️ Criteri Return to Sport")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### ✅ Lista di Controllo")
        
        rts_criteria = [
            ("Assenza dolore a riposo", False),
            ("Assenza dolore durante ADL", False),
            ("ROM completo (0-135°)", False),
            ("Forza 90% controlaterale", False),
            ("Test hop > 90%", False),
            ("Assenza gonfiore", False),
            ("Controllo propriocettivo", False),
            ("Psicologicamente pronto", False)
        ]
        
        criteria_met = 0
        for criterion, default in rts_criteria:
            met = st.checkbox(criterion, value=default)
            if met:
                criteria_met += 1
        
        rts_percentage = (criteria_met / len(rts_criteria)) * 100
        st.progress(rts_percentage / 100)
        st.metric("Readiness Return to Sport", f"{rts_percentage:.0f}%")
    
    with col2:
        st.markdown("#### 🎯 Raccomandazioni")
        
        if rts_percentage >= 90:
            st.success("✅ Pronto per return to sport graduale")
            st.markdown("• Inizia con allenamenti a bassa intensità")
            st.markdown("• Progressione graduale volume/intensità")
            st.markdown("• Monitoraggio continuo sintomi")
        elif rts_percentage >= 70:
            st.warning("⚠️ Quasi pronto - ancora alcuni criteri da soddisfare")
            st.markdown("• Continua riabilitazione specifica")
            st.markdown("• Focus sui criteri mancanti")
            st.markdown("• Test funzionali avanzati")
        else:
            st.error("❌ Non ancora pronto per return to sport")
            st.markdown("• Prosegui protocollo riabilitativo")
            st.markdown("• Rivalutazione medica se necessario")
            st.markdown("• Pazienza nel processo di guarigione")
    
    # Educational content
    st.subheader("📚 Educazione e Prevenzione")
    
    with st.expander("🧠 Conoscere il Problema", expanded=False):
        st.markdown("""
        #### Anatomia del Ginocchio
        Il ginocchio è un'articolazione complessa che coinvolge:
        - **Femore, tibia e rotula**
        - **Legamenti**: crociati e collaterali
        - **Menischi**: cuscinetti cartilaginei
        - **Muscoli**: quadricipite, ischiocrurale, gastrocnemio
        
        #### Cause Comuni di Infortunio
        - **Sovraccarico funzionale**: aumento troppo rapido del carico
        - **Squilibri muscolari**: debolezza glutei, quadricipite
        - **Problemi biomeccanici**: pronazione eccessiva, valgismo
        - **Superficie di allenamento**: terreni duri, pendenze
        """)
    
    with st.expander("🛡️ Strategie di Prevenzione", expanded=False):
        st.markdown("""
        #### Prevenzione Primaria
        - **Riscaldamento adeguato**: sempre prima dell'attività
        - **Rinforzo muscolare**: focus su quadricipite e glutei
        - **Propriocezione**: esercizi di equilibrio e coordinazione
        - **Flessibilità**: stretching regolare catene muscolari
        
        #### Gestione del Carico
        - **Regola del 10%**: aumenta volume max 10% per settimana
        - **Giorni di riposo**: almeno 1-2 giorni/settimana
        - **Cross-training**: attività alternative
        - **Ascolto del corpo**: rispetta i segnali di affaticamento
        """)
    
    # Contact healthcare provider
    st.subheader("🏥 Quando Consultare uno Specialista")
    
    warning_signs = [
        "Dolore che peggiora progressivamente",
        "Impossibilità a caricare il peso",
        "Blocco articolare",
        "Instabilità significativa",
        "Gonfiore che non diminuisce",
        "Febbre associata al dolore",
        "Nessun miglioramento dopo 1 settimana di riposo"
    ]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 🚨 Segnali di Allarme")
        for sign in warning_signs:
            st.markdown(f"• {sign}")
    
    with col2:
        st.markdown("#### 👨‍⚕️ Team Multidisciplinare")
        st.markdown("• **Medico Ortopedico**: diagnosi e terapie")
        st.markdown("• **Fisioterapista**: riabilitazione funzionale")
        st.markdown("• **Preparatore Atletico**: return to sport")
        st.markdown("• **Podologo**: analisi biomeccanica")
        
        if st.button("📞 Prenota Visita Specialistica", use_container_width=True):
            st.info("Funzionalità prenotazione in sviluppo")

if __name__ == "__main__":
    main()
