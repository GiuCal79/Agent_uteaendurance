import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from data.athlete_profiles import ATHLETE_PROFILES
from services.data_analysis import DataAnalysisService
from services.garmin_connect import GarminConnectService

st.set_page_config(page_title="Athlete Profiles", page_icon="🏆", layout="wide")

@st.cache_resource
def init_services():
    data_analysis_service = DataAnalysisService()
    garmin_service = GarminConnectService()
    return data_analysis_service, garmin_service

def main():
    st.title("🏆 Profili Atleti Ultra-Endurance")
    st.markdown("### Ispirati ai migliori atleti del mondo e raggiungi i loro livelli")
    
    try:
        data_analysis_service, garmin_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Athlete selection
    st.subheader("🌟 Seleziona il tuo Atleta di Riferimento")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        athlete_names = list(ATHLETE_PROFILES.keys())
        selected_athlete = st.selectbox(
            "Atleta",
            athlete_names,
            index=0
        )
    
    # Get selected athlete data
    athlete_data = ATHLETE_PROFILES[selected_athlete]
    
    # Athlete overview
    st.subheader(f"👤 {selected_athlete}")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col1:
        st.image("https://via.placeholder.com/200x250/2E8B57/FFFFFF?text=" + selected_athlete.replace(" ", "+"), 
                caption=selected_athlete)
    
    with col2:
        st.markdown(f"**Specialità**: {athlete_data['specialty']}")
        st.markdown(f"**Nazionalità**: {athlete_data['nationality']}")
        st.markdown(f"**Età**: {athlete_data['age']}")
        st.markdown(f"**Anni di Carriera**: {athlete_data['career_years']}")
        
        st.markdown("#### 🏅 Record Principali")
        for record in athlete_data['major_achievements']:
            st.markdown(f"• {record}")
        
        st.markdown("#### 💭 Filosofia")
        st.markdown(f"*\"{athlete_data['philosophy']}\"*")
    
    with col3:
        st.markdown("#### 📊 Statistiche Chiave")
        stats = athlete_data['key_stats']
        
        for stat_name, stat_value in stats.items():
            st.metric(stat_name, stat_value)
    
    # Performance comparison
    st.subheader("📈 Confronto Performance")
    
    try:
        # Get user's current performance data
        user_performance = data_analysis_service.get_user_performance_summary()
        
        if user_performance:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 🏃‍♂️ Parametri Endurance")
                
                # Create comparison data
                comparison_data = {
                    'Parametro': [],
                    'Tuo Valore': [],
                    'Valore Atleta': [],
                    'Gap %': []
                }
                
                # VO2 Max comparison
                user_vo2 = user_performance.get('vo2_max', 0)
                athlete_vo2 = athlete_data['performance_metrics'].get('vo2_max', 0)
                if user_vo2 > 0 and athlete_vo2 > 0:
                    gap_vo2 = ((athlete_vo2 - user_vo2) / user_vo2) * 100
                    comparison_data['Parametro'].append('VO2 Max')
                    comparison_data['Tuo Valore'].append(f"{user_vo2} ml/kg/min")
                    comparison_data['Valore Atleta'].append(f"{athlete_vo2} ml/kg/min")
                    comparison_data['Gap %'].append(f"{gap_vo2:+.1f}%")
                
                # Threshold pace comparison
                user_threshold = user_performance.get('threshold_pace', 0)
                athlete_threshold = athlete_data['performance_metrics'].get('threshold_pace', 0)
                if user_threshold > 0 and athlete_threshold > 0:
                    gap_threshold = ((user_threshold - athlete_threshold) / athlete_threshold) * 100
                    comparison_data['Parametro'].append('Passo Soglia')
                    comparison_data['Tuo Valore'].append(f"{user_threshold:.2f} min/km")
                    comparison_data['Valore Atleta'].append(f"{athlete_threshold:.2f} min/km")
                    comparison_data['Gap %'].append(f"{gap_threshold:+.1f}%")
                
                # Weekly volume comparison
                user_volume = user_performance.get('weekly_volume', 0)
                athlete_volume = athlete_data['training_metrics'].get('weekly_volume_km', 0)
                if user_volume > 0 and athlete_volume > 0:
                    gap_volume = ((athlete_volume - user_volume) / user_volume) * 100
                    comparison_data['Parametro'].append('Volume Settimanale')
                    comparison_data['Tuo Valore'].append(f"{user_volume:.0f} km")
                    comparison_data['Valore Atleta'].append(f"{athlete_volume:.0f} km")
                    comparison_data['Gap %'].append(f"{gap_volume:+.1f}%")
                
                if comparison_data['Parametro']:
                    comparison_df = pd.DataFrame(comparison_data)
                    st.dataframe(comparison_df, use_container_width=True, hide_index=True)
                else:
                    st.info("Dati insufficienti per il confronto. Continua ad allenarti per raccogliere più dati!")
            
            with col2:
                st.markdown("#### 🎯 Gap Analysis")
                
                if comparison_data['Parametro']:
                    # Extract numeric gaps for visualization
                    gaps = []
                    params = []
                    for i, gap_str in enumerate(comparison_data['Gap %']):
                        try:
                            gap_value = float(gap_str.replace('%', '').replace('+', ''))
                            gaps.append(gap_value)
                            params.append(comparison_data['Parametro'][i])
                        except:
                            continue
                    
                    if gaps:
                        fig = px.bar(
                            x=params,
                            y=gaps,
                            title="Gap Performance (%)",
                            color=gaps,
                            color_continuous_scale='RdYlGn_r'
                        )
                        fig.update_layout(
                            yaxis_title="Gap (%)",
                            xaxis_title="Parametro"
                        )
                        fig.add_hline(y=0, line_dash="dash", line_color="black")
                        st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Dati performance utente non disponibili. Sincronizza i tuoi allenamenti per visualizzare il confronto.")
    except Exception as e:
        st.error(f"Errore nel confronto performance: {str(e)}")
    
    # Training methodology
    st.subheader("🏋️‍♂️ Metodologia di Allenamento")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 📅 Struttura Allenamento")
        
        training_structure = athlete_data['training_methodology']['structure']
        for aspect, details in training_structure.items():
            st.markdown(f"**{aspect.replace('_', ' ').title()}**: {details}")
        
        st.markdown("#### 🔥 Intensità Distribuzione")
        intensity_dist = athlete_data['training_methodology']['intensity_distribution']
        
        fig = px.pie(
            values=list(intensity_dist.values()),
            names=list(intensity_dist.keys()),
            title=f"Distribuzione Intensità - {selected_athlete}"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("#### 🎯 Principi Chiave")
        
        key_principles = athlete_data['training_methodology']['key_principles']
        for principle in key_principles:
            st.markdown(f"• {principle}")
        
        st.markdown("#### 🍎 Approccio Nutrizionale")
        nutrition = athlete_data['nutrition_approach']
        for aspect, details in nutrition.items():
            st.markdown(f"**{aspect.replace('_', ' ').title()}**: {details}")
    
    # Progressive goals based on athlete
    st.subheader("🎯 Obiettivi Progressivi")
    
    st.markdown(f"#### Percorso verso il livello di {selected_athlete}")
    
    # Generate progressive milestones
    try:
        milestones = data_analysis_service.generate_progressive_goals(athlete_data, user_performance if 'user_performance' in locals() else None)
        
        if milestones:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("##### 🥉 Obiettivi a 3 Mesi")
                for goal in milestones.get('3_months', []):
                    st.markdown(f"• {goal}")
            
            with col2:
                st.markdown("##### 🥈 Obiettivi a 6 Mesi")
                for goal in milestones.get('6_months', []):
                    st.markdown(f"• {goal}")
            
            with col3:
                st.markdown("##### 🥇 Obiettivi a 12 Mesi")
                for goal in milestones.get('12_months', []):
                    st.markdown(f"• {goal}")
        else:
            # Default progressive goals
            st.markdown("##### 🥉 Obiettivi a 3 Mesi")
            st.markdown("• Aumenta volume settimanale del 10%")
            st.markdown("• Migliora passo di soglia di 10 sec/km")
            st.markdown("• Completa una distanza ultra entry-level")
            
            st.markdown("##### 🥈 Obiettivi a 6 Mesi")
            st.markdown("• Raggiungi 80% del volume dell'atleta target")
            st.markdown("• Partecipa a gara di 50+ km")
            st.markdown("• Implementa strategie nutrizionali avanzate")
            
            st.markdown("##### 🥇 Obiettivi a 12 Mesi")
            st.markdown("• Avvicinati alle performance dell'atleta target")
            st.markdown("• Completa gara ultra di livello intermedio")
            st.markdown("• Sviluppa approccio mentale professionale")
    except Exception as e:
        st.error(f"Errore nella generazione obiettivi: {str(e)}")
    
    # Workouts inspired by athlete
    st.subheader("🏃‍♂️ Allenamenti Ispirati")
    
    signature_workouts = athlete_data.get('signature_workouts', [])
    
    if signature_workouts:
        workout_names = [workout['name'] for workout in signature_workouts]
        selected_workout = st.selectbox("Seleziona allenamento", workout_names)
        
        # Find selected workout details
        workout_details = next((w for w in signature_workouts if w['name'] == selected_workout), None)
        
        if workout_details:
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown(f"#### {workout_details['name']}")
                st.markdown(f"**Tipo**: {workout_details['type']}")
                st.markdown(f"**Durata**: {workout_details['duration']}")
                st.markdown(f"**Obiettivo**: {workout_details['purpose']}")
                
                st.markdown("##### 📋 Struttura")
                for phase in workout_details['structure']:
                    st.markdown(f"• {phase}")
                
                if 'notes' in workout_details:
                    st.markdown("##### 📝 Note")
                    st.markdown(workout_details['notes'])
            
            with col2:
                st.markdown("##### 🎯 Benefici")
                for benefit in workout_details.get('benefits', []):
                    st.markdown(f"✅ {benefit}")
                
                if st.button("📅 Aggiungi al Calendario", use_container_width=True):
                    st.success(f"✅ Allenamento '{selected_workout}' aggiunto al calendario!")
                
                if st.button("🔄 Adatta al Mio Livello", use_container_width=True):
                    try:
                        adapted_workout = data_analysis_service.adapt_workout_to_user_level(
                            workout_details, 
                            user_performance if 'user_performance' in locals() else None
                        )
                        if adapted_workout:
                            st.success("✅ Allenamento adattato al tuo livello!")
                            st.json(adapted_workout)
                        else:
                            st.info("Continua ad allenarti per ricevere adattamenti personalizzati")
                    except Exception as e:
                        st.error(f"Errore nell'adattamento: {str(e)}")
    else:
        st.info("Allenamenti specifici non disponibili per questo atleta.")
    
    # Mental approach and quotes
    st.subheader("🧠 Approccio Mentale")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 💭 Filosofia Mentale")
        mental_approach = athlete_data.get('mental_approach', {})
        
        for aspect, description in mental_approach.items():
            st.markdown(f"**{aspect.replace('_', ' ').title()}**: {description}")
    
    with col2:
        st.markdown("#### 💬 Citazioni Motivazionali")
        quotes = athlete_data.get('inspirational_quotes', [])
        
        for quote in quotes:
            st.markdown(f"*\"{quote}\"*")
            st.markdown("---")
    
    # Equipment and gear
    if 'equipment' in athlete_data:
        st.subheader("🎽 Equipaggiamento")
        
        equipment = athlete_data['equipment']
        cols = st.columns(len(equipment))
        
        for i, (category, items) in enumerate(equipment.items()):
            with cols[i]:
                st.markdown(f"#### {category.replace('_', ' ').title()}")
                for item in items:
                    st.markdown(f"• {item}")
    
    # Books and resources
    if 'recommended_resources' in athlete_data:
        st.subheader("📚 Risorse Consigliate")
        
        resources = athlete_data['recommended_resources']
        
        col1, col2 = st.columns(2)
        
        with col1:
            if 'books' in resources:
                st.markdown("#### 📖 Libri")
                for book in resources['books']:
                    st.markdown(f"• {book}")
        
        with col2:
            if 'documentaries' in resources:
                st.markdown("#### 🎬 Documentari")
                for doc in resources['documentaries']:
                    st.markdown(f"• {doc}")
    
    # Progress tracking towards athlete level
    st.subheader("📊 Progresso verso il Livello Target")
    
    try:
        progress_data = data_analysis_service.calculate_athlete_progress(
            selected_athlete, 
            athlete_data, 
            user_performance if 'user_performance' in locals() else None
        )
        
        if progress_data:
            overall_progress = progress_data.get('overall_progress', 0)
            st.progress(overall_progress / 100)
            st.metric("Progresso Complessivo", f"{overall_progress:.1f}%")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Fitness Fisico", f"{progress_data.get('physical_fitness', 0):.1f}%")
            
            with col2:
                st.metric("Volume Allenamento", f"{progress_data.get('training_volume', 0):.1f}%")
            
            with col3:
                st.metric("Performance", f"{progress_data.get('performance_level', 0):.1f}%")
        else:
            st.info("Continua ad allenarti per tracciare i progressi verso il livello dell'atleta selezionato.")
    except Exception as e:
        st.error(f"Errore nel calcolo progresso: {str(e)}")

if __name__ == "__main__":
    main()
