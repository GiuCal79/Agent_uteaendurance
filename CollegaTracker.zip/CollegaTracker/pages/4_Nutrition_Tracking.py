import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
from services.integrations import IntegrationsService
from services.data_analysis import DataAnalysisService

st.set_page_config(page_title="Nutrition Tracking", page_icon="🍎", layout="wide")

@st.cache_resource
def init_services():
    integrations_service = IntegrationsService()
    data_analysis_service = DataAnalysisService()
    return integrations_service, data_analysis_service

def main():
    st.title("🍎 Tracking Nutrizionale")
    st.markdown("### Monitoraggio completo di alimentazione e macronutrienti")
    
    try:
        integrations_service, data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Date selection
    col1, col2 = st.columns([1, 3])
    
    with col1:
        selected_date = st.date_input(
            "Seleziona data",
            value=date.today(),
            max_value=date.today()
        )
    
    # Quick add meal section
    st.subheader("🍽️ Aggiungi Pasto")
    
    with st.expander("➕ Nuovo Pasto", expanded=False):
        with st.form("add_meal_form"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                meal_type = st.selectbox(
                    "Tipo pasto",
                    ["Colazione", "Spuntino Mattina", "Pranzo", "Spuntino Pomeriggio", "Cena", "Post-Workout"]
                )
                food_name = st.text_input("Nome alimento")
                quantity = st.number_input("Quantità (g)", min_value=0.0, step=1.0)
            
            with col2:
                calories = st.number_input("Calorie", min_value=0, step=1)
                proteins = st.number_input("Proteine (g)", min_value=0.0, step=0.1)
                carbs = st.number_input("Carboidrati (g)", min_value=0.0, step=0.1)
            
            with col3:
                fats = st.number_input("Grassi (g)", min_value=0.0, step=0.1)
                fiber = st.number_input("Fibre (g)", min_value=0.0, step=0.1)
                sugars = st.number_input("Zuccheri (g)", min_value=0.0, step=0.1)
            
            if st.form_submit_button("💾 Aggiungi Pasto", use_container_width=True):
                meal_data = {
                    'date': selected_date,
                    'meal_type': meal_type,
                    'food_name': food_name,
                    'quantity': quantity,
                    'calories': calories,
                    'proteins': proteins,
                    'carbs': carbs,
                    'fats': fats,
                    'fiber': fiber,
                    'sugars': sugars,
                    'timestamp': datetime.now()
                }
                
                try:
                    # Save meal data (mock implementation)
                    st.success(f"✅ {food_name} aggiunto a {meal_type}")
                    st.rerun()
                except Exception as e:
                    st.error(f"Errore nel salvare il pasto: {str(e)}")
    
    # Daily nutrition overview
    st.subheader(f"📊 Panoramica Nutrizionale - {selected_date.strftime('%d/%m/%Y')}")
    
    try:
        # Get daily nutrition data
        daily_nutrition = integrations_service.get_daily_nutrition(selected_date)
        
        if daily_nutrition:
            # Macronutrients overview
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                total_calories = daily_nutrition.get('total_calories', 0)
                target_calories = daily_nutrition.get('target_calories', 2500)
                calories_percent = (total_calories / target_calories) * 100 if target_calories > 0 else 0
                
                st.metric(
                    "Calorie", 
                    f"{total_calories:.0f} / {target_calories:.0f}",
                    delta=f"{calories_percent:.1f}%"
                )
                st.progress(min(calories_percent / 100, 1.0))
            
            with col2:
                total_proteins = daily_nutrition.get('total_proteins', 0)
                target_proteins = daily_nutrition.get('target_proteins', 150)
                proteins_percent = (total_proteins / target_proteins) * 100 if target_proteins > 0 else 0
                
                st.metric(
                    "Proteine (g)", 
                    f"{total_proteins:.1f} / {target_proteins:.1f}",
                    delta=f"{proteins_percent:.1f}%"
                )
                st.progress(min(proteins_percent / 100, 1.0))
            
            with col3:
                total_carbs = daily_nutrition.get('total_carbs', 0)
                target_carbs = daily_nutrition.get('target_carbs', 350)
                carbs_percent = (total_carbs / target_carbs) * 100 if target_carbs > 0 else 0
                
                st.metric(
                    "Carboidrati (g)", 
                    f"{total_carbs:.1f} / {target_carbs:.1f}",
                    delta=f"{carbs_percent:.1f}%"
                )
                st.progress(min(carbs_percent / 100, 1.0))
            
            with col4:
                total_fats = daily_nutrition.get('total_fats', 0)
                target_fats = daily_nutrition.get('target_fats', 85)
                fats_percent = (total_fats / target_fats) * 100 if target_fats > 0 else 0
                
                st.metric(
                    "Grassi (g)", 
                    f"{total_fats:.1f} / {target_fats:.1f}",
                    delta=f"{fats_percent:.1f}%"
                )
                st.progress(min(fats_percent / 100, 1.0))
            
            # Macronutrients distribution chart
            col1, col2 = st.columns(2)
            
            with col1:
                # Pie chart for macronutrients
                macro_data = {
                    'Proteine': total_proteins * 4,  # 4 cal per gram
                    'Carboidrati': total_carbs * 4,   # 4 cal per gram
                    'Grassi': total_fats * 9          # 9 cal per gram
                }
                
                fig = px.pie(
                    values=list(macro_data.values()),
                    names=list(macro_data.keys()),
                    title="Distribuzione Calorie per Macronutriente",
                    color_discrete_map={
                        'Proteine': '#FF6B6B',
                        'Carboidrati': '#4ECDC4', 
                        'Grassi': '#45B7D1'
                    }
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Meals breakdown
                meals_data = daily_nutrition.get('meals_breakdown', {})
                if meals_data:
                    meals_df = pd.DataFrame(list(meals_data.items()), columns=['Pasto', 'Calorie'])
                    
                    fig = px.bar(
                        meals_df,
                        x='Pasto',
                        y='Calorie',
                        title="Calorie per Pasto",
                        color='Calorie',
                        color_continuous_scale='Viridis'
                    )
                    st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Nessun dato nutrizionale disponibile per questa data.")
    except Exception as e:
        st.error(f"Errore nel caricamento dati nutrizionali: {str(e)}")
    
    # Detailed meals log
    st.subheader("📝 Registro Pasti Dettagliato")
    
    try:
        meals_log = integrations_service.get_meals_log(selected_date)
        
        if meals_log and not meals_log.empty:
            # Group by meal type
            meal_types = meals_log['meal_type'].unique()
            
            for meal_type in meal_types:
                with st.expander(f"🍽️ {meal_type}", expanded=True):
                    meal_data = meals_log[meals_log['meal_type'] == meal_type]
                    
                    for idx, meal in meal_data.iterrows():
                        col1, col2, col3, col4, col5 = st.columns([2, 1, 1, 1, 1])
                        
                        with col1:
                            st.markdown(f"**{meal['food_name']}** ({meal['quantity']}g)")
                        with col2:
                            st.markdown(f"{meal['calories']:.0f} kcal")
                        with col3:
                            st.markdown(f"P: {meal['proteins']:.1f}g")
                        with col4:
                            st.markdown(f"C: {meal['carbs']:.1f}g")
                        with col5:
                            st.markdown(f"G: {meal['fats']:.1f}g")
        else:
            st.info("Nessun pasto registrato per questa data.")
    except Exception as e:
        st.error(f"Errore nel caricamento registro pasti: {str(e)}")
    
    # Weekly nutrition trends
    st.subheader("📈 Trend Settimanale")
    
    try:
        end_date = selected_date
        start_date = end_date - timedelta(days=6)
        
        weekly_nutrition = integrations_service.get_nutrition_range(start_date, end_date)
        
        if weekly_nutrition and not weekly_nutrition.empty:
            col1, col2 = st.columns(2)
            
            with col1:
                # Calories trend
                fig = px.line(
                    weekly_nutrition,
                    x='date',
                    y='total_calories',
                    title="Trend Calorie Settimanali",
                    markers=True
                )
                fig.add_hline(
                    y=weekly_nutrition['target_calories'].mean(),
                    line_dash="dash",
                    annotation_text="Target"
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Macronutrients trend
                fig = go.Figure()
                
                fig.add_trace(go.Scatter(
                    x=weekly_nutrition['date'],
                    y=weekly_nutrition['total_proteins'],
                    mode='lines+markers',
                    name='Proteine',
                    line=dict(color='#FF6B6B')
                ))
                
                fig.add_trace(go.Scatter(
                    x=weekly_nutrition['date'],
                    y=weekly_nutrition['total_carbs'],
                    mode='lines+markers',
                    name='Carboidrati',
                    line=dict(color='#4ECDC4')
                ))
                
                fig.add_trace(go.Scatter(
                    x=weekly_nutrition['date'],
                    y=weekly_nutrition['total_fats'],
                    mode='lines+markers',
                    name='Grassi',
                    line=dict(color='#45B7D1')
                ))
                
                fig.update_layout(
                    title="Trend Macronutrienti (g)",
                    xaxis_title="Data",
                    yaxis_title="Grammi"
                )
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Dati insufficienti per il trend settimanale.")
    except Exception as e:
        st.error(f"Errore nel caricamento trend settimanale: {str(e)}")
    
    # Hydration tracking
    st.subheader("💧 Idratazione")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("#### Consumo Acqua Oggi")
        
        try:
            hydration_data = integrations_service.get_hydration_data(selected_date)
            
            if hydration_data:
                water_consumed = hydration_data.get('water_consumed', 0)
                water_target = hydration_data.get('water_target', 3000)  # ml
                
                st.metric("Acqua Consumata", f"{water_consumed} ml")
                st.metric("Obiettivo", f"{water_target} ml")
                
                hydration_percent = (water_consumed / water_target) * 100 if water_target > 0 else 0
                st.progress(min(hydration_percent / 100, 1.0))
                
                # Quick add water buttons
                st.markdown("#### Aggiungi Acqua")
                col_a, col_b = st.columns(2)
                with col_a:
                    if st.button("💧 250ml", use_container_width=True):
                        # Add water intake
                        st.success("250ml aggiunti!")
                        st.rerun()
                with col_b:
                    if st.button("💧 500ml", use_container_width=True):
                        # Add water intake
                        st.success("500ml aggiunti!")
                        st.rerun()
            else:
                st.info("Dati idratazione non disponibili")
        except Exception as e:
            st.error(f"Errore nei dati idratazione: {str(e)}")
    
    with col2:
        st.markdown("#### Timing Idratazione")
        
        try:
            hydration_timeline = integrations_service.get_hydration_timeline(selected_date)
            
            if hydration_timeline and not hydration_timeline.empty:
                fig = px.bar(
                    hydration_timeline,
                    x='hour',
                    y='water_amount',
                    title="Consumo Acqua per Ora",
                    color='water_amount',
                    color_continuous_scale='Blues'
                )
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Timeline idratazione non disponibile")
        except Exception as e:
            st.error(f"Errore timeline idratazione: {str(e)}")
    
    # Nutritional goals and targets
    st.subheader("🎯 Obiettivi Nutrizionali")
    
    with st.expander("⚙️ Configura Obiettivi", expanded=False):
        with st.form("nutrition_goals_form"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("#### Calorie e Macronutrienti")
                daily_calories = st.number_input("Calorie giornaliere", min_value=1000, max_value=5000, value=2500, step=50)
                protein_target = st.number_input("Proteine (g)", min_value=50, max_value=300, value=150, step=5)
                carbs_target = st.number_input("Carboidrati (g)", min_value=100, max_value=500, value=350, step=10)
                fats_target = st.number_input("Grassi (g)", min_value=30, max_value=150, value=85, step=5)
            
            with col2:
                st.markdown("#### Micronutrienti")
                fiber_target = st.number_input("Fibre (g)", min_value=10, max_value=50, value=25, step=1)
                sodium_limit = st.number_input("Sodio max (mg)", min_value=1000, max_value=3000, value=2300, step=100)
                sugar_limit = st.number_input("Zuccheri max (g)", min_value=20, max_value=100, value=50, step=5)
            
            with col3:
                st.markdown("#### Idratazione e Timing")
                water_target = st.number_input("Acqua (ml)", min_value=1500, max_value=4000, value=3000, step=250)
                meal_frequency = st.selectbox("Frequenza pasti", [3, 4, 5, 6], index=2)
                eating_window = st.slider("Finestra alimentare (ore)", 8, 16, 12)
            
            if st.form_submit_button("💾 Salva Obiettivi", use_container_width=True):
                nutrition_goals = {
                    'daily_calories': daily_calories,
                    'protein_target': protein_target,
                    'carbs_target': carbs_target,
                    'fats_target': fats_target,
                    'fiber_target': fiber_target,
                    'sodium_limit': sodium_limit,
                    'sugar_limit': sugar_limit,
                    'water_target': water_target,
                    'meal_frequency': meal_frequency,
                    'eating_window': eating_window
                }
                
                try:
                    # Save nutrition goals
                    st.success("✅ Obiettivi nutrizionali salvati!")
                except Exception as e:
                    st.error(f"Errore nel salvare gli obiettivi: {str(e)}")

if __name__ == "__main__":
    main()
