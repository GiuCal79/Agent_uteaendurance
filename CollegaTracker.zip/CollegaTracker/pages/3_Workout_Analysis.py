import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from datetime import datetime, timedelta
from services.garmin_connect import GarminConnectService
from services.data_analysis import DataAnalysisService
from services.ml_predictions import MLPredictionsService
from utils.helpers import format_duration, calculate_pace

st.set_page_config(page_title="Workout Analysis", page_icon="📈", layout="wide")

@st.cache_resource
def init_services():
    garmin_service = GarminConnectService()
    data_analysis_service = DataAnalysisService()
    ml_service = MLPredictionsService()
    return garmin_service, data_analysis_service, ml_service

def main():
    st.title("📈 Analisi Workout")
    st.markdown("### Analisi dettagliata delle performance pre e post allenamento")
    
    try:
        garmin_service, data_analysis_service, ml_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Workout selection
    st.subheader("🔍 Seleziona Allenamento")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Get recent activities
        try:
            recent_activities = garmin_service.get_recent_activities(limit=20)
            if recent_activities is not None and not recent_activities.empty:
                # Create display format for activities
                activity_options = []
                for idx, row in recent_activities.iterrows():
                    date_str = pd.to_datetime(row['date']).strftime('%d/%m/%Y')
                    activity_type = row.get('activity_type', 'Unknown')
                    distance = row.get('distance', 0)
                    display_text = f"{date_str} - {activity_type} - {distance:.1f} km"
                    activity_options.append((display_text, idx))
                
                selected_activity_display = st.selectbox(
                    "Seleziona allenamento da analizzare",
                    [option[0] for option in activity_options]
                )
                
                # Get the actual activity data
                selected_idx = next(idx for display, idx in activity_options if display == selected_activity_display)
                selected_activity = recent_activities.iloc[selected_idx]
            else:
                st.warning("Nessun allenamento disponibile per l'analisi.")
                return
        except Exception as e:
            st.error(f"Errore nel caricamento allenamenti: {str(e)}")
            return
    
    with col2:
        analysis_type = st.selectbox(
            "Tipo di analisi",
            ["Completa", "Performance", "Fisiologica", "Tecnica"]
        )
    
    # Activity details header
    st.subheader("ℹ️ Dettagli Allenamento")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        activity_date = pd.to_datetime(selected_activity['date']).strftime('%d/%m/%Y')
        st.metric("Data", activity_date)
    
    with col2:
        activity_type = selected_activity.get('activity_type', 'N/A')
        st.metric("Tipo", activity_type)
    
    with col3:
        distance = selected_activity.get('distance', 0)
        st.metric("Distanza", f"{distance:.2f} km")
    
    with col4:
        duration = selected_activity.get('duration', 0)
        st.metric("Durata", format_duration(duration))
    
    with col5:
        avg_pace = selected_activity.get('avg_pace', 0)
        st.metric("Passo Medio", f"{avg_pace:.2f} min/km")
    
    # Pre-workout analysis
    st.subheader("📊 Analisi Pre-Workout")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 💤 Condizioni Pre-Allenamento")
        
        # Sleep and recovery metrics (simulated data for demo)
        try:
            pre_workout_data = data_analysis_service.get_pre_workout_metrics(selected_activity['date'])
            
            if pre_workout_data:
                sleep_quality = pre_workout_data.get('sleep_quality', 0)
                resting_hr = pre_workout_data.get('resting_hr', 0)
                hrv = pre_workout_data.get('hrv', 0)
                stress_level = pre_workout_data.get('stress_level', 0)
                
                st.metric("Qualità Sonno", f"{sleep_quality}/10")
                st.metric("FC a Riposo", f"{resting_hr} bpm")
                st.metric("HRV", f"{hrv} ms")
                st.metric("Livello Stress", f"{stress_level}/10")
            else:
                st.info("Dati pre-workout non disponibili")
        except Exception as e:
            st.error(f"Errore caricamento dati pre-workout: {str(e)}")
    
    with col2:
        st.markdown("#### 🎯 Previsioni Performance")
        
        try:
            # ML predictions based on pre-workout conditions
            predicted_performance = ml_service.predict_workout_performance(
                selected_activity, 
                pre_workout_data if 'pre_workout_data' in locals() else None
            )
            
            if predicted_performance:
                st.metric("Passo Previsto", f"{predicted_performance.get('predicted_pace', 0):.2f} min/km")
                st.metric("FC Media Prevista", f"{predicted_performance.get('predicted_hr', 0):.0f} bpm")
                st.metric("Sforzo Previsto", f"{predicted_performance.get('predicted_effort', 0)}/10")
                
                confidence = predicted_performance.get('confidence', 0)
                if confidence > 0.8:
                    st.success(f"✅ Previsione affidabile ({confidence:.1%})")
                elif confidence > 0.6:
                    st.warning(f"⚠️ Previsione moderata ({confidence:.1%})")
                else:
                    st.error(f"❌ Previsione poco affidabile ({confidence:.1%})")
            else:
                st.info("Previsioni non disponibili")
        except Exception as e:
            st.error(f"Errore nelle previsioni ML: {str(e)}")
    
    # Workout performance analysis
    st.subheader("🏃‍♂️ Analisi Performance Durante l'Allenamento")
    
    try:
        # Get detailed workout data
        workout_details = garmin_service.get_workout_details(selected_activity.get('activity_id'))
        
        if workout_details and not workout_details.empty:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 💓 Frequenza Cardiaca")
                
                # Heart rate zones analysis
                if 'heart_rate' in workout_details.columns:
                    hr_data = workout_details['heart_rate'].dropna()
                    
                    # Calculate time in zones
                    zones = {
                        'Zona 1 (Recupero)': (0, 0.6),
                        'Zona 2 (Aerobica)': (0.6, 0.7),
                        'Zona 3 (Tempo)': (0.7, 0.8),
                        'Zona 4 (Soglia)': (0.8, 0.9),
                        'Zona 5 (VO2max)': (0.9, 1.0)
                    }
                    
                    max_hr = 220 - 30  # Estimate, should come from user profile
                    zone_times = {}
                    
                    for zone_name, (low, high) in zones.items():
                        zone_mask = (hr_data >= max_hr * low) & (hr_data < max_hr * high)
                        zone_time = zone_mask.sum()  # Assuming 1-second intervals
                        zone_times[zone_name] = zone_time
                    
                    # Display zone distribution
                    fig = px.pie(
                        values=list(zone_times.values()),
                        names=list(zone_times.keys()),
                        title="Distribuzione Tempo nelle Zone FC"
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # HR trend during workout
                    fig_hr = px.line(
                        workout_details,
                        x='elapsed_time',
                        y='heart_rate',
                        title="Andamento Frequenza Cardiaca"
                    )
                    fig_hr.update_layout(height=300)
                    st.plotly_chart(fig_hr, use_container_width=True)
                else:
                    st.info("Dati frequenza cardiaca dettagliati non disponibili")
            
            with col2:
                st.markdown("#### ⚡ Passo e Velocità")
                
                if 'pace' in workout_details.columns:
                    # Pace analysis
                    pace_data = workout_details['pace'].dropna()
                    
                    st.metric("Passo Medio", f"{pace_data.mean():.2f} min/km")
                    st.metric("Passo Migliore", f"{pace_data.min():.2f} min/km")
                    st.metric("Variabilità Passo", f"{pace_data.std():.2f} min/km")
                    
                    # Pace distribution
                    fig_pace = px.histogram(
                        x=pace_data,
                        nbins=20,
                        title="Distribuzione Passo"
                    )
                    st.plotly_chart(fig_pace, use_container_width=True)
                    
                    # Pace trend
                    fig_pace_trend = px.line(
                        workout_details,
                        x='elapsed_time',
                        y='pace',
                        title="Andamento Passo"
                    )
                    fig_pace_trend.update_layout(height=300)
                    st.plotly_chart(fig_pace_trend, use_container_width=True)
                else:
                    st.info("Dati passo dettagliati non disponibili")
        else:
            st.info("Dati dettagliati del workout non disponibili")
    except Exception as e:
        st.error(f"Errore nell'analisi performance: {str(e)}")
    
    # Post-workout analysis
    st.subheader("📉 Analisi Post-Workout")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 🔄 Recupero e Coefficienti")
        
        try:
            post_workout_metrics = data_analysis_service.get_post_workout_metrics(selected_activity)
            
            if post_workout_metrics:
                # Recovery metrics
                st.metric("Training Load", f"{post_workout_metrics.get('training_load', 0):.1f}")
                st.metric("Recovery Time", f"{post_workout_metrics.get('recovery_time', 0):.0f} ore")
                st.metric("Stress Score", f"{post_workout_metrics.get('stress_score', 0):.0f}")
                
                # Progression coefficients
                st.markdown("##### 📈 Coefficienti di Progressione")
                aerobic_coeff = post_workout_metrics.get('aerobic_coefficient', 0)
                anaerobic_coeff = post_workout_metrics.get('anaerobic_coefficient', 0)
                strength_coeff = post_workout_metrics.get('strength_coefficient', 0)
                
                col_a, col_b, col_c = st.columns(3)
                with col_a:
                    st.metric("Aerobico", f"{aerobic_coeff:.2f}")
                with col_b:
                    st.metric("Anaerobico", f"{anaerobic_coeff:.2f}")
                with col_c:
                    st.metric("Forza", f"{strength_coeff:.2f}")
            else:
                st.info("Metriche post-workout non disponibili")
        except Exception as e:
            st.error(f"Errore nel calcolo metriche post-workout: {str(e)}")
    
    with col2:
        st.markdown("#### 🎯 Confronto con Obiettivi")
        
        try:
            # Compare actual vs predicted/target performance
            performance_comparison = data_analysis_service.compare_performance(
                selected_activity,
                predicted_performance if 'predicted_performance' in locals() else None
            )
            
            if performance_comparison:
                # Actual vs predicted
                actual_pace = selected_activity.get('avg_pace', 0)
                predicted_pace = predicted_performance.get('predicted_pace', 0) if 'predicted_performance' in locals() else 0
                
                if predicted_pace > 0:
                    pace_diff = actual_pace - predicted_pace
                    if pace_diff < 0:
                        st.success(f"✅ Passo: {abs(pace_diff):.2f} min/km migliore del previsto")
                    else:
                        st.warning(f"⚠️ Passo: {pace_diff:.2f} min/km più lento del previsto")
                
                # Performance trends
                recent_similar_workouts = data_analysis_service.get_similar_workouts(
                    selected_activity, limit=5
                )
                
                if recent_similar_workouts is not None and not recent_similar_workouts.empty:
                    trend_fig = px.line(
                        recent_similar_workouts,
                        x='date',
                        y='avg_pace',
                        title="Trend Performance Allenamenti Simili"
                    )
                    trend_fig.add_hline(
                        y=actual_pace,
                        line_dash="dash",
                        annotation_text="Allenamento Corrente"
                    )
                    st.plotly_chart(trend_fig, use_container_width=True)
            else:
                st.info("Confronto performance non disponibile")
        except Exception as e:
            st.error(f"Errore nel confronto performance: {str(e)}")
    
    # Recommendations
    st.subheader("💡 Raccomandazioni")
    
    try:
        recommendations = ml_service.generate_workout_recommendations(
            selected_activity,
            post_workout_metrics if 'post_workout_metrics' in locals() else None
        )
        
        if recommendations:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 🎯 Prossimi Allenamenti")
                for rec in recommendations.get('next_workouts', []):
                    st.markdown(f"• **{rec['type']}**: {rec['description']}")
            
            with col2:
                st.markdown("#### ⚠️ Attenzioni")
                for warning in recommendations.get('warnings', []):
                    st.warning(warning)
                
                st.markdown("#### ✅ Punti di Forza")
                for strength in recommendations.get('strengths', []):
                    st.success(strength)
        else:
            st.info("Raccomandazioni non disponibili")
    except Exception as e:
        st.error(f"Errore nella generazione raccomandazioni: {str(e)}")
    
    # Export analysis
    st.subheader("📥 Esporta Analisi")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Genera Report PDF", use_container_width=True):
            st.info("Funzionalità di export PDF in sviluppo")
    
    with col2:
        if st.button("📈 Esporta Dati CSV", use_container_width=True):
            try:
                # Export workout data as CSV
                csv_data = selected_activity.to_csv()
                st.download_button(
                    label="⬇️ Scarica CSV",
                    data=csv_data,
                    file_name=f"workout_analysis_{activity_date.replace('/', '_')}.csv",
                    mime="text/csv"
                )
            except Exception as e:
                st.error(f"Errore nell'export CSV: {str(e)}")
    
    with col3:
        if st.button("📧 Condividi Analisi", use_container_width=True):
            st.info("Funzionalità di condivisione in sviluppo")

if __name__ == "__main__":
    main()
