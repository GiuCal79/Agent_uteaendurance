import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, date, timedelta
from services.integrations import IntegrationsService
from services.data_analysis import DataAnalysisService

st.set_page_config(page_title="Biometric Monitoring", page_icon="📊", layout="wide")

@st.cache_resource
def init_services():
    integrations_service = IntegrationsService()
    data_analysis_service = DataAnalysisService()
    return integrations_service, data_analysis_service

def main():
    st.title("📊 Monitoraggio Biometrico")
    st.markdown("### Tracking completo dei parametri biometrici e bioelettrici")
    
    try:
        integrations_service, data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Quick input section
    st.subheader("📝 Registrazione Rapida")
    
    with st.expander("➕ Aggiungi Misurazione", expanded=True):
        with st.form("quick_measurement_form"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                measurement_date = st.date_input("Data", value=date.today())
                measurement_time = st.time_input("Ora", value=datetime.now().time())
                weight = st.number_input("Peso (kg)", min_value=30.0, max_value=200.0, step=0.1)
                body_fat = st.number_input("Massa Grassa (%)", min_value=0.0, max_value=50.0, step=0.1)
            
            with col2:
                muscle_mass = st.number_input("Massa Muscolare (%)", min_value=0.0, max_value=70.0, step=0.1)
                water_percentage = st.number_input("Acqua Corporea (%)", min_value=30.0, max_value=80.0, step=0.1)
                bone_mass = st.number_input("Massa Ossea (kg)", min_value=0.0, max_value=10.0, step=0.1)
                visceral_fat = st.number_input("Grasso Viscerale", min_value=1, max_value=30, step=1)
            
            with col3:
                resting_hr = st.number_input("FC a Riposo (bpm)", min_value=30, max_value=120, step=1)
                blood_pressure_sys = st.number_input("Pressione Sistolica", min_value=80, max_value=200, step=1)
                blood_pressure_dia = st.number_input("Pressione Diastolica", min_value=40, max_value=120, step=1)
                sleep_hours = st.number_input("Ore di Sonno", min_value=0.0, max_value=12.0, step=0.5)
            
            if st.form_submit_button("💾 Salva Misurazione", use_container_width=True):
                measurement_data = {
                    'date': measurement_date,
                    'time': measurement_time,
                    'weight': weight,
                    'body_fat': body_fat,
                    'muscle_mass': muscle_mass,
                    'water_percentage': water_percentage,
                    'bone_mass': bone_mass,
                    'visceral_fat': visceral_fat,
                    'resting_hr': resting_hr,
                    'blood_pressure_sys': blood_pressure_sys,
                    'blood_pressure_dia': blood_pressure_dia,
                    'sleep_hours': sleep_hours,
                    'timestamp': datetime.combine(measurement_date, measurement_time)
                }
                
                try:
                    # Save measurement data
                    st.success("✅ Misurazione salvata con successo!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Errore nel salvare la misurazione: {str(e)}")
    
    # Current status overview
    st.subheader("📈 Stato Attuale")
    
    try:
        latest_measurements = integrations_service.get_latest_biometric_data()
        
        if latest_measurements:
            col1, col2, col3, col4, col5, col6 = st.columns(6)
            
            with col1:
                current_weight = latest_measurements.get('weight', 0)
                weight_change = latest_measurements.get('weight_change_week', 0)
                st.metric("Peso", f"{current_weight:.1f} kg", delta=f"{weight_change:+.1f} kg")
            
            with col2:
                current_bf = latest_measurements.get('body_fat', 0)
                bf_change = latest_measurements.get('bf_change_week', 0)
                st.metric("Massa Grassa", f"{current_bf:.1f}%", delta=f"{bf_change:+.1f}%")
            
            with col3:
                current_muscle = latest_measurements.get('muscle_mass', 0)
                muscle_change = latest_measurements.get('muscle_change_week', 0)
                st.metric("Massa Muscolare", f"{current_muscle:.1f}%", delta=f"{muscle_change:+.1f}%")
            
            with col4:
                current_rhr = latest_measurements.get('resting_hr', 0)
                rhr_change = latest_measurements.get('rhr_change_week', 0)
                st.metric("FC Riposo", f"{current_rhr:.0f} bpm", delta=f"{rhr_change:+.0f} bpm")
            
            with col5:
                current_bp = f"{latest_measurements.get('blood_pressure_sys', 0):.0f}/{latest_measurements.get('blood_pressure_dia', 0):.0f}"
                st.metric("Pressione", current_bp)
            
            with col6:
                current_sleep = latest_measurements.get('sleep_hours', 0)
                sleep_change = latest_measurements.get('sleep_change_week', 0)
                st.metric("Sonno", f"{current_sleep:.1f}h", delta=f"{sleep_change:+.1f}h")
        else:
            st.info("Nessuna misurazione recente disponibile.")
    except Exception as e:
        st.error(f"Errore nel caricamento dati attuali: {str(e)}")
    
    # Trend analysis
    st.subheader("📊 Analisi Trend")
    
    # Time period selector
    col1, col2 = st.columns([1, 3])
    with col1:
        time_period = st.selectbox(
            "Periodo analisi",
            ["Ultima settimana", "Ultimo mese", "Ultimi 3 mesi", "Ultimo anno"],
            index=1
        )
    
    # Calculate date range
    end_date = datetime.now()
    if time_period == "Ultima settimana":
        start_date = end_date - timedelta(weeks=1)
    elif time_period == "Ultimo mese":
        start_date = end_date - timedelta(days=30)
    elif time_period == "Ultimi 3 mesi":
        start_date = end_date - timedelta(days=90)
    else:  # Ultimo anno
        start_date = end_date - timedelta(days=365)
    
    try:
        biometric_data = integrations_service.get_biometric_data_range(start_date, end_date)
        
        if biometric_data is not None and not biometric_data.empty:
            # Weight and body composition trends
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### ⚖️ Peso e Composizione Corporea")
                
                fig = make_subplots(
                    rows=2, cols=1,
                    subplot_titles=('Peso (kg)', 'Composizione Corporea (%)'),
                    shared_xaxes=True
                )
                
                # Weight trend
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['weight'],
                        mode='lines+markers',
                        name='Peso',
                        line=dict(color='blue')
                    ),
                    row=1, col=1
                )
                
                # Body composition
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['body_fat'],
                        mode='lines+markers',
                        name='Massa Grassa',
                        line=dict(color='red')
                    ),
                    row=2, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['muscle_mass'],
                        mode='lines+markers',
                        name='Massa Muscolare',
                        line=dict(color='green')
                    ),
                    row=2, col=1
                )
                
                fig.update_layout(height=500)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("#### 💓 Parametri Cardiovascolari")
                
                fig = make_subplots(
                    rows=2, cols=1,
                    subplot_titles=('Frequenza Cardiaca a Riposo (bpm)', 'Pressione Arteriosa (mmHg)'),
                    shared_xaxes=True
                )
                
                # Resting heart rate
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['resting_hr'],
                        mode='lines+markers',
                        name='FC Riposo',
                        line=dict(color='purple')
                    ),
                    row=1, col=1
                )
                
                # Blood pressure
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['blood_pressure_sys'],
                        mode='lines+markers',
                        name='Sistolica',
                        line=dict(color='red')
                    ),
                    row=2, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=biometric_data['date'],
                        y=biometric_data['blood_pressure_dia'],
                        mode='lines+markers',
                        name='Diastolica',
                        line=dict(color='orange')
                    ),
                    row=2, col=1
                )
                
                fig.update_layout(height=500)
                st.plotly_chart(fig, use_container_width=True)
            
            # Sleep and recovery analysis
            st.markdown("#### 😴 Analisi Sonno e Recupero")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Sleep trends
                fig = px.line(
                    biometric_data,
                    x='date',
                    y='sleep_hours',
                    title="Ore di Sonno",
                    markers=True
                )
                fig.add_hline(y=8, line_dash="dash", annotation_text="Target 8h")
                fig.add_hline(y=7, line_dash="dash", annotation_text="Minimo 7h")
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Sleep quality distribution
                sleep_quality_bins = pd.cut(biometric_data['sleep_hours'], 
                                          bins=[0, 6, 7, 8, 9, 12], 
                                          labels=['<6h', '6-7h', '7-8h', '8-9h', '>9h'])
                sleep_dist = sleep_quality_bins.value_counts()
                
                fig = px.pie(
                    values=sleep_dist.values,
                    names=sleep_dist.index,
                    title="Distribuzione Ore di Sonno"
                )
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Dati biometrici insufficienti per l'analisi del trend.")
    except Exception as e:
        st.error(f"Errore nell'analisi trend: {str(e)}")
    
    # Body composition detailed analysis
    st.subheader("🔬 Analisi Dettagliata Composizione Corporea")
    
    try:
        if biometric_data is not None and not biometric_data.empty:
            latest_data = biometric_data.iloc[-1]
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("#### 📊 Composizione Attuale")
                
                composition_data = {
                    'Massa Muscolare': latest_data.get('muscle_mass', 0),
                    'Massa Grassa': latest_data.get('body_fat', 0),
                    'Acqua Corporea': latest_data.get('water_percentage', 0),
                    'Altro': 100 - (latest_data.get('muscle_mass', 0) + 
                                  latest_data.get('body_fat', 0) + 
                                  latest_data.get('water_percentage', 0))
                }
                
                fig = px.pie(
                    values=list(composition_data.values()),
                    names=list(composition_data.keys()),
                    title="Composizione Corporea Attuale",
                    color_discrete_map={
                        'Massa Muscolare': '#2E8B57',
                        'Massa Grassa': '#FF6B6B',
                        'Acqua Corporea': '#4ECDC4',
                        'Altro': '#95A5A6'
                    }
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("#### 🎯 Obiettivi e Range Ideali")
                
                # Health ranges based on age and gender (simplified)
                current_bf = latest_data.get('body_fat', 0)
                current_muscle = latest_data.get('muscle_mass', 0)
                current_water = latest_data.get('water_percentage', 0)
                
                # Simplified healthy ranges (should be personalized)
                st.markdown(f"**Massa Grassa**: {current_bf:.1f}% ")
                if 10 <= current_bf <= 20:
                    st.success("✅ Range ottimale")
                elif 20 < current_bf <= 25:
                    st.warning("⚠️ Leggermente alto")
                else:
                    st.error("❌ Fuori range")
                
                st.markdown(f"**Massa Muscolare**: {current_muscle:.1f}%")
                if current_muscle >= 40:
                    st.success("✅ Eccellente")
                elif current_muscle >= 35:
                    st.warning("⚠️ Buono")
                else:
                    st.error("❌ Da migliorare")
                
                st.markdown(f"**Acqua Corporea**: {current_water:.1f}%")
                if 50 <= current_water <= 70:
                    st.success("✅ Range normale")
                else:
                    st.warning("⚠️ Verifica idratazione")
            
            with col3:
                st.markdown("#### 📈 Progressi Recenti")
                
                if len(biometric_data) >= 2:
                    # Calculate recent changes
                    recent_change = biometric_data.iloc[-1] - biometric_data.iloc[-2]
                    
                    st.metric("Peso", 
                             f"{latest_data.get('weight', 0):.1f} kg",
                             delta=f"{recent_change.get('weight', 0):+.1f} kg")
                    
                    st.metric("Massa Grassa", 
                             f"{latest_data.get('body_fat', 0):.1f}%",
                             delta=f"{recent_change.get('body_fat', 0):+.1f}%")
                    
                    st.metric("Massa Muscolare", 
                             f"{latest_data.get('muscle_mass', 0):.1f}%",
                             delta=f"{recent_change.get('muscle_mass', 0):+.1f}%")
                    
                    st.metric("FC Riposo", 
                             f"{latest_data.get('resting_hr', 0):.0f} bpm",
                             delta=f"{recent_change.get('resting_hr', 0):+.0f} bpm")
                else:
                    st.info("Dati insufficienti per calcolare i progressi")
    except Exception as e:
        st.error(f"Errore nell'analisi composizione corporea: {str(e)}")
    
    # Health alerts and recommendations
    st.subheader("⚠️ Alert Salute e Raccomandazioni")
    
    try:
        health_alerts = data_analysis_service.generate_health_alerts(latest_measurements if 'latest_measurements' in locals() else None)
        
        if health_alerts:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 🚨 Alert")
                for alert in health_alerts.get('alerts', []):
                    if alert['severity'] == 'high':
                        st.error(f"🚨 {alert['message']}")
                    elif alert['severity'] == 'medium':
                        st.warning(f"⚠️ {alert['message']}")
                    else:
                        st.info(f"ℹ️ {alert['message']}")
            
            with col2:
                st.markdown("#### 💡 Raccomandazioni")
                for recommendation in health_alerts.get('recommendations', []):
                    st.success(f"✅ {recommendation}")
        else:
            st.success("✅ Nessun alert sanitario rilevato")
    except Exception as e:
        st.error(f"Errore nella generazione alert: {str(e)}")
    
    # Data export
    st.subheader("📥 Esporta Dati")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Esporta CSV", use_container_width=True):
            try:
                if 'biometric_data' in locals() and biometric_data is not None:
                    csv_data = biometric_data.to_csv(index=False)
                    st.download_button(
                        label="⬇️ Scarica Dati Biometrici",
                        data=csv_data,
                        file_name=f"biometric_data_{datetime.now().strftime('%Y%m%d')}.csv",
                        mime="text/csv"
                    )
                else:
                    st.error("Nessun dato disponibile per l'export")
            except Exception as e:
                st.error(f"Errore nell'export: {str(e)}")
    
    with col2:
        if st.button("📈 Report PDF", use_container_width=True):
            st.info("Funzionalità report PDF in sviluppo")
    
    with col3:
        if st.button("📧 Condividi con Medico", use_container_width=True):
            st.info("Funzionalità condivisione in sviluppo")

if __name__ == "__main__":
    main()
