import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta, date
import calendar
from services.garmin_connect import GarminConnectService
from services.data_analysis import DataAnalysisService
from utils.helpers import format_duration

st.set_page_config(page_title="Training Calendar", page_icon="📅", layout="wide")

@st.cache_resource
def init_services():
    garmin_service = GarminConnectService()
    data_analysis_service = DataAnalysisService()
    return garmin_service, data_analysis_service

def create_calendar_view(activities_data, selected_month, selected_year):
    """Create a calendar view of training activities"""
    
    # Create calendar matrix
    cal = calendar.monthcalendar(selected_year, selected_month)
    
    # Prepare data for the month
    month_data = {}
    if activities_data is not None and not activities_data.empty:
        activities_data['date'] = pd.to_datetime(activities_data['date'])
        month_activities = activities_data[
            (activities_data['date'].dt.month == selected_month) &
            (activities_data['date'].dt.year == selected_year)
        ]
        
        for _, activity in month_activities.iterrows():
            day = activity['date'].day
            if day not in month_data:
                month_data[day] = []
            month_data[day].append({
                'type': activity.get('activity_type', 'Unknown'),
                'distance': activity.get('distance', 0),
                'duration': activity.get('duration', 0)
            })
    
    return cal, month_data

def main():
    st.title("📅 Calendario Allenamenti")
    st.markdown("### Pianificazione e tracciamento degli allenamenti")
    
    try:
        garmin_service, data_analysis_service = init_services()
    except Exception as e:
        st.error(f"Errore nell'inizializzazione: {str(e)}")
        return
    
    # Date selection
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        selected_year = st.selectbox(
            "Anno",
            range(2020, 2030),
            index=range(2020, 2030).index(datetime.now().year)
        )
    
    with col2:
        month_names = list(calendar.month_name)[1:]
        selected_month_name = st.selectbox(
            "Mese",
            month_names,
            index=datetime.now().month - 1
        )
        selected_month = month_names.index(selected_month_name) + 1
    
    # Load activities for the selected month
    try:
        start_date = datetime(selected_year, selected_month, 1)
        if selected_month == 12:
            end_date = datetime(selected_year + 1, 1, 1) - timedelta(days=1)
        else:
            end_date = datetime(selected_year, selected_month + 1, 1) - timedelta(days=1)
        
        activities_data = garmin_service.get_activities_in_range(start_date, end_date)
    except Exception as e:
        st.error(f"Errore nel caricamento attività: {str(e)}")
        activities_data = pd.DataFrame()
    
    # Calendar view
    st.subheader(f"📅 {selected_month_name} {selected_year}")
    
    try:
        cal, month_data = create_calendar_view(activities_data, selected_month, selected_year)
        
        # Create calendar display
        days_of_week = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom']
        
        # Header
        cols = st.columns(7)
        for i, day in enumerate(days_of_week):
            cols[i].markdown(f"**{day}**")
        
        # Calendar rows
        for week in cal:
            cols = st.columns(7)
            for i, day in enumerate(week):
                if day == 0:
                    cols[i].markdown("")
                else:
                    with cols[i]:
                        # Day number
                        st.markdown(f"**{day}**")
                        
                        # Activities for this day
                        if day in month_data:
                            for activity in month_data[day]:
                                activity_type = activity['type']
                                distance = activity['distance']
                                
                                # Color code by activity type
                                if activity_type == 'Running':
                                    st.markdown(f"🏃‍♂️ {distance:.1f}km")
                                elif activity_type == 'Cycling':
                                    st.markdown(f"🚴‍♂️ {distance:.1f}km")
                                elif activity_type == 'Swimming':
                                    st.markdown(f"🏊‍♂️ {distance:.1f}km")
                                else:
                                    st.markdown(f"⚡ {distance:.1f}km")
                        
                        # Add workout button
                        if st.button("+", key=f"add_{day}", help="Aggiungi allenamento"):
                            st.session_state.selected_date = date(selected_year, selected_month, day)
                            st.session_state.show_add_workout = True
    
    except Exception as e:
        st.error(f"Errore nella visualizzazione calendario: {str(e)}")
    
    # Add workout modal
    if st.session_state.get('show_add_workout', False):
        st.subheader("➕ Aggiungi Allenamento")
        
        with st.form("add_workout_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                workout_date = st.date_input(
                    "Data",
                    value=st.session_state.get('selected_date', date.today())
                )
                activity_type = st.selectbox(
                    "Tipo di attività",
                    ["Running", "Cycling", "Swimming", "Walking", "Strength", "Yoga", "Rest"]
                )
                distance = st.number_input("Distanza (km)", min_value=0.0, step=0.1)
                duration_hours = st.number_input("Ore", min_value=0, max_value=23, step=1)
                duration_minutes = st.number_input("Minuti", min_value=0, max_value=59, step=1)
            
            with col2:
                avg_hr = st.number_input("FC Media (bpm)", min_value=0, max_value=220, step=1)
                max_hr = st.number_input("FC Massima (bpm)", min_value=0, max_value=220, step=1)
                calories = st.number_input("Calorie", min_value=0, step=10)
                notes = st.text_area("Note")
                
                # Effort scale
                perceived_effort = st.slider("Sforzo Percepito (RPE)", 1, 10, 5)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.form_submit_button("💾 Salva Allenamento", use_container_width=True):
                    # Calculate total duration in seconds
                    total_duration = (duration_hours * 3600) + (duration_minutes * 60)
                    
                    # Create workout data
                    workout_data = {
                        'date': workout_date,
                        'activity_type': activity_type,
                        'distance': distance,
                        'duration': total_duration,
                        'avg_heart_rate': avg_hr if avg_hr > 0 else None,
                        'max_heart_rate': max_hr if max_hr > 0 else None,
                        'calories': calories,
                        'notes': notes,
                        'perceived_effort': perceived_effort
                    }
                    
                    try:
                        # Save to database (mock implementation)
                        st.success("✅ Allenamento salvato con successo!")
                        st.session_state.show_add_workout = False
                        st.rerun()
                    except Exception as e:
                        st.error(f"Errore nel salvare l'allenamento: {str(e)}")
            
            with col2:
                if st.form_submit_button("❌ Annulla", use_container_width=True):
                    st.session_state.show_add_workout = False
                    st.rerun()
    
    # Monthly summary
    st.subheader("📊 Riepilogo Mensile")
    
    if activities_data is not None and not activities_data.empty:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_workouts = len(activities_data)
            st.metric("Allenamenti", total_workouts)
        
        with col2:
            total_distance = activities_data['distance'].sum() if 'distance' in activities_data.columns else 0
            st.metric("Distanza Totale", f"{total_distance:.1f} km")
        
        with col3:
            total_time = activities_data['duration'].sum() if 'duration' in activities_data.columns else 0
            st.metric("Tempo Totale", format_duration(total_time))
        
        with col4:
            total_calories = activities_data['calories'].sum() if 'calories' in activities_data.columns else 0
            st.metric("Calorie", f"{total_calories:.0f}")
        
        # Activity type distribution
        col1, col2 = st.columns(2)
        
        with col1:
            if 'activity_type' in activities_data.columns:
                activity_counts = activities_data['activity_type'].value_counts()
                fig = px.pie(
                    values=activity_counts.values,
                    names=activity_counts.index,
                    title="Distribuzione Tipi di Attività"
                )
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Weekly progression
            activities_data['week'] = pd.to_datetime(activities_data['date']).dt.isocalendar().week
            weekly_distance = activities_data.groupby('week')['distance'].sum().reset_index()
            
            fig = px.bar(
                weekly_distance,
                x='week',
                y='distance',
                title="Distanza per Settimana"
            )
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Nessuna attività registrata per questo mese.")
    
    # Training plan section
    st.subheader("🎯 Piano di Allenamento")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Weekly plan template
        st.markdown("#### Modello Settimanale")
        
        weekly_plan = {
            'Lunedì': 'Riposo attivo / Mobilità',
            'Martedì': 'Interval Training',
            'Mercoledì': 'Endurance moderata',
            'Giovedì': 'Strength Training',
            'Venerdì': 'Recovery Run',
            'Sabato': 'Long Run',
            'Domenica': 'Cross Training'
        }
        
        for day, activity in weekly_plan.items():
            st.markdown(f"**{day}**: {activity}")
    
    with col2:
        st.markdown("#### Obiettivi Settimanali")
        
        weekly_targets = st.form("weekly_targets")
        with weekly_targets:
            target_distance = st.number_input("Distanza target (km)", min_value=0.0, step=5.0, value=50.0)
            target_workouts = st.number_input("Numero allenamenti", min_value=0, max_value=14, step=1, value=5)
            target_hours = st.number_input("Ore totali", min_value=0.0, step=0.5, value=6.0)
            
            if st.form_submit_button("💾 Salva Obiettivi"):
                st.success("✅ Obiettivi salvati!")
        
        # Progress towards weekly goals
        if activities_data is not None and not activities_data.empty:
            current_week_data = activities_data[
                pd.to_datetime(activities_data['date']).dt.isocalendar().week == datetime.now().isocalendar().week
            ]
            
            if not current_week_data.empty:
                current_distance = current_week_data['distance'].sum()
                current_workouts = len(current_week_data)
                current_hours = current_week_data['duration'].sum() / 3600
                
                st.markdown("#### Progresso Settimana")
                st.progress(min(current_distance / target_distance, 1.0), text=f"Distanza: {current_distance:.1f}/{target_distance:.1f} km")
                st.progress(min(current_workouts / target_workouts, 1.0), text=f"Allenamenti: {current_workouts}/{target_workouts}")
                st.progress(min(current_hours / target_hours, 1.0), text=f"Ore: {current_hours:.1f}/{target_hours:.1f}")

if __name__ == "__main__":
    main()
