import os
import json
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

class CacheManager:
    """Manages local caching of Garmin Connect data to reduce API calls"""
    
    def __init__(self):
        self.cache_dir = "cache"
        self.activities_cache = "cache/activities.json"
        self.biometric_cache = "cache/biometric.json"
        self.cache_expiry_hours = 2  # Cache expires after 2 hours
        
        # Create cache directory if it doesn't exist
        os.makedirs(self.cache_dir, exist_ok=True)
    
    def is_cache_valid(self, cache_file: str) -> bool:
        """Check if cache file exists and is not expired"""
        if not os.path.exists(cache_file):
            return False
        
        # Check file modification time
        file_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
        expiry_time = datetime.now() - timedelta(hours=self.cache_expiry_hours)
        
        return file_time > expiry_time
    
    def save_activities_cache(self, activities_data: pd.DataFrame):
        """Save activities data to cache"""
        try:
            # Convert DataFrame to JSON
            activities_json = activities_data.to_json(orient='records', date_format='iso')
            with open(self.activities_cache, 'w') as f:
                f.write(activities_json)
        except Exception as e:
            print(f"Error saving activities cache: {e}")
    
    def load_activities_cache(self) -> Optional[pd.DataFrame]:
        """Load activities data from cache"""
        try:
            if self.is_cache_valid(self.activities_cache):
                with open(self.activities_cache, 'r') as f:
                    activities_json = f.read()
                return pd.read_json(activities_json, orient='records')
            return None
        except Exception as e:
            print(f"Error loading activities cache: {e}")
            return None
    
    def save_biometric_cache(self, biometric_data: Dict[str, Any]):
        """Save biometric data to cache"""
        try:
            with open(self.biometric_cache, 'w') as f:
                json.dump(biometric_data, f, indent=2, default=str)
        except Exception as e:
            print(f"Error saving biometric cache: {e}")
    
    def load_biometric_cache(self) -> Optional[Dict[str, Any]]:
        """Load biometric data from cache"""
        try:
            if self.is_cache_valid(self.biometric_cache):
                with open(self.biometric_cache, 'r') as f:
                    return json.load(f)
            return None
        except Exception as e:
            print(f"Error loading biometric cache: {e}")
            return None
    
    def clear_cache(self):
        """Clear all cached data"""
        try:
            if os.path.exists(self.activities_cache):
                os.remove(self.activities_cache)
            if os.path.exists(self.biometric_cache):
                os.remove(self.biometric_cache)
        except Exception as e:
            print(f"Error clearing cache: {e}")
    
    def get_cache_info(self) -> Dict[str, Any]:
        """Get information about cached data"""
        info = {
            'activities_cached': os.path.exists(self.activities_cache),
            'biometric_cached': os.path.exists(self.biometric_cache),
            'activities_valid': self.is_cache_valid(self.activities_cache),
            'biometric_valid': self.is_cache_valid(self.biometric_cache)
        }
        
        if info['activities_cached']:
            info['activities_size'] = os.path.getsize(self.activities_cache)
            info['activities_modified'] = datetime.fromtimestamp(
                os.path.getmtime(self.activities_cache)
            ).strftime('%Y-%m-%d %H:%M')
        
        if info['biometric_cached']:
            info['biometric_size'] = os.path.getsize(self.biometric_cache)
            info['biometric_modified'] = datetime.fromtimestamp(
                os.path.getmtime(self.biometric_cache)
            ).strftime('%Y-%m-%d %H:%M')
        
        return info